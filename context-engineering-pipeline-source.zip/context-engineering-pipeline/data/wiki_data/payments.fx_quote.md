---
title: FX quote endpoint returns stale rate after v2 migration
entity_key: payments.fx_quote
source_type: ado
source_ref: ado-1:48301
candidate_id: cko-24010a8e7094
viewpoints: [api_integration, business_process, technical_implementation]
version: 1
approved_by: S. Idris
published_at: 2026-08-16T20:33:40.496677+00:00
status: Active
---

# FX quote endpoint returns stale rate after v2 migration

## Summary
This document outlines the migration from the deprecated v1 quote endpoint to v2, addressing issues with clients still using v1 and causing stale rate problems.

## Purpose
To address the issue of clients using the deprecated v1 quote endpoint which returns stale rates after migration to v2.

## Interfaces
- /v1/quote
- /v2/quote

## Business Rules
- All internal callers of /v1/quote are migrated to /v2/quote.
- /v1/quote returns a deprecation warning header until fully retired.

## Source Content
Since migrating callers to GET /v2/quote, a small number of clients still hardcode /v1/quote, which was deprecated 4 months ago and now returns a rate that is no longer refreshed on the usual schedule. Clients must move to /v2/quote, which also adds async callback mode instead of synchronous-only polling.

- All internal callers of /v1/quote are migrated to /v2/quote.
- /v1/quote returns a deprecation warning header until fully retired.
