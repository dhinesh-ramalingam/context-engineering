---
title: SRE on-call — sanctions screening timeout
entity_key: payments.sanctions_screening
source_type: runbook
source_ref: runbook-1:sanctions-screening-timeout-oncall
candidate_id: cko-722ba29085f5
viewpoints: [operational_procedure]
version: 2
approved_by: K. Mensah
published_at: 2026-08-16T20:34:05.408538+00:00
status: Active
---

# SRE on-call — sanctions screening timeout

## Summary
This runbook outlines the steps for SRE on-call personnel when SanctionsService.screen() times out, directing them to check provider status and escalate payments requiring manual review.

## Purpose
What to do when SanctionsService.screen() is timing out for a sustained period, causing payments to escalate to manual review instead of dispatching.

## Interfaces
- sanctions_check table (payments schema)
- sanctions provider status page

## Business Rules
- Do not disable screening to relieve backlog under any circumstance.

## Dependencies
- SanctionsService
- PaymentDispatcher
- compliance on-call rotation

## Source Content
# SRE on-call — sanctions screening timeout

## Purpose
What to do when SanctionsService.screen() is timing out for a sustained period, causing payments to escalate to manual review instead of dispatching.

## Scope
Applies to the Singapore FAST rail sanctions screening step in PaymentDispatcher.

## Procedure
1. Check the sanctions provider status page for an outage.
2. Check `sanctions_check.screening_latency_ms` in the payments schema for a latency spike vs. the 180ms internal timeout budget.
3. If the provider is degraded, page the compliance on-call — escalated payments must go through manual review, they are not queued automatically.
4. Do not disable screening to relieve backlog under any circumstance.

## Interfaces
Reads `sanctions_check` table (payments schema) and the sanctions provider status page.

## Dependencies
SanctionsService, PaymentDispatcher, compliance on-call rotation.
