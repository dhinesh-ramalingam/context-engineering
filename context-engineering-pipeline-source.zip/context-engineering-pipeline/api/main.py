"""Lightweight FastAPI review console — the four screens from KNOW-PIPE §07
(source config, run console, review queue, wiki explorer) as one small
JSON API + a vanilla-JS single page, not a React SPA. Functional and real:
every endpoint calls the same pipeline/ modules the CLI and MCP server use,
so there is exactly one implementation of every pipeline behavior.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from pipeline.governance.review_store import ReviewStore, SegregationOfDutiesError
from pipeline.governance.wiki_publish import WikiRepo
from pipeline.indexing import es_index
from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.models import ObjectStatus, ReviewDecisionAction, RunMode
from pipeline.orchestrator import approve_and_publish, refresh_conflict_check, run_pipeline
from pipeline.serving.context_builder import ContextBuilder
from pipeline.serving.coverage import capability_matrix, persona_coverage, product_country_matrix
from pipeline.serving.document_view import build_full_document
from pipeline.serving.prioritization import rank_entities

app = FastAPI(title="Context Engineering Pipeline")

STATIC_DIR = Path(__file__).resolve().parent / "static"


@app.get("/")
def index():
    return FileResponse(STATIC_DIR / "index.html")


app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# --- sources ---

@app.get("/api/sources")
def list_sources():
    from pipeline.connectors import CONNECTOR_REGISTRY
    from pipeline.orchestrator import _source_root
    out = []
    for source_type in CONNECTOR_REGISTRY:
        try:
            root = _source_root(source_type)
            conn = CONNECTOR_REGISTRY[source_type](connector_id=f"{source_type}-1", name=source_type, root=root)
            items = list(conn.list_items())
            out.append({"type": source_type, "root": str(root), "item_count": len(items), "connected": conn.connect()})
        except Exception as e:
            out.append({"type": source_type, "error": str(e)})
    return out


# --- pipeline runs ---

class RunRequest(BaseModel):
    mode: str = "full"
    reset: bool = False


@app.post("/api/runs")
def start_run(req: RunRequest):
    mode = RunMode.ISOLATED if req.mode == "isolated" else RunMode.FULL
    run = run_pipeline(mode=mode, reset=req.reset)
    return run.model_dump()


@app.get("/api/runs")
def list_runs():
    from pipeline.config import settings
    runs_dir = settings.data_dir / "runs"
    if not runs_dir.exists():
        return []
    out = []
    for p in sorted(runs_dir.glob("*.json"), reverse=True):
        out.append(__import__("json").loads(p.read_text(encoding="utf-8")))
    return out


# --- review queue ---

@app.get("/api/review")
def review_queue(status: str = "pending_review"):
    store = ReviewStore()
    items = store.list_candidates(status=ObjectStatus(status))
    out = []
    for c in items:
        conflicts = store.conflicts_for(c.id)
        out.append({
            "id": c.id, "title": c.title, "source_type": c.source_type.value,
            "gate_verdict": c.gate_verdict.value if c.gate_verdict else None,
            "entity_key": c.canonical_entity_key, "drift_flag": c.drift_flag,
            "near_duplicate_of": c.near_duplicate_of,
            "conflict_severity": max((x.severity for x in conflicts), default=None),
        })
    return out


@app.get("/api/review/{candidate_id}")
def review_detail(candidate_id: str):
    store = ReviewStore()
    obj = store.get_candidate(candidate_id)
    if obj is None:
        raise HTTPException(404, "not found")
    conflict = refresh_conflict_check(candidate_id)
    canonical = None
    if obj.canonical_entity_key:
        canonical = WikiRepo().get(obj.canonical_entity_key)
    return {
        "candidate": obj.model_dump(),
        "conflict": conflict.model_dump() if conflict else None,
        "canonical": canonical,
        "audit_log": store.audit_log(candidate_id),
    }


class DecisionRequest(BaseModel):
    reviewer: str
    action: str  # approve | reject | request_changes
    note: str = ""


@app.post("/api/review/{candidate_id}/decide")
def review_decide(candidate_id: str, req: DecisionRequest):
    try:
        result = approve_and_publish(candidate_id, reviewer=req.reviewer,
                                       action=ReviewDecisionAction(req.action), note=req.note)
    except SegregationOfDutiesError as e:
        raise HTTPException(400, str(e))
    except (KeyError, ValueError) as e:
        raise HTTPException(400, str(e))
    return result


# --- wiki ---

@app.get("/api/wiki")
def wiki_list():
    return WikiRepo().list_articles()


@app.get("/api/document/{entity_key}")
def full_document(entity_key: str):
    """Base article + everything that extends or relates to it, merged
    into one document — the answer to 'give me the whole picture for this
    entity', not a chunk list."""
    graph = GraphBuilder()
    try:
        doc = build_full_document(graph, WikiRepo(), entity_key)
    finally:
        graph.close()
    if doc is None:
        raise HTTPException(404, "no canonical article for this entity_key")
    return {
        "root_entity_key": doc.root_entity_key,
        "sections": [
            {"role": s.role, "entity_key": s.entity_key, "title": s.title, "body": s.body,
             "approved_by": s.approved_by, "version": s.version, "relationship": s.relationship}
            for s in doc.sections
        ],
        "merged_markdown": doc.merged_markdown,
    }


@app.get("/api/wiki/{entity_key}")
def wiki_get(entity_key: str):
    article = WikiRepo().get(entity_key)
    if article is None:
        raise HTTPException(404, "not found")
    article["history"] = WikiRepo().history(entity_key)
    return article


# --- context / query (same path the MCP server uses) ---

class QueryRequest(BaseModel):
    query: str
    agent_role: str
    intent: str | None = None
    top_k: int = 12
    session_id: str | None = None


@app.post("/api/context")
def get_context(req: QueryRequest):
    cb = ContextBuilder(env="production")
    try:
        bundle = cb.build(req.query, agent_role=req.agent_role, intent=req.intent, top_k=req.top_k,
                           session_id=req.session_id)
    finally:
        cb.close()
    return {
        "intent": bundle.intent, "intent_confidence": bundle.intent_confidence,
        "tokens_used": bundle.tokens_used, "token_budget": bundle.token_budget,
        "guardrail_clean": bundle.guardrail_clean, "guardrail_hits": bundle.guardrail_hits,
        "session_id": bundle.session_id,
        "items": [
            {"id": i.id, "title": i.title, "score": i.score, "source_type": i.source_type,
             "viewpoints": i.viewpoints, "entity_key": i.entity_key, "tag": i.tag, "provenance": i.provenance,
             "text": i.text, "already_seen": i.already_seen}
            for i in bundle.items
        ],
        "graph_notes": bundle.graph_notes,
        "assembled_text": bundle.assembled_text,
    }


@app.get("/api/session/{session_id}")
def get_session_summary(session_id: str):
    from pipeline.serving.session_memory import load_session_summary
    summary = load_session_summary(session_id)
    if summary is None:
        raise HTTPException(404, "session not found")
    return summary


# --- dependency / context trees ---

@app.get("/api/graph/roots")
def graph_roots():
    graph = GraphBuilder()
    try:
        return graph.list_roots()
    finally:
        graph.close()


@app.get("/api/graph/tree")
def graph_tree(label: str, key: str, depth: int = 3):
    graph = GraphBuilder()
    try:
        key_prop = "name" if label in ("Component",) else GraphBuilder._KEY_PROP_BY_LABEL.get(label, "key")
        return graph.dependency_tree(label, key_prop, key, max_depth=depth)
    finally:
        graph.close()


# --- coverage: persona document mapping + product/country matrix ---

@app.get("/api/coverage/personas")
def coverage_personas():
    from pipeline.config import settings
    client = es_index.get_client()
    return persona_coverage(client, settings.es_index_prod)


@app.get("/api/coverage/products")
def coverage_products():
    graph = GraphBuilder()
    try:
        return product_country_matrix(graph)
    finally:
        graph.close()


@app.get("/api/coverage/capabilities")
def coverage_capabilities():
    graph = GraphBuilder()
    try:
        return capability_matrix(graph)
    finally:
        graph.close()


# --- PM prioritization ---

@app.get("/api/prioritize")
def prioritize():
    store = ReviewStore()
    graph = GraphBuilder()
    from pipeline.extraction.entity_resolution import Glossary
    glossary = Glossary()
    entity_keys = {c.canonical_entity_key for c in store.list_candidates() if c.canonical_entity_key}
    entities = [
        {"entity_key": k, "label": glossary.label(k) or k, "component_name": graph.implemented_by_name(k)}
        for k in entity_keys
    ]
    ranked = rank_entities(graph, entities)
    graph.close()
    return [s.model_dump() for s in ranked]
