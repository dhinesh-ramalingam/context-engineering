import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.models import RunMode
from pipeline.orchestrator import run_pipeline

run = run_pipeline(mode=RunMode.FULL, reset=True)
print("run id:", run.id)
print("status:", run.status)
print("funnel:", run.funnel)
