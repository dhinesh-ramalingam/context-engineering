"""The pipeline orchestrator — runs every stage from KNOW-PIPE-2026-01 end to
end against the configured sources: connectors -> regime routing -> Tier 0/1
gate -> entity resolution -> drift detection -> Tier 2 LLM structuring for
the narrative regime; direct parse + graph-build for the structured regime;
aggregate + graph-build for the telemetry regime. Isolated runs write to a
'staging' env tag across both Elasticsearch and Neo4j; Full runs write to
'production' directly for narrative candidates only after Human Review
approves them — structured/telemetry content is 'correct by construction'
(KNOW-EXTRACT §03) and is indexed immediately without a review gate.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Optional

from pipeline.config import settings
from pipeline.connectors import CONNECTOR_REGISTRY
from pipeline.extraction.ace_playbook import Playbook, pattern_signature
from pipeline.extraction.drift_detection import check_api_drift, check_data_model_drift
from pipeline.extraction.entity_resolution import Glossary, resolve_entity
from pipeline.extraction.guardrails import scan_inbound
from pipeline.extraction.regimes import normalize_narrative
from pipeline.extraction.tier0_gate import evaluate_tier0, gate_version
from pipeline.extraction.tier1_statistical import Bm25Corpus, DOMAIN_LEXICON, find_near_duplicates
from pipeline.extraction.tier2_llm import structure_candidate
from pipeline.extraction.conflict_scoring import score_conflict
from pipeline.governance.review_store import ReviewStore
from pipeline.governance.wiki_publish import WikiRepo
from pipeline.indexing import es_index
from pipeline.indexing.embeddings import get_default_cache
from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.models import (
    SOURCE_DEFAULT_VIEWPOINTS,
    CandidateKnowledgeObject,
    ConflictRecord,
    GateVerdict,
    ObjectStatus,
    PipelineRun,
    ReviewDecisionAction,
    RunMode,
    RunStatus,
    SourceType,
    now_iso,
)
from pipeline.serving.chunking import structural_truncate
from pipeline.watermarks import WatermarkStore, is_newer

NARRATIVE_TYPES = ["ado", "confluence", "runbook", "product_catalog"]
CONFLICT_SEVERITY_THRESHOLD = 0.2


def _connector(source_type: str, root: Path):
    cls = CONNECTOR_REGISTRY[source_type]
    return cls(connector_id=f"{source_type}-1", name=source_type, root=root)


def _source_root(source_type: str) -> Path:
    dirs = {
        "ado": settings.mock_sources_dir / "ado",
        "confluence": settings.mock_sources_dir / "confluence",
        "git": settings.mock_sources_dir / "git_payments_core",
        "db_schema": settings.mock_sources_dir / "db_schema",
        "swagger": settings.mock_sources_dir / "swagger",
        "plantuml": settings.mock_sources_dir / "plantuml",
        "runbook": settings.mock_sources_dir / "runbooks",
        "logs": settings.mock_sources_dir / "logs",
        "product_catalog": settings.mock_sources_dir / "product_catalog",
    }
    return dirs[source_type]


def _stable_doc_id(obj: CandidateKnowledgeObject) -> str:
    """A candidate's own id is a fresh random uuid every time the pipeline
    re-extracts the *same* underlying source item — re-running ingestion
    (an isolated run, a re-run without --reset) must not create a second
    Elasticsearch document for a source that's already indexed. The
    Elasticsearch doc id is therefore derived from the source identity
    (type + connector + native item id), which is stable across re-runs,
    not from the candidate wrapper's id. Neo4j gets this for free via
    MERGE on business keys; this is the equivalent for the ES side."""
    source_type_val = obj.source_type.value if hasattr(obj.source_type, "value") else obj.source_type
    raw = f"{source_type_val}:{obj.source_connector_id}:{obj.source_item_id}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]


def _index_object(obj: CandidateKnowledgeObject, cache, es_client, idx_name: str,
                   approved_by: str = "", version: int = 1) -> None:
    text_for_embedding = f"{obj.title}\n{obj.summary or ''}\n{obj.body[:2000]}"
    vector, content_hash, _ = cache.get_or_embed(text_for_embedding)
    source_type_val = obj.source_type.value if hasattr(obj.source_type, "value") else obj.source_type
    fields = {
        "title": obj.title, "body": structural_truncate(obj.body, 8000), "summary": obj.summary or "",
        "source_type": source_type_val,
        "doc_type": obj.source_metadata.get("doc_type", ""),
        "viewpoints": obj.viewpoints, "entity_key": obj.canonical_entity_key,
        "product_code": obj.product_code, "product_scope": obj.product_scope,
        "product_variant_key": obj.product_variant_key,
        "approved_by": approved_by, "version": version,
        "content_hash": content_hash, "candidate_id": obj.id,
    }
    es_index.upsert(es_client, idx_name, _stable_doc_id(obj), fields, vector)


def reset_all(env: str) -> None:
    """Clears pipeline-generated state for a clean, repeatable run. Never
    touches mock_sources/ (raw input) or the embedding cache (content-hash
    keyed, safe to reuse across runs)."""
    for d in ("candidates", "conflicts", "review_decisions"):
        p = settings.data_dir / d
        if p.exists():
            for f in p.glob("*.json"):
                f.unlink()
    audit = settings.data_dir / "audit_log.jsonl"
    if audit.exists():
        audit.unlink()
    WatermarkStore().clear()

    import os
    import shutil
    import stat

    def _on_rm_error(func, path, exc_info):
        # git objects are written read-only on Windows; clear that before retrying
        os.chmod(path, stat.S_IWRITE)
        func(path)

    if settings.wiki_repo_dir.exists():
        shutil.rmtree(settings.wiki_repo_dir, onerror=_on_rm_error)

    es_client = es_index.get_client()
    for idx in (settings.es_index_prod, settings.es_index_staging):
        es_client.options(ignore_status=[404]).indices.delete(index=idx)

    graph = GraphBuilder()
    graph.wipe_env("production")
    graph.wipe_env("staging")
    graph.close()


def run_pipeline(mode: RunMode = RunMode.FULL, reset: bool = False, incremental: bool = False) -> PipelineRun:
    """incremental=True skips narrative items whose `updated` timestamp is
    not newer than that source's stored watermark — the expensive part of
    a re-run (Tier 2 LLM structuring, conflict scoring, embeddings) only
    ever touches what's actually new or changed. Structured/telemetry
    sources are always reprocessed regardless (cheap, parse-only, and
    idempotent since the ES dedup and Neo4j (key, env) identity fixes)."""
    env = "staging" if mode == RunMode.ISOLATED else "production"
    if reset:
        reset_all(env)

    run = PipelineRun(mode=mode, status=RunStatus.RUNNING)
    funnel = {
        "raw_narrative_docs": 0, "blocked": 0, "ignored": 0, "tier0_survivors": 0,
        "tier1_survivors": 0, "tier2_candidates": 0, "structured_objects": 0,
        "telemetry_signatures": 0,
    }

    store = ReviewStore()
    glossary = Glossary()
    playbook = Playbook()
    graph = GraphBuilder()
    graph.ensure_constraints()
    es_client = es_index.get_client()
    idx_name = es_index.index_name_for(env)
    es_index.ensure_index(es_client, idx_name)
    cache = get_default_cache()
    embed_fn = lambda text: cache.get_or_embed(text)[0]

    class_key_by_name: dict[str, str] = {}
    schema_tables: list[dict] = []
    swagger_endpoints: list[dict] = []

    # ---------------------------------------------------------------
    # Structured regime — parsed, not graded (KNOW-EXTRACT §03). Order
    # matters: db_schema and swagger must run before git (git links
    # DEPENDS_ON/READS_WRITES against nodes they create) and before the
    # narrative loop (drift detection needs both as source-of-truth).
    # ---------------------------------------------------------------
    db_conn = _connector("db_schema", _source_root("db_schema"))
    for item_id in db_conn.list_items():
        raw = db_conn.fetch(item_id)
        schema_name = raw.content["schema"]
        for t in raw.content["tables"]:
            table_key = f"{schema_name}:{t['name']}"
            graph.upsert_db_table(table_key, schema_name, t["name"], t["columns"], env=env)
            schema_tables.append(t)
        obj = CandidateKnowledgeObject(
            source_connector_id=db_conn.connector_id, source_type=SourceType.DATABASE, source_item_id=item_id,
            source_updated=raw.updated, title=f"{schema_name} — database schema", body=json.dumps(raw.content, indent=2)[:6000],
            viewpoints=SOURCE_DEFAULT_VIEWPOINTS["db_schema"], status=ObjectStatus.APPROVED,
            gate_verdict=GateVerdict.CANDIDATE, gate_version=gate_version(),
            summary=f"{schema_name} schema — {len(raw.content['tables'])} tables introspected live.",
            dependencies=[t["name"] for t in raw.content["tables"]], run_id=run.id,
        )
        store.save_candidate(obj)
        _index_object(obj, cache, es_client, idx_name, approved_by="system:parsed", version=1)
        funnel["structured_objects"] += 1

    swagger_conn = _connector("swagger", _source_root("swagger"))
    for item_id in swagger_conn.list_items():
        raw = swagger_conn.fetch(item_id)
        swagger_endpoints = raw.content["endpoints"]
        title = raw.content["title"]
        match = resolve_entity(title, "", glossary)
        obj = CandidateKnowledgeObject(
            source_connector_id=swagger_conn.connector_id, source_type=SourceType.SWAGGER, source_item_id=item_id,
            source_updated=raw.updated, title=title,
            body="\n".join(f"{e['method']} {e['path']}{' (DEPRECATED)' if e['deprecated'] else ''} — {e['description']}" for e in swagger_endpoints),
            viewpoints=SOURCE_DEFAULT_VIEWPOINTS["swagger"], canonical_entity_key=match.entity_key,
            entity_match_method=match.method, status=ObjectStatus.APPROVED,
            gate_verdict=GateVerdict.CANDIDATE, gate_version=gate_version(),
            interfaces=[f"{e['method']} {e['path']}" for e in swagger_endpoints],
            summary=f"{title} — {len(swagger_endpoints)} live endpoints.", run_id=run.id,
        )
        store.save_candidate(obj)
        _index_object(obj, cache, es_client, idx_name, approved_by="system:parsed", version=1)
        funnel["structured_objects"] += 1
        if match.entity_key:
            graph.upsert_entity(match.entity_key, glossary.label(match.entity_key) or match.entity_key,
                                  match.entity_key.split(".")[0], env=env)

    plant_conn = _connector("plantuml", _source_root("plantuml"))
    for item_id in plant_conn.list_items():
        raw = plant_conn.fetch(item_id)
        for comp in raw.content["components"]:
            kind = "queue" if "kafka" in comp.lower() or "topic" in comp.lower() else (
                "actor" if comp.lower() in ("regulator",) else "component")
            graph.upsert_component(comp, kind=kind, env=env)
        for edge in raw.content["edges"]:
            graph.link_component_flow(edge["from"], edge["to"], edge["label"], env=env)
        obj = CandidateKnowledgeObject(
            source_connector_id=plant_conn.connector_id, source_type=SourceType.PLANTUML, source_item_id=item_id,
            source_updated="", title=f"Architecture diagram — {item_id}", body=raw.content["raw"],
            viewpoints=SOURCE_DEFAULT_VIEWPOINTS["plantuml"], status=ObjectStatus.APPROVED,
            gate_verdict=GateVerdict.CANDIDATE, gate_version=gate_version(),
            dependencies=raw.content["components"],
            summary=f"{len(raw.content['components'])} components, {len(raw.content['edges'])} flows.", run_id=run.id,
        )
        store.save_candidate(obj)
        _index_object(obj, cache, es_client, idx_name, approved_by="system:parsed", version=1)
        funnel["structured_objects"] += 1

    git_conn = _connector("git", _source_root("git"))
    git_items = list(git_conn.list_items())
    parsed_java = {}
    for item_id in git_items:
        if item_id.endswith(".java"):
            raw = git_conn.fetch(item_id)
            parsed_java[item_id] = raw
            for cls in raw.content.get("classes", []):
                class_key_by_name[cls] = f"payments-core:{cls}"

    for cls, key in class_key_by_name.items():
        raw = next(r for item_id, r in parsed_java.items() if cls in r.content.get("classes", []))
        graph.upsert_code_class(key, cls, raw.content.get("package"), "payments-core", raw.content["path"], env=env)
        # link to entity via glossary if the class name resolves (e.g. SanctionsService -> payments.sanctions_screening)
        match = resolve_entity(cls, "", glossary)
        if match.entity_key:
            graph.link_entity_to_code(match.entity_key, key, env=env)

    for item_id, raw in parsed_java.items():
        for cls in raw.content.get("classes", []):
            key = class_key_by_name[cls]
            for imp in raw.content.get("imports", []):
                imp_simple = imp.split(".")[-1]
                if imp_simple in class_key_by_name and imp_simple != cls:
                    graph.link_code_depends_on(key, class_key_by_name[imp_simple], env=env)
            for dbt in raw.content.get("db_tables", []):
                table_name = dbt["table"].split(".")[-1]
                table_key = f"payments:{table_name}"
                graph.link_code_reads_writes(key, table_key, dbt["modes"], env=env)

        guardrail = scan_inbound(raw.content.get("text", ""))
        if guardrail.blocked:
            continue  # code can carry secrets too — same hard block applies
        obj = CandidateKnowledgeObject(
            source_connector_id=git_conn.connector_id, source_type=SourceType.GIT, source_item_id=item_id,
            source_updated=raw.updated, title=Path(item_id).name, body=raw.content.get("text", "")[:6000],
            viewpoints=SOURCE_DEFAULT_VIEWPOINTS["git"], status=ObjectStatus.APPROVED,
            gate_verdict=GateVerdict.CANDIDATE, gate_version=gate_version(),
            dependencies=raw.content.get("imports", [])[:8],
            summary=f"Source file {item_id}" + (f" — classes: {', '.join(raw.content.get('classes', []))}" if raw.content.get("classes") else ""),
            run_id=run.id,
        )
        store.save_candidate(obj)
        _index_object(obj, cache, es_client, idx_name, approved_by="system:parsed", version=1)
        funnel["structured_objects"] += 1

    for item_id in git_items:
        if item_id == "README.md":
            raw = git_conn.fetch(item_id)
            obj = CandidateKnowledgeObject(
                source_connector_id=git_conn.connector_id, source_type=SourceType.GIT, source_item_id=item_id,
                source_updated=raw.updated, title="payments-core README", body=raw.content.get("text", ""),
                viewpoints=[SOURCE_DEFAULT_VIEWPOINTS["git"][0], "business_domain"], status=ObjectStatus.APPROVED,
                gate_verdict=GateVerdict.CANDIDATE, gate_version=gate_version(),
                summary="payments-core module README — conventions and module overview.", run_id=run.id,
            )
            store.save_candidate(obj)
            _index_object(obj, cache, es_client, idx_name, approved_by="system:parsed", version=1)
            funnel["structured_objects"] += 1

    # ---------------------------------------------------------------
    # Telemetry regime — aggregated, never scored per-line (KNOW-EXTRACT §03)
    # ---------------------------------------------------------------
    logs_conn = _connector("logs", _source_root("logs"))
    for item_id in logs_conn.list_items():
        raw = logs_conn.fetch(item_id)
        for sig in raw.content["signatures"]:
            key = f"{item_id}:{sig['component']}:{sig['reason']}"
            graph.upsert_incident_signature(key, sig["component"], sig["reason"], sig["count"],
                                              sig["first_seen"], sig["last_seen"], env=env)
            funnel["telemetry_signatures"] += 1
        obj = CandidateKnowledgeObject(
            source_connector_id=logs_conn.connector_id, source_type=SourceType.LOG, source_item_id=item_id,
            source_updated="", title=raw.content["title"], body=json.dumps(raw.content["signatures"], indent=2),
            viewpoints=SOURCE_DEFAULT_VIEWPOINTS["logs"], status=ObjectStatus.APPROVED,
            gate_verdict=GateVerdict.CANDIDATE, gate_version=gate_version(),
            summary=f"{len(raw.content['signatures'])} error-signature clusters from {raw.content['raw_line_count']} raw lines.",
            run_id=run.id,
        )
        store.save_candidate(obj)
        _index_object(obj, cache, es_client, idx_name, approved_by="system:aggregated", version=1)
        funnel["structured_objects"] += 1

    # ---------------------------------------------------------------
    # Narrative regime — the full Tier 0 / Tier 1 / drift / entity-
    # resolution / Tier 2 cascade (KNOW-EXTRACT §04-§08)
    # ---------------------------------------------------------------
    normalized_docs = []
    connector_by_type = {}
    watermarks = WatermarkStore()
    max_updated_seen: dict[str, str] = {}
    skipped_unchanged = 0
    for source_type in NARRATIVE_TYPES:
        conn = _connector(source_type, _source_root(source_type))
        connector_by_type[source_type] = conn
        source_watermark = watermarks.get(source_type) if incremental else None
        for item_id in conn.list_items():
            raw = conn.fetch(item_id)
            if raw.updated and raw.updated > max_updated_seen.get(source_type, ""):
                max_updated_seen[source_type] = raw.updated
            if incremental and not is_newer(raw.updated, source_watermark):
                skipped_unchanged += 1
                continue
            doc = normalize_narrative(raw, source_type, conn.connector_id)
            normalized_docs.append(doc)
            funnel["raw_narrative_docs"] += 1
    funnel["skipped_unchanged_since_watermark"] = skipped_unchanged

    tier0_survivors = []
    for doc in normalized_docs:
        verdict, conditions = evaluate_tier0(doc)
        if verdict == GateVerdict.BLOCKED:
            funnel["blocked"] += 1
            continue
        if verdict == GateVerdict.IGNORED:
            funnel["ignored"] += 1
            continue
        funnel["tier0_survivors"] += 1
        tier0_survivors.append((doc, verdict, conditions))

    corpus = Bm25Corpus.build([d.body_markdown for d, _, _ in tier0_survivors])
    tier1_survivors = []
    for doc, verdict, conditions in tier0_survivors:
        score = corpus.score(doc.body_markdown, DOMAIN_LEXICON)
        if score < settings.bm25_relevance_floor:
            continue
        tier1_survivors.append((doc, verdict, conditions, score))
    funnel["tier1_survivors"] = len(tier1_survivors)

    dup_pairs = find_near_duplicates([(d.source_item_id, d.body_markdown) for d, _, _, _ in tier1_survivors])
    near_dup_of = {b: a for a, b, _ in dup_pairs}

    wiki = WikiRepo()
    for doc, verdict, conditions, relevance in tier1_survivors:
        match = resolve_entity(doc.title, doc.body_markdown, glossary, embed_fn=embed_fn)

        # ACE — offer the playbook's learned strategy for this document's
        # pattern, if one has accumulated (extraction/ace_playbook.py)
        signature = pattern_signature(doc, conditions[2].signal or 0, conditions[3].signal or 0)
        playbook_entry = playbook.match(signature)
        if playbook_entry:
            playbook.mark_matched(playbook_entry.id)

        structured = structure_candidate(
            doc.title, doc.body_markdown, doc.doc_type, SOURCE_DEFAULT_VIEWPOINTS.get(doc.source_type, []),
            playbook_hint=playbook_entry.strategy_text if playbook_entry else None,
        )

        api_finding = check_api_drift(doc.body_markdown, swagger_endpoints)
        dm_finding = check_data_model_drift(doc.body_markdown, schema_tables)
        drift_flag = api_finding.drift or dm_finding.drift
        drift_detail = "; ".join(x for x in [
            api_finding.detail if api_finding.drift else None,
            dm_finding.detail if dm_finding.drift else None,
        ] if x) or None

        obj = CandidateKnowledgeObject(
            source_connector_id=connector_by_type[doc.source_type].connector_id, source_type=doc.source_type,
            source_item_id=doc.source_item_id, source_updated=doc.updated, title=doc.title, body=doc.body_markdown,
            raw_excerpt=doc.body_markdown[:300],
            viewpoints=structured["viewpoints"], canonical_entity_key=match.entity_key,
            entity_match_method=match.method, confidence=0.9 if verdict == GateVerdict.CANDIDATE else 0.6,
            status=ObjectStatus.DRAFT, gate_verdict=verdict, gate_conditions=conditions, gate_version=gate_version(),
            relevance_score=relevance, near_duplicate_of=near_dup_of.get(doc.source_item_id),
            drift_flag=drift_flag, drift_detail=drift_detail,
            purpose=structured["purpose"], interfaces=structured["interfaces"], constraints=structured["constraints"],
            business_rules=structured["business_rules"], open_questions=structured["open_questions"],
            dependencies=structured["dependencies"], summary=structured["summary"],
            product_code=doc.extra.get("product_code"), product_scope=doc.extra.get("scope"),
            product_variant_key=doc.extra.get("variant_key"), product_domain=doc.extra.get("domain"),
            product_family=doc.extra.get("family"), capabilities=doc.extra.get("capabilities") or [],
            product_country=doc.extra.get("country"),
            source_metadata={"doc_type": doc.doc_type, "status": doc.status, "owner": doc.owner or "", "labels": doc.labels},
            ace_pattern_signature=signature, ace_playbook_entry_id=playbook_entry.id if playbook_entry else None,
            run_id=run.id,
        )
        store.save_candidate(obj)
        store.submit_for_review(obj.id)
        funnel["tier2_candidates"] += 1

        if match.entity_key:
            canonical = wiki.get(match.entity_key)
            if canonical:
                conflict = score_conflict(obj.body, canonical["body"])
                if conflict["severity"] >= CONFLICT_SEVERITY_THRESHOLD:
                    store.save_conflict(ConflictRecord(
                        candidate_id=obj.id, canonical_id=match.entity_key,
                        severity=conflict["severity"], rationale=conflict["rationale"],
                    ))

        if doc.source_type == "ado":
            graph.upsert_work_item(
                id=doc.source_item_id, title=doc.title, item_type=doc.doc_type, state=doc.status,
                entity_key=match.entity_key, env=env,
            )

    for source_type, updated in max_updated_seen.items():
        watermarks.set(source_type, updated)

    run.status = RunStatus.AWAITING_REVIEW
    run.funnel = funnel
    run.finished_at = now_iso()
    graph.close()

    runs_dir = settings.data_dir / "runs"
    runs_dir.mkdir(parents=True, exist_ok=True)
    (runs_dir / f"{run.id}.json").write_text(run.model_dump_json(indent=2), encoding="utf-8")
    return run


def refresh_conflict_check(candidate_id: str) -> Optional[ConflictRecord]:
    """Re-checks a pending candidate against the *current* wiki state.
    Conflict scoring at ingestion time only catches a contradiction if the
    canonical article already existed when the candidate was extracted —
    but review is asynchronous, so by the time a checker opens an item, a
    canonical article may have been approved and published since. Called
    right before a reviewer sees the item (CLI `review show`, API GET), not
    just once at ingestion."""
    store = ReviewStore()
    wiki = WikiRepo()
    obj = store.get_candidate(candidate_id)
    if obj is None or not obj.canonical_entity_key:
        return None
    canonical = wiki.get(obj.canonical_entity_key)
    if not canonical:
        return None
    existing = store.conflicts_for(candidate_id)
    conflict = score_conflict(obj.body, canonical["body"])
    if conflict["severity"] < CONFLICT_SEVERITY_THRESHOLD:
        return existing[0] if existing else None
    record = ConflictRecord(
        candidate_id=candidate_id, canonical_id=obj.canonical_entity_key,
        severity=conflict["severity"], rationale=conflict["rationale"],
    )
    store.save_conflict(record)
    return record


def ace_scan(min_cluster_size: int = 2) -> dict:
    """ACE Generation phase, run standalone: scans every narrative source
    (in a real deployment, this is the 'large volume of ADO epics/stories
    and Confluence pages' pass) through Tier 0/1 only — no Tier 2, no LLM
    structuring cost yet — clusters survivors by pattern signature, and
    proposes a new playbook strategy for any cluster of at least
    `min_cluster_size` documents that doesn't already have one. Safe to
    run repeatedly and cheaply, same as Tier 0/1 always have been (KNOW-
    PIPE §02): only clusters without an existing entry pay an LLM call,
    and only once per cluster, not once per document."""
    glossary = Glossary()
    playbook = Playbook()

    normalized_docs: list = []
    connector_by_type = {}
    for source_type in NARRATIVE_TYPES:
        conn = _connector(source_type, _source_root(source_type))
        connector_by_type[source_type] = conn
        for item_id in conn.list_items():
            raw = conn.fetch(item_id)
            normalized_docs.append(normalize_narrative(raw, source_type, conn.connector_id))

    survivors = []
    for doc in normalized_docs:
        verdict, conditions = evaluate_tier0(doc)
        if verdict in (GateVerdict.BLOCKED, GateVerdict.IGNORED):
            continue
        survivors.append((doc, conditions))

    clusters: dict[str, list] = {}
    for doc, conditions in survivors:
        sig = pattern_signature(doc, conditions[2].signal or 0, conditions[3].signal or 0)
        clusters.setdefault(sig, []).append(doc)

    report = {"clusters_found": len(clusters), "documents_scanned": len(normalized_docs),
              "survivors": len(survivors), "new_strategies_proposed": [], "existing_strategies": [],
              "below_cluster_threshold": []}

    for sig, docs in clusters.items():
        existing = playbook.by_signature(sig)
        if existing:
            report["existing_strategies"].append({"signature": sig, "count": len(docs), "entries": len(existing)})
            continue
        if len(docs) < min_cluster_size:
            report["below_cluster_threshold"].append({"signature": sig, "count": len(docs)})
            continue
        entry = playbook.propose(sig, docs)
        report["new_strategies_proposed"].append({"signature": sig, "count": len(docs), "entry_id": entry.id,
                                                     "strategy": entry.strategy_text})
    return report


def approve_and_publish(candidate_id: str, reviewer: str, action: ReviewDecisionAction, note: str = "",
                          env: str = "production") -> dict:
    """The Human Review -> Publish -> Index path (KNOW-PIPE §05-§08) for one
    narrative candidate. Approve triggers glossary write-back (if the match
    was fuzzy/embedding), wiki publish, canonical-article graph nodes,
    product-hierarchy linking, and ES indexing into the governed index — all
    in one place so the CLI, API, and MCP server share the exact same path."""
    store = ReviewStore()
    wiki = WikiRepo()
    glossary = Glossary()
    graph = GraphBuilder()

    obj = store.get_candidate(candidate_id)
    if obj is None:
        raise KeyError(candidate_id)

    # Always re-check for a conflict against the *current* wiki state before
    # deciding — not just when the caller happened to view the item first
    # (CLI `review show` / API GET). A programmatic or scripted decision
    # must not silently skip the same check a human reviewer would trigger.
    refresh_conflict_check(candidate_id)

    canonical = wiki.get(obj.canonical_entity_key) if obj.canonical_entity_key else None
    canonical_text = canonical["body"] if canonical else None
    decision = store.decide(candidate_id, reviewer=reviewer, action=action, note=note, canonical_text=canonical_text)

    # ACE Reflection phase — this decision is the ground truth for whether
    # the playbook entry (if any) that guided this candidate's extraction
    # actually helped. Recorded regardless of approve/reject/changes so
    # `ace curate` has real sample counts to promote or retire against.
    if obj.ace_playbook_entry_id:
        Playbook().record_outcome(obj.ace_playbook_entry_id, action)

    result: dict = {"decision": decision.model_dump()}

    if action == ReviewDecisionAction.APPROVE:
        if obj.entity_match_method in ("fuzzy", "embedding") and obj.canonical_entity_key:
            glossary.add_alias(obj.canonical_entity_key, obj.title)

        publish_result = None
        if obj.canonical_entity_key:
            publish_result = wiki.publish(obj, approved_by=reviewer)
            entity_label = glossary.label(obj.canonical_entity_key) or obj.canonical_entity_key
            graph.upsert_entity(obj.canonical_entity_key, entity_label, obj.canonical_entity_key.split(".")[0], env=env)
            for vp in obj.viewpoints:
                graph.upsert_viewpoint(vp, env=env)
            graph.upsert_canonical_article(
                obj.canonical_entity_key, obj.title, publish_result["version"],
                obj.source_type.value if hasattr(obj.source_type, "value") else obj.source_type,
                obj.viewpoints, reviewer, env=env,
            )
            if obj.product_code and obj.product_scope:
                base_key = obj.canonical_entity_key.rsplit(".", 1)[0] if obj.product_scope == "variant" else None
                graph.upsert_product(obj.canonical_entity_key, obj.product_code, obj.product_domain or "",
                                       obj.product_scope, obj.product_variant_key, base_key, env=env,
                                       family=obj.product_family, country=obj.product_country)
                graph.link_article_to_product(obj.canonical_entity_key, obj.canonical_entity_key, env=env)
                for cap in obj.capabilities:
                    sub_type, direction = cap.get("sub_type"), cap.get("direction")
                    if not sub_type or not direction:
                        continue
                    cap_key = f"{obj.canonical_entity_key}:{sub_type}:{direction}"
                    graph.upsert_capability(cap_key, obj.canonical_entity_key, sub_type, direction, env=env)
            result["publish"] = publish_result

        es_client = es_index.get_client()
        idx_name = es_index.index_name_for(env)
        es_index.ensure_index(es_client, idx_name)
        cache = get_default_cache()
        _index_object(obj, cache, es_client, idx_name, approved_by=reviewer,
                        version=publish_result["version"] if publish_result else 1)
        result["indexed"] = True

    graph.close()
    return result
