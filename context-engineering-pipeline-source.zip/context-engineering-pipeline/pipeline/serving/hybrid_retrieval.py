"""Context-Engineering-Platform-Design Layer 04 — Hybrid Retrieval + Rerank.

A fast hybrid recall pass fusing BM25 lexical search with dense vector
search via Reciprocal Rank Fusion, standard shape for production retrieval:
lexical search alone misses paraphrases, dense search alone misses exact
identifiers (a class name, a UETR-shaped token) — fusing both recovers what
either misses alone. Per-factor contribution is logged on every hit so "why
was this in the context" has a logged answer, not a reconstruction after
the fact.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class FusedHit:
    id: str
    fused_score: float
    bm25_rank: int | None
    dense_rank: int | None
    bm25_score: float | None
    dense_score: float | None
    source: dict[str, Any] = field(default_factory=dict)
    rerank_rationale: str | None = None  # set by serving/rerank.py when the LLM rerank pass runs


def reciprocal_rank_fusion(bm25_hits: list[dict], dense_hits: list[dict], k: int = 60) -> list[FusedHit]:
    bm25_rank = {h["id"]: (i + 1, h["score"]) for i, h in enumerate(bm25_hits)}
    dense_rank = {h["id"]: (i + 1, h["score"]) for i, h in enumerate(dense_hits)}
    by_id: dict[str, dict] = {h["id"]: h for h in bm25_hits}
    for h in dense_hits:
        by_id.setdefault(h["id"], h)

    fused: list[FusedHit] = []
    for doc_id, doc in by_id.items():
        b_rank, b_score = bm25_rank.get(doc_id, (None, None))
        d_rank, d_score = dense_rank.get(doc_id, (None, None))
        score = 0.0
        if b_rank is not None:
            score += 1.0 / (k + b_rank)
        if d_rank is not None:
            score += 1.0 / (k + d_rank)
        fused.append(FusedHit(
            id=doc_id, fused_score=score, bm25_rank=b_rank, dense_rank=d_rank,
            bm25_score=b_score, dense_score=d_score, source=doc,
        ))
    fused.sort(key=lambda h: -h.fused_score)
    return fused
