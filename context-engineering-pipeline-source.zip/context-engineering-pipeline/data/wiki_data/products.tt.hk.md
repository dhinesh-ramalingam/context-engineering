---
title: TT — Hong Kong (Cross-Border Telegraphic Transfer)
entity_key: products.tt.hk
source_type: product_catalog
source_ref: product_catalog-1:PROD-TT-HK
candidate_id: cko-8b7b3e64198f
viewpoints: [business_domain, business_process, regulatory_product]
version: 1
approved_by: S. Idris
published_at: 2026-08-16T20:34:13.895092+00:00
status: Active
---

# TT — Hong Kong (Cross-Border Telegraphic Transfer)

## Summary
This document outlines rules for initiating outward cross-border wire transfers from a Hong Kong account via SWIFT, including sanctions checks and dual-currency handling.

## Purpose
Defines the platform's rules for outward cross-border wire transfers (TT) via SWIFT from a Hong Kong-domiciled account. Inward TT for Hong Kong is not yet onboarded on this platform — outward-only today.

## Interfaces
- CrossBorderWireRequest

## Business Rules
- - Outward TT is initiated from a customer channel and requires full beneficiary bank details plus sanctions screening before release to SWIFT, same discipline as the Singapore TT product.
- - Dual-currency operational awareness (HKD and CNY) applies, consistent with the FPS — Hong Kong product's currency handling.

## Dependencies
- SWIFT messaging gateway
- sanctions screening

## Open Questions
- Inward TT onboarding for Hong Kong is on the roadmap but not yet scoped — do not assume symmetry with the Singapore TT product's inward support.

## Source Content
# TT — Hong Kong (Cross-Border Telegraphic Transfer)

## Purpose
Defines the platform's rules for outward cross-border wire transfers (TT) via SWIFT from a Hong Kong-domiciled account. Inward TT for Hong Kong is not yet onboarded on this platform — outward-only today.

## Scope
Applies to outward cross-border TT/wire payments in any supported currency, sent via SWIFT from Hong Kong.

## Business Rules
- Outward TT is initiated from a customer channel and requires full beneficiary bank details plus sanctions screening before release to SWIFT, same discipline as the Singapore TT product.
- Dual-currency operational awareness (HKD and CNY) applies, consistent with the FPS — Hong Kong product's currency handling.

## Interfaces
`CrossBorderWireRequest` (HK) — `payerAccount`, `beneficiaryBic`, `beneficiaryAccountOrIban`, `amountMinorUnits`, `currency`.

## Dependencies
SWIFT messaging gateway, sanctions screening.

## Open Questions
Inward TT onboarding for Hong Kong is on the roadmap but not yet scoped — do not assume symmetry with the Singapore TT product's inward support.

