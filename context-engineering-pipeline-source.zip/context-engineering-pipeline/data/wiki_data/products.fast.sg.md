---
title: FAST — Singapore (Instant Payment Rail)
entity_key: products.fast.sg
source_type: product_catalog
source_ref: product_catalog-1:PROD-FAST-SG
candidate_id: cko-7fd4b8143059
viewpoints: [business_domain, business_process, regulatory_product]
version: 1
approved_by: R. Tan
published_at: 2026-08-16T20:34:11.304936+00:00
status: Active
---

# FAST — Singapore (Instant Payment Rail)

## Summary
This document serves as a product-catalog entry for Singapore's FAST scheme, detailing real-time credit and dependencies without duplicating operational content.

## Purpose
Product-catalog entry for Singapore's FAST (Fast And Secure Transfers) scheme — the same real-world rail described operationally in the Payments architecture and business-rule articles elsewhere in this knowledge base (cut-off handling, sanctions screening). This entry exists so FAST is discoverable alongside the other national instant-payment schemes in the same family, not to duplicate that content.

## Business Rules
- Real-time, irrevocable credit to the beneficiary account, settled via MAS's FAST infrastructure.
- Same-day cut-off and peak-period handling are defined in the FAST Payment cut-off & peak handling article — this entry does not restate them.

## Dependencies
- PaymentDispatcher
- SanctionsService
- the payments.settlement Kafka topic

## Source Content
# FAST — Singapore (Instant Payment Rail)

## Purpose
Product-catalog entry for Singapore's FAST (Fast And Secure Transfers) scheme — the same real-world rail described operationally in the Payments architecture and business-rule articles elsewhere in this knowledge base (cut-off handling, sanctions screening). This entry exists so FAST is discoverable alongside the other national instant-payment schemes in the same family, not to duplicate that content.

## Scope
Applies to retail instant transfers between participating Singapore banks and e-wallets via FAST.

## Business Rules
- Real-time, irrevocable credit to the beneficiary account, settled via MAS's FAST infrastructure.
- Same-day cut-off and peak-period handling are defined in the FAST Payment cut-off & peak handling article — this entry does not restate them.

## Dependencies
PaymentDispatcher, SanctionsService, the payments.settlement Kafka topic.

## Glossary
FAST — Fast And Secure Transfers, Singapore's national instant retail payment scheme, operated under MAS.

