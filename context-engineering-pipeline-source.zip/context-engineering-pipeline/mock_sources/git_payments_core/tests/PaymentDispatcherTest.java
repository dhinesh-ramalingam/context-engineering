package com.payments.core;

import com.payments.core.sanctions.SanctionsService;
import com.payments.core.sanctions.ScreeningResult;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

class PaymentDispatcherTest {

    @Test
    void dispatchRejectsOnSanctionsHit() {
        SanctionsService sanctions = Mockito.mock(SanctionsService.class);
        Mockito.when(sanctions.screen(Mockito.any())).thenReturn(ScreeningResult.hit("SANCTIONS_MATCH"));
        SettlementPublisher publisher = Mockito.mock(SettlementPublisher.class);
        PaymentDispatcher dispatcher = new PaymentDispatcher(sanctions, publisher);

        DispatchResult result = dispatcher.dispatch(PaymentRequest.sample());

        assertTrue(result.isRejected());
        Mockito.verifyNoInteractions(publisher);
    }

    @Test
    void dispatchEscalatesOnScreeningTimeout() {
        SanctionsService sanctions = Mockito.mock(SanctionsService.class);
        Mockito.when(sanctions.screen(Mockito.any())).thenReturn(ScreeningResult.timeout());
        SettlementPublisher publisher = Mockito.mock(SettlementPublisher.class);
        PaymentDispatcher dispatcher = new PaymentDispatcher(sanctions, publisher);

        DispatchResult result = dispatcher.dispatch(PaymentRequest.sample());

        assertTrue(result.isEscalated());
    }

    @Test
    void dispatchUsesPacs008ForFastRail() {
        SanctionsService sanctions = Mockito.mock(SanctionsService.class);
        Mockito.when(sanctions.screen(Mockito.any())).thenReturn(ScreeningResult.clear());
        SettlementPublisher publisher = Mockito.mock(SettlementPublisher.class);
        PaymentDispatcher dispatcher = new PaymentDispatcher(sanctions, publisher);

        dispatcher.dispatch(PaymentRequest.sampleFastRail());

        Mockito.verify(publisher).publishPacs008(Mockito.any());
    }
}
