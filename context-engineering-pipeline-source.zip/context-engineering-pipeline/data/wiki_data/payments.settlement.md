---
title: FAST Real-Time Settlement Enhancements
entity_key: payments.settlement
source_type: ado
source_ref: ado-1:4002
candidate_id: cko-d56ffecfbf99
viewpoints: [business_process, technical_implementation]
version: 4
approved_by: R. Tan
published_at: 2026-08-16T20:34:34.033174+00:00
status: Active
---

# FAST Real-Time Settlement Enhancements

## Summary
This document outlines enhancements to the Singapore FAST rail system including extended cut-off times during peak periods, sanctions screening at intake, and migration to FX v2 service.

## Purpose
To extend the cut-off for same-day FAST transfers during peak periods and ensure all FAST payments are screened against sanctions lists at intake. Also, to migrate to the new FX v2 service.

## Constraints
- Cut-off extended to 23:30 SGT during peak periods
- All FAST payments must be screened against sanctions list before dispatch

## Business Rules
- Cut-off for same-day FAST transfer is 22:00 SGT, extended to 23:30 SGT during peak periods (declared peak calendar)
- All FAST payments are screened against the sanctions list at intake, not after settlement
- FX rate lookups use the v2 quote endpoint with async callback support

## Dependencies
- Parent epic: 4001

## Source Content
Deliver peak-period cut-off extension, sanctions screening at intake, and FX v2 migration for the Singapore FAST rail. Parent epic: 4001.

- Cut-off for same-day FAST transfer is 22:00 SGT, extended to 23:30 during peak periods (declared peak calendar).
- All FAST payments are screened against the sanctions list before dispatch, not after settlement.
- FX rate lookups use the v2 quote endpoint with async callback support.
