"""AI Context Builder — KNOW-PIPE §02 stage 9 / Context-Engineering-Platform
-Design Layers 01, 02, 04, 05, 09, 10. The one place all seven agent
personas (BA, Architect, Designer, Developer, Tester, SRE, PM) get their
context from: intent classification -> policy-as-code planning -> hybrid
retrieval -> graph enrichment -> token-budgeted, provenance-tagged assembly
-> outbound guardrail scan.

'Which documents are most similar to this prompt?' is not the question this
answers. The question is: 'what is the minimum, verified, provenance-tagged
context this agent needs to complete this exact task, right now?'
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import yaml

from pipeline.config import settings
from pipeline.extraction.entity_resolution import Glossary
from pipeline.extraction.guardrails import scan_outbound
from pipeline.extraction.tier1_statistical import estimated_jaccard, minhash_signature
from pipeline.indexing import es_index
from pipeline.indexing.embeddings import get_default_cache
from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.llm_client import OllamaError, generate_json
from pipeline.models import AgentRole, Intent
from pipeline.serving.hybrid_retrieval import reciprocal_rank_fusion
from pipeline.serving.query_augmentation import augment_query
from pipeline.serving.rerank import llm_rerank
from pipeline.serving.session_memory import get_session

_SUFFICIENCY_SYSTEM_PROMPT = """You judge whether an assembled context bundle contains enough information to
address a task query. Be pragmatic: partial-but-useful context is sufficient; context that is off-topic or
missing the specific fact/entity the query names is not. Respond with JSON only:
{"sufficient": true/false, "reason": "one short sentence"}"""


def _assess_sufficiency(query: str, assembled_text: str, model: Optional[str] = None) -> tuple[bool, str]:
    """CGR3-inspired sufficiency assessment: before returning context to
    the caller, ask whether it actually addresses the query. Fails open
    (assumed sufficient) on any LLM error — this is a quality refinement,
    never a reason to withhold context the caller already has a right to."""
    prompt = f"Query: {query}\n\nAssembled context (truncated):\n{assembled_text[:4000]}"
    try:
        result = generate_json(prompt, system=_SUFFICIENCY_SYSTEM_PROMPT, model=model)
        return bool(result.get("sufficient", True)), str(result.get("reason", ""))
    except (OllamaError, ValueError, TypeError):
        return True, "sufficiency check unavailable (LLM call failed)"


def _diversity_filter(items: list["ContextItem"], threshold: float = 0.85) -> list["ContextItem"]:
    """Drops items whose body text is a near-duplicate of a higher-ranked
    item already kept — the same MinHash mechanism Tier 1 uses at
    ingestion (extraction/tier1_statistical.py), applied here to the
    retrieved set instead. Product base/overlay items are exempt: they're
    deliberately similar by design (an overlay restates its base's shape)
    and must never be filtered against each other."""
    protected = [i for i in items if i.tag != "retrieved"]
    candidates = [i for i in items if i.tag == "retrieved"]
    kept: list[ContextItem] = []
    kept_sigs: list[tuple] = []
    for item in candidates:
        sig = minhash_signature(item.text) if item.text else None
        is_dup = sig is not None and any(estimated_jaccard(sig, other) >= threshold for other in kept_sigs)
        if is_dup:
            continue
        kept.append(item)
        if sig:
            kept_sigs.append(sig)
    return protected + kept

_POLICIES_DIR = Path(__file__).resolve().parent / "policies"


# ---------------------------------------------------------------------------
# Policy loading
# ---------------------------------------------------------------------------

def load_policies() -> dict[str, dict]:
    policies = {}
    for p in _POLICIES_DIR.glob("*.yaml"):
        data = yaml.safe_load(p.read_text(encoding="utf-8"))
        policies[data["intent"]] = data
    return policies


_POLICIES = load_policies()


# ---------------------------------------------------------------------------
# Intent classification — Layer 01. A small local classifier (keyword/
# embedding-centroid match), not a full LLM call: 20-50ms instead of
# 200-800ms, per the platform doc's own latency guidance.
# ---------------------------------------------------------------------------

DEFAULT_INTENT_BY_ROLE = {
    AgentRole.BA.value: Intent.SPEC_AUTHORING.value,
    AgentRole.ARCHITECT.value: Intent.ARCHITECTURE_REVIEW.value,
    AgentRole.DESIGNER.value: Intent.INTERFACE_DESIGN.value,
    AgentRole.DEVELOPER.value: Intent.CODE_GENERATION.value,
    AgentRole.TESTER.value: Intent.TEST_GENERATION.value,
    AgentRole.SRE.value: Intent.INCIDENT_RESPONSE.value,
    AgentRole.PM.value: Intent.PRIORITIZATION.value,
}


@dataclass
class IntentResult:
    intent: str
    confidence: float
    matched_keywords: list[str]


def classify_intent(query: str, agent_role: Optional[str] = None) -> IntentResult:
    q = query.lower()
    scores: dict[str, list[str]] = {}
    for intent, policy in _POLICIES.items():
        hits = [kw for kw in policy.get("keywords", []) if kw.lower() in q]
        if hits:
            scores[intent] = hits

    if scores:
        # Tie-break by whether the requesting role is a primary_role of the
        # candidate policy before falling back to keyword-hit count alone —
        # otherwise a tie resolves by policy-file iteration order (alphabetical),
        # which has nothing to do with which intent actually fits the caller.
        def _rank(item: tuple[str, list[str]]) -> tuple[int, int]:
            intent, hits = item
            role_match = 1 if agent_role and agent_role in _POLICIES[intent].get("primary_roles", []) else 0
            return (len(hits), role_match)

        best_intent = max(scores.items(), key=_rank)[0]
        confidence = min(1.0, 0.5 + 0.15 * len(scores[best_intent]))
        return IntentResult(intent=best_intent, confidence=confidence, matched_keywords=scores[best_intent])

    # No keyword match — fall back to the requesting agent's default intent,
    # at low confidence (a real deployment would route this to a clarifying
    # question per the platform doc's guidance; the CLI/MCP layer does that).
    fallback = DEFAULT_INTENT_BY_ROLE.get(agent_role or "", Intent.CODE_GENERATION.value)
    return IntentResult(intent=fallback, confidence=0.3, matched_keywords=[])


# ---------------------------------------------------------------------------
# Product-aware resolution — base capability + scoped variant (e.g. "RTGS
# IN" = RTGS base rules + India overlay), generalized beyond payments: any
# domain populating the Product/EXTENDS graph gets this for free.
# ---------------------------------------------------------------------------

_PRODUCT_QUERY_RE = re.compile(r"\b([A-Z]{2,10})\s*[- ]?\s*(IN|GB|UK|US|SG)\b", re.IGNORECASE)

# Config, not code, in a real rollout: which product codes the platform
# knows about, and how natural-language jurisdiction names map to the
# short variant codes the Product graph uses.
KNOWN_PRODUCT_CODES = ["RTGS"]
COUNTRY_NAME_TO_VARIANT = {
    "india": "IN", "singapore": "SG", "united kingdom": "GB", "great britain": "GB",
    "uk": "GB", "u.k.": "GB", "united states": "US", "usa": "US", "u.s.": "US",
}


def detect_product_variant_query(query: str) -> Optional[tuple[str, str]]:
    """Recognizes both a literal code pair ('RTGS IN', 'RTGS-GB') and
    natural-language phrasing ('RTGS rules for India') — a BA or PM agent
    asks the second way far more often than the first."""
    q_lower = query.lower()
    code_match = next((c for c in KNOWN_PRODUCT_CODES if re.search(rf"\b{re.escape(c.lower())}\b", q_lower)), None)
    if not code_match:
        return None

    m = _PRODUCT_QUERY_RE.search(query)
    if m and m.group(1).upper() == code_match:
        variant = m.group(2).upper()
        return code_match, ("GB" if variant == "UK" else variant)

    for name, variant in COUNTRY_NAME_TO_VARIANT.items():
        if re.search(rf"\b{re.escape(name)}\b", q_lower):
            return code_match, variant
    return None


# ---------------------------------------------------------------------------
# Context bundle
# ---------------------------------------------------------------------------

@dataclass
class ContextItem:
    id: str
    title: str
    text: str
    score: float
    source_type: str
    viewpoints: list[str]
    entity_key: Optional[str]
    provenance: dict[str, Any]
    summary: str = ""
    compressed: bool = False  # rendering the summary-resolution stand-in, not the full text — see token budgeting
    rank_detail: dict[str, Any] = field(default_factory=dict)
    tag: str = "retrieved"  # "retrieved" | "product-base" | "product-overlay" | "graph-enrichment"
    already_seen: bool = False  # delivered earlier in this session — see session_memory.py


@dataclass
class ContextBundle:
    query: str
    agent_role: str
    intent: str
    intent_confidence: float
    items: list[ContextItem]
    graph_notes: list[str]
    token_budget: int
    tokens_used: int
    dropped_for_budget: list[str]
    guardrail_clean: bool
    guardrail_hits: list[str]
    filter_relaxed: bool
    session_id: Optional[str]
    reranked: bool = False
    diversity_dropped: int = 0
    compressed_count: int = 0
    sufficiency_checked: bool = False
    sufficient: Optional[bool] = None
    sufficiency_reason: str = ""
    expanded: bool = False
    query_augmentation_terms: list[str] = field(default_factory=list)
    assembled_text: str = ""


def _estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)  # standard ~4 chars/token approximation


_ALREADY_SEEN_TOKEN_COST = 20  # a reference line costs far less than the full text it stands in for


def _viewpoint_filters(policy: dict) -> Optional[dict]:
    required = policy.get("sources", {}).get("required_viewpoints") or []
    if not required:
        return None
    return {"viewpoints": required}


class ContextBuilder:
    def __init__(self, env: str = "production"):
        self.env = env
        self.es_client = es_index.get_client()
        self.index_name = es_index.index_name_for(env)
        self.cache = get_default_cache()
        self.graph = GraphBuilder()
        self.glossary = Glossary()

    def close(self):
        self.graph.close()

    def build(self, query: str, agent_role: str, intent: Optional[str] = None, top_k: int = 12,
              session_id: Optional[str] = None, rerank: bool = True, check_sufficiency: bool = True) -> ContextBundle:
        intent_result = IntentResult(intent=intent, confidence=1.0, matched_keywords=[]) if intent else classify_intent(query, agent_role)
        policy = _POLICIES.get(intent_result.intent, _POLICIES[Intent.CODE_GENERATION.value])
        session = get_session(session_id) if session_id else None

        base_hops = policy.get("graph_enrichment", {}).get("hops", 2)
        pass1 = self._retrieve_and_assemble(query, agent_role, intent_result, policy, top_k, session, rerank, base_hops)

        expanded = False
        sufficient: Optional[bool] = None
        sufficiency_reason = ""
        result = pass1
        if check_sufficiency and pass1["kept"]:
            sufficient, sufficiency_reason = _assess_sufficiency(query, pass1["assembled"])
            if not sufficient:
                # CGR3-style iterative reasoning, bounded to one extra pass:
                # widen the candidate pool and traverse one hop further
                # rather than silently returning context already judged
                # insufficient for the query.
                pass2 = self._retrieve_and_assemble(
                    query, agent_role, intent_result, policy, top_k * 2, session, rerank, base_hops + 1,
                )
                if pass2["kept"]:
                    result = pass2
                    expanded = True

        if session:
            session.record(
                query=query, intent=intent_result.intent, agent_role=agent_role,
                item_ids=[i.id for i in result["kept"]],
                entity_keys=[i.entity_key for i in result["kept"] if i.entity_key],
            )

        guardrail = scan_outbound(result["assembled"])
        return ContextBundle(
            query=query, agent_role=agent_role, intent=intent_result.intent,
            intent_confidence=intent_result.confidence, items=result["kept"], graph_notes=result["graph_notes"],
            token_budget=result["max_tokens"], tokens_used=result["used"], dropped_for_budget=result["dropped"],
            guardrail_clean=guardrail.clean, guardrail_hits=guardrail.all_hits(),
            filter_relaxed=result["filter_relaxed"], session_id=session_id,
            reranked=result["reranked"], diversity_dropped=result["diversity_dropped"],
            compressed_count=result["compressed_count"], sufficiency_checked=check_sufficiency,
            sufficient=sufficient, sufficiency_reason=sufficiency_reason, expanded=expanded,
            query_augmentation_terms=result["matched_terms"], assembled_text=result["assembled"],
        )

    def _retrieve_and_assemble(self, query: str, agent_role: str, intent_result: "IntentResult", policy: dict,
                                 top_k: int, session, rerank: bool, hops: int) -> dict:
        """One full retrieve -> rerank -> diversity-filter -> graph-enrich
        -> token-budget -> assemble pass. Factored out so sufficiency-
        driven expansion (build()) can call it a second time with wider
        parameters without duplicating the pipeline."""
        items: list[ContextItem] = []

        # --- product base + overlay resolution, bypasses normal ranking ---
        product_match = detect_product_variant_query(query)
        if product_match:
            items.extend(self._product_items(*product_match))

        # --- query augmentation: expand with canonical glossary labels for
        # any entity the raw query already names, before it hits retrieval
        # (Weaviate 'Query Augmentation' pillar) — deterministic, no LLM call ---
        search_query, matched_terms = augment_query(query, self.glossary)

        # --- hybrid retrieval ---
        query_vector, _, _ = self.cache.get_or_embed(search_query)
        filters = _viewpoint_filters(policy)
        bm25_hits = es_index.search_bm25(self.es_client, self.index_name, search_query, filters=filters, size=top_k)
        dense_hits = es_index.search_dense(self.es_client, self.index_name, query_vector, filters=filters, k=top_k)
        filter_relaxed = False
        if filters and not bm25_hits and not dense_hits:
            # A required-viewpoint filter that zeroes out every result is a
            # misconfigured policy or an under-tagged corpus, not "no
            # answer" — relax to unfiltered search rather than fail
            # silently (the explicit degradation path this same layer
            # already applies to token budget).
            filter_relaxed = True
            bm25_hits = es_index.search_bm25(self.es_client, self.index_name, search_query, size=top_k)
            dense_hits = es_index.search_dense(self.es_client, self.index_name, query_vector, k=top_k)
        fused = reciprocal_rank_fusion(bm25_hits, dense_hits)

        # --- LLM-based reranking (precision pass over the top-N fused candidates) ---
        did_rerank = False
        if rerank and len(fused) > 1:
            fused = llm_rerank(query, fused, top_n=8)
            did_rerank = True

        seen_ids = {i.id for i in items}
        for hit in fused:
            if hit.id in seen_ids:
                continue
            src = hit.source
            items.append(ContextItem(
                id=hit.id, title=src.get("title", ""), text=src.get("body", "") or src.get("summary", ""),
                score=hit.fused_score, source_type=src.get("source_type", ""),
                viewpoints=src.get("viewpoints", []) or [], entity_key=src.get("entity_key"),
                provenance={"candidate_id": src.get("candidate_id"), "content_hash": src.get("content_hash"),
                            "approved_by": src.get("approved_by"), "version": src.get("version"),
                            "rerank_rationale": hit.rerank_rationale},
                rank_detail={"bm25_rank": hit.bm25_rank, "dense_rank": hit.dense_rank,
                             "bm25_score": hit.bm25_score, "dense_score": hit.dense_score},
                summary=src.get("summary", ""),
            ))
            seen_ids.add(hit.id)

        # --- diversity filtering over the retrieved set (not just at ingestion) ---
        before_diversity = len(items)
        items = _diversity_filter(items)
        diversity_dropped = before_diversity - len(items)

        # --- session working memory (Context-Engineering-Platform-Design
        # Layer 07 'agent scratchpad'): content already delivered earlier
        # in this session gets marked, not dropped — a lower-cost stand-in
        # reclaims its token budget for genuinely new context, matching
        # 'avoid re-fetching what's already been retrieved' without
        # pretending previously-relevant content stopped being relevant. ---
        if session:
            for item in items:
                item.already_seen = session.already_seen(item.id)

        # --- graph enrichment ---
        graph_notes: list[str] = []
        if policy.get("graph_enrichment", {}).get("enabled") and items:
            graph_notes = self._graph_enrichment(items[:3], hops)

        # --- token budgeting: two-resolution compression before dropping
        # (Hierarchical Context Compression) — an item that doesn't fit at
        # full text may still fit as its existing summary; only drop it
        # once neither resolution fits. ---
        max_tokens = policy.get("budget", {}).get("max_tokens", settings.default_token_budget)
        kept: list[ContextItem] = []
        dropped: list[str] = []
        compressed_count = 0
        used = 0
        for item in items:  # already priority-ordered (product items first, then fused rank order)
            full_cost = _ALREADY_SEEN_TOKEN_COST if item.already_seen else _estimate_tokens(item.text)
            if used + full_cost <= max_tokens or not kept:
                kept.append(item)
                used += full_cost
                continue
            if not item.already_seen and item.summary and item.summary != item.text:
                compressed_cost = _estimate_tokens(item.summary)
                if used + compressed_cost <= max_tokens:
                    item.compressed = True
                    kept.append(item)
                    used += compressed_cost
                    compressed_count += 1
                    continue
            dropped.append(item.id)

        assembled = self._assemble(query, agent_role, intent_result.intent, kept, graph_notes, filter_relaxed)
        return {
            "kept": kept, "dropped": dropped, "used": used, "max_tokens": max_tokens,
            "graph_notes": graph_notes, "filter_relaxed": filter_relaxed, "assembled": assembled,
            "reranked": did_rerank, "diversity_dropped": diversity_dropped, "compressed_count": compressed_count,
            "matched_terms": matched_terms,
        }

    def _product_items(self, code: str, variant: str) -> list[ContextItem]:
        rows = self.graph.product_hierarchy(code)
        variant_row = next((r for r in rows if r["product"].get("variant_key") == variant), None)
        if not variant_row:
            return []
        out = []
        base = variant_row.get("base_product")
        if base:
            out.append(self._product_es_lookup(base["key"], tag="product-base"))
        out.append(self._product_es_lookup(variant_row["product"]["key"], tag="product-overlay"))
        return [i for i in out if i is not None]

    def _product_es_lookup(self, entity_key: str, tag: str) -> Optional[ContextItem]:
        hits = es_index.get_by_field(self.es_client, self.index_name, "entity_key", entity_key)
        if not hits:
            return None
        src = hits[0]
        return ContextItem(
            id=hits[0]["id"], title=src.get("title", ""), text=src.get("body", ""), score=1.0,
            source_type=src.get("source_type", ""), viewpoints=src.get("viewpoints", []) or [],
            entity_key=entity_key, provenance={"candidate_id": src.get("candidate_id"), "content_hash": src.get("content_hash")},
            tag=tag,
        )

    def _graph_enrichment(self, top_items: list[ContextItem], hops: int) -> list[str]:
        notes = []
        for item in top_items:
            if not item.entity_key:
                continue
            neighbors = self.graph.neighbors("Entity", "key", item.entity_key, hops=hops, env=self.env)
            if not neighbors:
                continue
            def _label(n: dict) -> str:
                node = n["node"]
                return node.get("name") or node.get("key") or node.get("title") or node.get("entity_key") or "?"
            summary = ", ".join(f"{n['labels'][0]}:{_label(n)}" for n in neighbors[:8])
            notes.append(f"Graph neighbors of {item.entity_key} (within {hops} hops): {summary}")
        return notes

    def _assemble(self, query: str, role: str, intent: str, items: list[ContextItem], graph_notes: list[str],
                   filter_relaxed: bool = False) -> str:
        parts = [f"# Context for {role} agent — intent: {intent}", f"Query: {query}\n"]
        if filter_relaxed:
            parts.append("_Note: this intent's required-viewpoint filter matched nothing in the current "
                         "knowledge base, so retrieval was relaxed to unfiltered search. Consider whether "
                         "the source needs re-tagging or the policy needs revisiting._\n")
        for item in items:
            tag = f" [{item.tag}]" if item.tag != "retrieved" else ""
            header = (f"## {item.title}{tag} (source={item.source_type}, viewpoints={','.join(item.viewpoints)}, "
                      f"score={item.score:.3f})\nprovenance: {item.provenance}\n")
            if item.already_seen:
                parts.append(f"{header}\n_(already provided earlier in this session — not re-sent to save budget)_\n")
            elif item.compressed:
                parts.append(f"{header}\n_(compressed to summary resolution to fit the token budget)_\n{item.summary}\n")
            else:
                parts.append(f"{header}\n{item.text}\n")
        if graph_notes:
            parts.append("## Graph enrichment\n" + "\n".join(graph_notes))
        return "\n".join(parts)
