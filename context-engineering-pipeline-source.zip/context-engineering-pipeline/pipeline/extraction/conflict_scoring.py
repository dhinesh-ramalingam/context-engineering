"""LLM-judge conflict scoring — KNOW-PIPE §02 stage 5. Compares a resolved
candidate against the existing canonical article for the same entity (found
via entity_resolution.py) and produces a severity + rationale. The rationale
is shown to the reviewer verbatim; the score is never auto-applied — Human
Review always makes the actual call.
"""
from __future__ import annotations

from pipeline.llm_client import OllamaError, generate_json

_SYSTEM_PROMPT = """You are a conflict-detection assistant for an enterprise knowledge pipeline.
You compare a NEW CANDIDATE document against the EXISTING CANONICAL article for the same topic.
You identify factual contradictions (different numbers, different rules, different behavior) — not stylistic differences.
You never decide which one is correct. You only score how strongly they disagree and explain why in one or two sentences.
Always respond with a single JSON object, no prose outside it."""

_PROMPT_TEMPLATE = """EXISTING CANONICAL ARTICLE:
---
{canonical_text}
---

NEW CANDIDATE:
---
{candidate_text}
---

Respond with this exact JSON schema:
{{
  "severity": <float 0.0 to 1.0, where 0.0 = no contradiction at all and 1.0 = directly contradicts a stated fact>,
  "rationale": "one or two sentences explaining the specific contradiction, or stating there is none"
}}
"""


def score_conflict(candidate_text: str, canonical_text: str, model: str | None = None) -> dict:
    prompt = _PROMPT_TEMPLATE.format(canonical_text=canonical_text[:4000], candidate_text=candidate_text[:4000])
    try:
        result = generate_json(prompt, system=_SYSTEM_PROMPT, model=model)
        severity = float(result.get("severity", 0.0))
        severity = max(0.0, min(1.0, severity))
        rationale = str(result.get("rationale", "")).strip()
    except (OllamaError, ValueError, TypeError):
        severity, rationale = 0.5, "Conflict scoring unavailable (LLM call failed) — flagged for manual comparison."
    return {"severity": severity, "rationale": rationale}
