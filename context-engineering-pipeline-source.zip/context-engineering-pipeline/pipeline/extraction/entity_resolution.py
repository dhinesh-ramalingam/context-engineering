"""KNOW-EXTRACT §07 — Entity Resolution.

Cross-source, not just cross-title. Resolves against a maintained glossary
of canonical entity keys per domain via a three-stage cascade in cost order:
exact/alias match (cheapest, highest precision), fuzzy string match for
near-misses the glossary doesn't yet list, and embedding similarity — only
on the Tier-0/1 survivor set — for genuine synonyms with no lexical overlap.

This has to run before Conflict Detection: the pipeline can only compare a
candidate against "the existing canonical article for this entity" once it
knows which entity that is.
"""
from __future__ import annotations

import difflib
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

import yaml

_GLOSSARY_PATH = Path(__file__).resolve().parent.parent.parent / "data" / "glossary.yaml"

FUZZY_THRESHOLD = 0.80
EMBEDDING_THRESHOLD = 0.80


@dataclass
class EntityMatch:
    entity_key: Optional[str]
    label: Optional[str]
    method: str  # "exact" | "fuzzy" | "embedding" | "unresolved"
    matched_alias: Optional[str]
    score: float


class Glossary:
    def __init__(self, path: Path = _GLOSSARY_PATH):
        self.path = path
        self._data: dict = {}
        self.reload()

    def reload(self) -> None:
        if self.path.exists():
            self._data = yaml.safe_load(self.path.read_text(encoding="utf-8")) or {}
        else:
            self._data = {}

    def save(self) -> None:
        self.path.write_text(yaml.safe_dump(self._data, sort_keys=True, allow_unicode=True), encoding="utf-8")

    def entries(self) -> dict:
        return self._data

    def label(self, entity_key: str) -> Optional[str]:
        entry = self._data.get(entity_key)
        return entry.get("label") if entry else None

    def add_alias(self, entity_key: str, alias: str) -> bool:
        """Write-back: a confirmed fuzzy/embedding match becomes a new
        exact-match alias for next time — the vocabulary grows from real
        approvals instead of being maintained by hand indefinitely."""
        entry = self._data.setdefault(entity_key, {"label": entity_key, "aliases": []})
        aliases = entry.setdefault("aliases", [])
        if alias not in aliases:
            aliases.append(alias)
            self.save()
            return True
        return False


def _norm(s: str) -> str:
    return " ".join(s.lower().split())


def _exact_match(glossary: Glossary, title: str, body: str) -> Optional[EntityMatch]:
    """Specificity-ranked, not dict-order-first-hit: an exact title match
    always wins; otherwise the longest alias found — checking the title
    before the body, and preferring longer/more specific aliases over short
    generic ones — so a passing mention of a dependency (e.g. 'SanctionsService'
    in a Dependencies section) can't outrank the document's own declared
    subject."""
    title_norm = _norm(title)
    body_norm = _norm(body[:500])

    for key, entry in glossary.entries().items():
        for alias in entry.get("aliases", []):
            if title_norm == _norm(alias):
                return EntityMatch(key, entry.get("label"), "exact", alias, 1.0)

    title_hits: list[tuple[str, str, str]] = []  # (key, label, alias)
    for key, entry in glossary.entries().items():
        for alias in entry.get("aliases", []):
            if _norm(alias) in title_norm:
                title_hits.append((key, entry.get("label"), alias))
    if title_hits:
        key, label, alias = max(title_hits, key=lambda h: len(h[2]))
        return EntityMatch(key, label, "exact", alias, 0.95)

    body_hits: list[tuple[str, str, str]] = []
    for key, entry in glossary.entries().items():
        for alias in entry.get("aliases", []):
            if _norm(alias) in body_norm:
                body_hits.append((key, entry.get("label"), alias))
    if body_hits:
        key, label, alias = max(body_hits, key=lambda h: len(h[2]))
        return EntityMatch(key, label, "exact", alias, 0.85)

    return None


def _fuzzy_match(glossary: Glossary, title: str) -> Optional[EntityMatch]:
    title_norm = _norm(title)
    best: Optional[EntityMatch] = None
    for key, entry in glossary.entries().items():
        for alias in entry.get("aliases", []):
            ratio = difflib.SequenceMatcher(None, title_norm, _norm(alias)).ratio()
            if ratio >= FUZZY_THRESHOLD and (best is None or ratio > best.score):
                best = EntityMatch(key, entry.get("label"), "fuzzy", alias, ratio)
    return best


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def _embedding_match(glossary: Glossary, title: str, body: str, embed_fn: Callable[[str], list[float]]) -> Optional[EntityMatch]:
    query_vec = embed_fn((title + " " + body[:300]).strip())
    best: Optional[EntityMatch] = None
    for key, entry in glossary.entries().items():
        rep_text = entry.get("label", "") + " " + " ".join(entry.get("aliases", []))
        entry_vec = embed_fn(rep_text)
        sim = _cosine(query_vec, entry_vec)
        if sim >= EMBEDDING_THRESHOLD and (best is None or sim > best.score):
            best = EntityMatch(key, entry.get("label"), "embedding", entry.get("label"), sim)
    return best


def resolve_entity(
    title: str,
    body: str,
    glossary: Glossary,
    embed_fn: Optional[Callable[[str], list[float]]] = None,
) -> EntityMatch:
    match = _exact_match(glossary, title, body)
    if match:
        return match
    match = _fuzzy_match(glossary, title)
    if match:
        return match
    if embed_fn is not None:
        match = _embedding_match(glossary, title, body, embed_fn)
        if match:
            return match
    return EntityMatch(None, None, "unresolved", None, 0.0)
