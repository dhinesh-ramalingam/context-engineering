---
title: AML threshold — Singapore
entity_key: payments.aml_threshold_sg
source_type: confluence
source_ref: confluence-1:CONF-1005
candidate_id: cko-b6b1701efe80
viewpoints: [business_domain, business_process]
version: 2
approved_by: K. Mensah
published_at: 2026-08-16T20:34:21.276305+00:00
status: Active
---

# AML threshold — Singapore

## Summary
This document outlines the SGD 20,000 daily transaction threshold for Singapore-domiciled accounts and mandates routing of transactions exceeding this limit for enhanced AML review.

## Purpose
Defines the aggregate daily transaction threshold that triggers enhanced AML review for Singapore-domiciled accounts.

## Business Rules
- The aggregate daily threshold is SGD 20,000, applied per-account. Transactions that would cause the per-account aggregate to exceed this threshold within a rolling 24-hour window must be routed to enhanced AML review before settlement.

## Dependencies
- SanctionsService
- AML case management system

## Source Content
# AML threshold — Singapore

## Purpose
Defines the aggregate daily transaction threshold that triggers enhanced AML review for Singapore-domiciled accounts.

## Business Rules
The aggregate daily threshold is SGD 20,000, applied per-account. Transactions that would cause the per-account aggregate to exceed this threshold within a rolling 24-hour window must be routed to enhanced AML review before settlement.

## Dependencies
SanctionsService, AML case management system.

