---
title: TT — Singapore (Cross-Border Telegraphic Transfer)
entity_key: products.tt.sg
source_type: product_catalog
source_ref: product_catalog-1:PROD-TT-SG
candidate_id: cko-4becbc0b5ffc
viewpoints: [business_domain, business_process, regulatory_product]
version: 1
approved_by: R. Tan
published_at: 2026-08-16T20:33:48.086935+00:00
status: Active
---

# TT — Singapore (Cross-Border Telegraphic Transfer)

## Summary
This document outlines rules for cross-border wire transfers (TT) via SWIFT from Singapore-domiciled accounts, detailing business rules and dependencies.

## Purpose
Defines the platform's rules for outward and inward cross-border wire transfers (Telegraphic Transfer, TT) routed via SWIFT from a Singapore-domiciled account.

## Interfaces
- CrossBorderWireRequest

## Business Rules
- - Outward TT is initiated from a customer channel (mobile/branch/API) and requires full beneficiary bank details (SWIFT BIC, IBAN or account number) plus sanctions screening before release to SWIFT.
- - Inward TT arrives via SWIFT from a correspondent or the beneficiary's bank and is credited after sanctions/AML screening on the remitter — inward transactions are regulator/correspondent-bank-initiated, not customer-initiated, and follow a different screening trigger than outward.
- - Same-day value is not guaranteed for cross-border TT; cut-off depends on the currency's correspondent banking cut-off, not a single platform-wide time.

## Dependencies
- SWIFT messaging gateway
- correspondent banking network
- sanctions screening

## Source Content
# TT — Singapore (Cross-Border Telegraphic Transfer)

## Purpose
Defines the platform's rules for outward and inward cross-border wire transfers (Telegraphic Transfer, TT) routed via SWIFT from a Singapore-domiciled account.

## Scope
Applies to cross-border TT/wire payments in any supported currency, sent or received via SWIFT MT/MX messaging.

## Business Rules
- Outward TT is initiated from a customer channel (mobile/branch/API) and requires full beneficiary bank details (SWIFT BIC, IBAN or account number) plus sanctions screening before release to SWIFT.
- Inward TT arrives via SWIFT from a correspondent or the beneficiary's bank and is credited after sanctions/AML screening on the remitter — inward transactions are regulator/correspondent-bank-initiated, not customer-initiated, and follow a different screening trigger than outward.
- Same-day value is not guaranteed for cross-border TT; cut-off depends on the currency's correspondent banking cut-off, not a single platform-wide time.

## Interfaces
`CrossBorderWireRequest` — `payerAccount`, `beneficiaryBic`, `beneficiaryAccountOrIban`, `amountMinorUnits`, `currency`, `purposeCode`.

## Dependencies
SWIFT messaging gateway, correspondent banking network, sanctions screening.

## Glossary
TT — Telegraphic Transfer, a cross-border wire payment. SWIFT — the international interbank messaging network used to route TT instructions.

