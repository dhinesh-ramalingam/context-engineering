"""GraphRAG on Neo4j — Context-Engineering-Platform-Design Layer 05, extended
with two additions the user asked for on top of the base architecture:

1. A generic base-capability + scoped-variant hierarchy (`Product
   -[:EXTENDS]-> Product`), populated here with payments RTGS/base+country
   overlays but not payments-specific in the model itself — any domain's
   "base spec + jurisdiction/environment override" shape fits the same
   two node types and one relationship.
2. A code-to-database dependency graph (`CodeClass -[:DEPENDS_ON]->
   CodeClass`, `CodeClass -[:READS_WRITES]-> DbTable`) built from the
   structured regime's parsed output (imports + explicit @db-table
   markers — see connectors/git.py), not inferred by a model.

Isolation: every node's identity is its business key **plus** `env`
("staging" | "production") — MERGE always matches on (key, env) together,
never key alone. Without that, an Isolated run's MERGE would find and
silently overwrite the *production* node with the same business key (its
`env` property flipped to "staging" in place) instead of creating a
separate staging node — exactly the leak KNOW-PIPE §06 says must never
happen. This mirrors how the Elasticsearch side is already genuinely
isolated: staging and production are separate indices, not a shared index
with a flag. `promote_staging()` re-tags staging nodes to production
in-place, which is safe specifically because it's the one explicit,
audited action allowed to cross that boundary.
"""
from __future__ import annotations

from typing import Any, Optional

from neo4j import GraphDatabase

from pipeline.config import settings


class GraphBuilder:
    def __init__(self, uri: Optional[str] = None, user: Optional[str] = None, password: Optional[str] = None):
        self.driver = GraphDatabase.driver(
            uri or settings.neo4j_uri,
            auth=(user or settings.neo4j_user, password or settings.neo4j_password),
        )

    def close(self):
        self.driver.close()

    def ensure_constraints(self):
        stmts = [
            "CREATE CONSTRAINT article_id IF NOT EXISTS FOR (n:CanonicalArticle) REQUIRE (n.entity_key, n.env) IS UNIQUE",
            "CREATE CONSTRAINT entity_key IF NOT EXISTS FOR (n:Entity) REQUIRE (n.key, n.env) IS UNIQUE",
            "CREATE CONSTRAINT viewpoint_name IF NOT EXISTS FOR (n:Viewpoint) REQUIRE (n.name, n.env) IS UNIQUE",
            "CREATE CONSTRAINT product_key IF NOT EXISTS FOR (n:Product) REQUIRE (n.key, n.env) IS UNIQUE",
            "CREATE CONSTRAINT codeclass_key IF NOT EXISTS FOR (n:CodeClass) REQUIRE (n.key, n.env) IS UNIQUE",
            "CREATE CONSTRAINT dbtable_key IF NOT EXISTS FOR (n:DbTable) REQUIRE (n.key, n.env) IS UNIQUE",
            "CREATE CONSTRAINT component_name IF NOT EXISTS FOR (n:Component) REQUIRE (n.name, n.env) IS UNIQUE",
            "CREATE CONSTRAINT workitem_id IF NOT EXISTS FOR (n:WorkItem) REQUIRE (n.id, n.env) IS UNIQUE",
            "CREATE CONSTRAINT incident_key IF NOT EXISTS FOR (n:IncidentSignature) REQUIRE (n.key, n.env) IS UNIQUE",
            "CREATE CONSTRAINT capability_key IF NOT EXISTS FOR (n:Capability) REQUIRE (n.key, n.env) IS UNIQUE",
        ]
        with self.driver.session() as session:
            for stmt in stmts:
                session.run(stmt)

    def wipe_env(self, env: str):
        with self.driver.session() as session:
            session.run("MATCH (n {env: $env}) DETACH DELETE n", env=env)

    # primary business-key property per label — used to find a staging
    # node's production counterpart (if any) when promoting
    _KEY_PROP_BY_LABEL = {
        "Entity": "key", "Viewpoint": "name", "CanonicalArticle": "entity_key",
        "Product": "key", "CodeClass": "key", "DbTable": "key", "Component": "name",
        "WorkItem": "id", "IncidentSignature": "key", "Capability": "key",
    }

    def promote_staging(self):
        """Re-tags the staging subgraph to 'production' — the Isolated Run
        -> Promote action in KNOW-PIPE §06. For each label, any existing
        production node sharing the same business key is replaced (deleted,
        then the staging node takes over its env) rather than left as a
        stale duplicate. Safe specifically because this is the one
        explicit, audited action allowed to cross the staging/production
        boundary; MERGE elsewhere in this class never does."""
        with self.driver.session() as session:
            for label, key_prop in self._KEY_PROP_BY_LABEL.items():
                session.run(
                    f"""
                    MATCH (staging:{label} {{env: 'staging'}})
                    OPTIONAL MATCH (prod:{label} {{env: 'production'}})
                    WHERE prod.{key_prop} = staging.{key_prop}
                    DETACH DELETE prod
                    """
                )
                session.run(f"MATCH (n:{label} {{env: 'staging'}}) SET n.env = 'production'")
            session.run("MATCH ()-[r {env: 'staging'}]-() SET r.env = 'production'")

    # --- entities / viewpoints / canonical articles ---
    def upsert_entity(self, key: str, label: str, domain: str, env: str = "production"):
        with self.driver.session() as session:
            session.run(
                "MERGE (e:Entity {key: $key, env: $env}) SET e.label = $label, e.domain = $domain",
                key=key, label=label, domain=domain, env=env,
            )

    def upsert_viewpoint(self, name: str, env: str = "production"):
        with self.driver.session() as session:
            session.run("MERGE (v:Viewpoint {name: $name, env: $env})", name=name, env=env)

    def upsert_canonical_article(self, entity_key: str, title: str, version: int, source_type: str,
                                   viewpoints: list[str], approved_by: str, env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MERGE (a:CanonicalArticle {entity_key: $entity_key, env: $env})
                SET a.title = $title, a.version = $version, a.source_type = $source_type,
                    a.approved_by = $approved_by
                WITH a
                MATCH (e:Entity {key: $entity_key, env: $env})
                MERGE (a)-[r:ABOUT]->(e) SET r.env = $env
                """,
                entity_key=entity_key, title=title, version=version, source_type=source_type,
                approved_by=approved_by, env=env,
            )
            for vp in viewpoints:
                session.run(
                    """
                    MERGE (v:Viewpoint {name: $vp, env: $env})
                    WITH v
                    MATCH (a:CanonicalArticle {entity_key: $entity_key, env: $env})
                    MERGE (a)-[r:HAS_VIEWPOINT]->(v) SET r.env = $env
                    """,
                    vp=vp, entity_key=entity_key, env=env,
                )

    # --- product base + jurisdiction/scope overlay ---
    def upsert_product(self, key: str, code: str, domain: str, scope: str,
                        variant_key: Optional[str], base_key: Optional[str], env: str = "production",
                        family: Optional[str] = None, country: Optional[str] = None):
        with self.driver.session() as session:
            session.run(
                """
                MERGE (p:Product {key: $key, env: $env})
                SET p.code = $code, p.domain = $domain, p.scope = $scope, p.variant_key = $variant_key,
                    p.family = coalesce($family, p.family), p.country = coalesce($country, $variant_key, p.country)
                """,
                key=key, code=code, domain=domain, scope=scope, variant_key=variant_key, env=env,
                family=family, country=country,
            )
            if base_key:
                # MERGE the base node rather than requiring it to pre-exist:
                # reviewers can approve a jurisdiction overlay before its
                # base product (review order isn't guaranteed), so a plain
                # MATCH here would silently drop the EXTENDS edge whenever
                # a variant is approved first. The base's own upsert_product
                # call later just fills in code/domain/scope on this same
                # (key, env) node — harmless, idempotent.
                session.run(
                    """
                    MERGE (base:Product {key: $base_key, env: $env})
                    WITH base
                    MATCH (variant:Product {key: $key, env: $env})
                    MERGE (variant)-[r:EXTENDS]->(base) SET r.env = $env
                    """,
                    key=key, base_key=base_key, env=env,
                )

    def upsert_capability(self, key: str, product_key: str, sub_type: str, direction: str,
                           env: str = "production"):
        """A leaf capability under a product — e.g. RTGS-IN supports
        'Customer Transfer' Outward and Inward as two separate Capability
        nodes. `direction` distinguishes inward (initiated by a regulator
        or external bank) from outward (initiated by a channel) — the axis
        the Product Capability Matrix is built on."""
        with self.driver.session() as session:
            session.run(
                """
                MERGE (cap:Capability {key: $key, env: $env})
                SET cap.sub_type = $sub_type, cap.direction = $direction
                WITH cap
                MERGE (p:Product {key: $product_key, env: $env})
                MERGE (p)-[r:HAS_CAPABILITY]->(cap) SET r.env = $env
                """,
                key=key, product_key=product_key, sub_type=sub_type, direction=direction, env=env,
            )

    def list_capabilities(self, env: str = "production") -> list[dict]:
        query = """
            MATCH (p:Product {env: $env})-[:HAS_CAPABILITY]->(cap:Capability {env: $env})
            RETURN p AS product, cap AS capability
        """
        with self.driver.session() as session:
            result = session.run(query, env=env)
            return [{"product": dict(r["product"]), "capability": dict(r["capability"])} for r in result]

    def link_article_to_product(self, entity_key: str, product_key: str, env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MATCH (a:CanonicalArticle {entity_key: $entity_key, env: $env}), (p:Product {key: $product_key, env: $env})
                MERGE (a)-[r:DESCRIBES_PRODUCT]->(p) SET r.env = $env
                """,
                entity_key=entity_key, product_key=product_key, env=env,
            )

    # --- code dependency graph, mapped to DB tables ---
    def upsert_code_class(self, key: str, name: str, package: Optional[str], repo: str, path: str, env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MERGE (c:CodeClass {key: $key, env: $env})
                SET c.name = $name, c.package = $package, c.repo = $repo, c.path = $path
                """,
                key=key, name=name, package=package, repo=repo, path=path, env=env,
            )

    def link_code_depends_on(self, from_key: str, to_key: str, env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MATCH (a:CodeClass {key: $from_key, env: $env}), (b:CodeClass {key: $to_key, env: $env})
                MERGE (a)-[r:DEPENDS_ON]->(b) SET r.env = $env
                """,
                from_key=from_key, to_key=to_key, env=env,
            )

    def upsert_db_table(self, key: str, schema: str, name: str, columns: list[str], env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MERGE (t:DbTable {key: $key, env: $env})
                SET t.schema = $schema, t.name = $name, t.columns = $columns
                """,
                key=key, schema=schema, name=name, columns=columns, env=env,
            )

    def link_code_reads_writes(self, class_key: str, table_key: str, modes: list[str], env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MATCH (c:CodeClass {key: $class_key, env: $env}), (t:DbTable {key: $table_key, env: $env})
                MERGE (c)-[r:READS_WRITES]->(t) SET r.modes = $modes, r.env = $env
                """,
                class_key=class_key, table_key=table_key, modes=modes, env=env,
            )

    def link_entity_to_code(self, entity_key: str, class_key: str, env: str = "production"):
        """MERGEs the Entity node rather than requiring it to pre-exist:
        code parsing runs before any narrative candidate mentioning this
        entity has been approved, so a plain MATCH here would silently
        find nothing and never create the link. upsert_entity() later
        (on approval) fills in label/domain on this same (key, env) node."""
        with self.driver.session() as session:
            session.run(
                """
                MERGE (e:Entity {key: $entity_key, env: $env})
                ON CREATE SET e.label = $entity_key
                WITH e
                MATCH (c:CodeClass {key: $class_key, env: $env})
                MERGE (e)-[r:IMPLEMENTED_BY]->(c) SET r.env = $env
                """,
                entity_key=entity_key, class_key=class_key, env=env,
            )

    # --- architecture components (PlantUML) ---
    def upsert_component(self, name: str, kind: str = "component", env: str = "production"):
        with self.driver.session() as session:
            session.run("MERGE (c:Component {name: $name, env: $env}) SET c.kind = $kind", name=name, kind=kind, env=env)

    def link_component_flow(self, from_name: str, to_name: str, label: str, env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MATCH (a:Component {name: $from_name, env: $env}), (b:Component {name: $to_name, env: $env})
                MERGE (a)-[r:FLOWS_TO]->(b) SET r.label = $label, r.env = $env
                """,
                from_name=from_name, to_name=to_name, label=label, env=env,
            )

    def link_component_to_code(self, component_name: str, class_key: str, env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MATCH (comp:Component {name: $component_name, env: $env}), (c:CodeClass {key: $class_key, env: $env})
                MERGE (comp)-[r:IMPLEMENTED_BY]->(c) SET r.env = $env
                """,
                component_name=component_name, class_key=class_key, env=env,
            )

    # --- work items + incident signals (PM prioritization, SRE) ---
    def upsert_work_item(self, id: str, title: str, item_type: str, state: str,
                          entity_key: Optional[str], env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MERGE (w:WorkItem {id: $id, env: $env})
                SET w.title = $title, w.item_type = $item_type, w.state = $state
                """,
                id=id, title=title, item_type=item_type, state=state, env=env,
            )
            if entity_key:
                # Same reasoning as link_entity_to_code / upsert_product:
                # ADO items are ingested before any narrative candidate has
                # been approved, so the Entity this work item resolves to
                # frequently doesn't exist yet — MERGE it rather than MATCH.
                session.run(
                    """
                    MERGE (e:Entity {key: $entity_key, env: $env})
                    ON CREATE SET e.label = $entity_key
                    WITH e
                    MATCH (w:WorkItem {id: $id, env: $env})
                    MERGE (w)-[r:RELATES_TO]->(e) SET r.env = $env
                    """,
                    id=id, entity_key=entity_key, env=env,
                )

    def upsert_incident_signature(self, key: str, component: str, reason: str, count: int,
                                    first_seen: str, last_seen: str, env: str = "production"):
        with self.driver.session() as session:
            session.run(
                """
                MERGE (i:IncidentSignature {key: $key, env: $env})
                SET i.component = $component, i.reason = $reason, i.count = $count,
                    i.first_seen = $first_seen, i.last_seen = $last_seen
                WITH i
                OPTIONAL MATCH (c:Component {name: $component, env: $env})
                FOREACH (_ IN CASE WHEN c IS NOT NULL THEN [1] ELSE [] END |
                    MERGE (i)-[r:AFFECTS]->(c) SET r.env = $env)
                WITH i
                OPTIONAL MATCH (cc:CodeClass {name: $component, env: $env})
                FOREACH (_ IN CASE WHEN cc IS NOT NULL THEN [1] ELSE [] END |
                    MERGE (i)-[r2:AFFECTS]->(cc) SET r2.env = $env)
                """,
                key=key, component=component, reason=reason, count=count,
                first_seen=first_seen, last_seen=last_seen, env=env,
            )

    # --- read side: blast radius / neighbors, used by context_builder + prioritization ---
    def neighbors(self, node_label: str, key_prop: str, key_val: str, hops: int = 2, env: str = "production") -> list[dict[str, Any]]:
        hops = max(1, min(hops, 4))  # bounded traversal, per Context-Engineering-Platform-Design Layer 05
        query = f"""
            MATCH (start:{node_label} {{{key_prop}: $key_val, env: $env}})
            MATCH path = (start)-[*1..{hops}]-(other)
            WHERE all(r IN relationships(path) WHERE r.env = $env) AND other.env = $env
            RETURN DISTINCT labels(other) AS labels, other AS node, length(path) AS distance
            ORDER BY distance
            LIMIT 50
        """
        with self.driver.session() as session:
            result = session.run(query, key_val=key_val, env=env)
            return [{"labels": r["labels"], "node": dict(r["node"]), "distance": r["distance"]} for r in result]

    def blast_radius_count(self, node_label: str, key_prop: str, key_val: str, hops: int = 2, env: str = "production") -> int:
        return len(self.neighbors(node_label, key_prop, key_val, hops, env))

    def product_hierarchy(self, code: str, domain: str = "payments", env: str = "production") -> list[dict]:
        query = """
            MATCH (p:Product {code: $code, domain: $domain, env: $env})
            OPTIONAL MATCH (p)-[:EXTENDS]->(base:Product {env: $env})
            RETURN p AS product, base AS base_product
        """
        with self.driver.session() as session:
            result = session.run(query, code=code, domain=domain, env=env)
            return [{"product": dict(r["product"]), "base_product": dict(r["base_product"]) if r["base_product"] else None} for r in result]

    def incident_count(self, component: str, env: str = "production") -> int:
        query = "MATCH (i:IncidentSignature {component: $component, env: $env}) RETURN coalesce(sum(i.count), 0) AS total"
        with self.driver.session() as session:
            return session.run(query, component=component, env=env).single()["total"]

    def open_work_item_count(self, entity_key: str, env: str = "production") -> int:
        query = """
            MATCH (w:WorkItem {env: $env})-[:RELATES_TO]->(:Entity {key: $entity_key, env: $env})
            WHERE NOT w.state IN ['Closed', 'Done', 'Resolved']
            RETURN count(w) AS total
        """
        with self.driver.session() as session:
            return session.run(query, entity_key=entity_key, env=env).single()["total"]

    def implemented_by_name(self, entity_key: str, env: str = "production") -> Optional[str]:
        """The CodeClass/Component name an entity is implemented by, if
        any — lets PM criticality correlate a business entity with the
        incident signals raised against the code that implements it."""
        query = """
            MATCH (:Entity {key: $key, env: $env})-[:IMPLEMENTED_BY]->(c)
            RETURN coalesce(c.name, c.key) AS name LIMIT 1
        """
        with self.driver.session() as session:
            rec = session.run(query, key=entity_key, env=env).single()
            return rec["name"] if rec else None

    def list_products(self, env: str = "production") -> list[dict]:
        """Every Product node (base and variant), with its base-product link
        and approving canonical article if one exists — the data behind the
        product/country coverage matrix. A Product node only exists here
        once a narrative candidate describing it has been approved
        (upsert_product runs in orchestrator.approve_and_publish), so this
        list is exactly 'what jurisdictions/variants are actually governed
        knowledge right now', not just what's in the mock corpus."""
        query = """
            MATCH (p:Product {env: $env})
            OPTIONAL MATCH (p)-[:EXTENDS]->(base:Product {env: $env})
            OPTIONAL MATCH (a:CanonicalArticle {entity_key: p.key, env: $env})
            RETURN p AS product, base AS base_product, a AS article
            ORDER BY p.code, p.scope DESC, p.variant_key
        """
        with self.driver.session() as session:
            result = session.run(query, env=env)
            return [
                {
                    "product": dict(r["product"]),
                    "base_product": dict(r["base_product"]) if r["base_product"] else None,
                    "article": dict(r["article"]) if r["article"] else None,
                }
                for r in result
            ]

    def dependency_tree(self, node_label: str, key_prop: str, key_val: str, max_depth: int = 3,
                         env: str = "production") -> dict:
        """A real parent->child tree (not the flat blast-radius list
        `neighbors()` returns) — every outbound typed relationship
        (DEPENDS_ON, READS_WRITES, EXTENDS, FLOWS_TO, IMPLEMENTED_BY,
        DESCRIBES_PRODUCT, ABOUT...) from the given node, expanded
        recursively and cycle-guarded. This is what a UI renders as an
        actual expandable tree instead of a distance-ordered list."""
        max_depth = max(1, min(max_depth, 5))

        def _expand(label: str, kprop: str, kval: str, depth: int, visited: frozenset) -> Optional[dict]:
            node_id = f"{label}:{kval}"
            if node_id in visited:
                return {"label": label, "key": kval, "name": kval, "children": [], "cycle": True}

            query = f"""
                MATCH (n:{label} {{{kprop}: $kval, env: $env}})
                OPTIONAL MATCH (n)-[r]->(child)
                WHERE r.env = $env AND child.env = $env
                RETURN n AS node, type(r) AS rel_type, child AS child, labels(child) AS child_labels
            """
            with self.driver.session() as session:
                rows = list(session.run(query, kval=kval, env=env))
            if not rows:
                return None

            node_props = dict(rows[0]["node"])
            node_name = node_props.get("name") or node_props.get("key") or node_props.get("title") \
                or node_props.get("entity_key") or kval

            children = []
            if depth < max_depth:
                for row in rows:
                    if row["child"] is None:
                        continue
                    child_label = row["child_labels"][0]
                    child_props = dict(row["child"])
                    child_kprop = self._KEY_PROP_BY_LABEL.get(child_label, "key")
                    child_kval = child_props.get(child_kprop)
                    if child_kval is None:
                        continue
                    sub = _expand(child_label, child_kprop, child_kval, depth + 1, visited | {node_id})
                    children.append({
                        "relationship": row["rel_type"],
                        "label": child_label,
                        "key": child_kval,
                        "name": (sub or {}).get("name") or child_kval,
                        "children": (sub or {}).get("children", []),
                    })
            return {"label": label, "key": kval, "name": node_name, "children": children}

        return _expand(node_label, key_prop, key_val, 0, frozenset()) or {
            "label": node_label, "key": key_val, "name": key_val, "children": [], "not_found": True,
        }

    def list_roots(self, env: str = "production") -> dict[str, list[str]]:
        """Candidate starting points for the dependency-tree explorer —
        every CodeClass, Component, Entity, and Product currently in the
        graph, grouped by label."""
        out: dict[str, list[str]] = {}
        for label, key_prop in self._KEY_PROP_BY_LABEL.items():
            if label in ("WorkItem", "IncidentSignature", "Viewpoint", "CanonicalArticle", "Capability"):
                continue
            query = f"MATCH (n:{label} {{env: $env}}) RETURN n.{key_prop} AS k ORDER BY k"
            with self.driver.session() as session:
                out[label] = [r["k"] for r in session.run(query, env=env) if r["k"]]
        return out

    def has_product_link(self, entity_key: str, env: str = "production") -> bool:
        """True if this entity key is itself a Product node, or its
        canonical article describes one — used for PM criticality's
        regulatory-linkage signal (serving/prioritization.py)."""
        query = """
            OPTIONAL MATCH (p:Product {key: $key, env: $env})
            OPTIONAL MATCH (:CanonicalArticle {entity_key: $key, env: $env})-[:DESCRIBES_PRODUCT]->(p2:Product {env: $env})
            RETURN (p IS NOT NULL OR p2 IS NOT NULL) AS linked
        """
        with self.driver.session() as session:
            return bool(session.run(query, key=entity_key, env=env).single()["linked"])
