---
title: Cards dispute SLA definition
entity_key: cards.dispute_sla
source_type: ado
source_ref: ado-1:48350
candidate_id: cko-762667856cf4
viewpoints: [business_process]
version: 1
approved_by: M. Reyes
published_at: 2026-08-16T20:34:08.245540+00:00
status: Active
---

# Cards dispute SLA definition

## Summary
This document outlines specific SLAs for dispute case resolution, including standard and escalated case timelines and automatic reporting of breaches.

## Purpose
Define SLA for dispute case resolution to ensure consistent regulatory reporting across markets.

## Business Rules
- Standard dispute cases must be resolved within 10 business days of intake.
- Cases requiring issuer network escalation may extend to 45 calendar days, with the customer notified of the extension.
- SLA breaches must be flagged to the Cards Operations dashboard automatically.

## Source Content
As a cards operations lead, I need a defined SLA for dispute case resolution so that regulatory reporting on dispute handling times is consistent across markets.

- Standard dispute cases must be resolved within 10 business days of intake.
- Cases requiring issuer network escalation may extend to 45 calendar days, with the customer notified of the extension.
- SLA breaches must be flagged to the Cards Operations dashboard automatically.
