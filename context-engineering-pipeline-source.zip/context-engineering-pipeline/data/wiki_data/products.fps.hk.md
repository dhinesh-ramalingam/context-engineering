---
title: FPS — Hong Kong (Faster Payment System)
entity_key: products.fps.hk
source_type: product_catalog
source_ref: product_catalog-1:PROD-FPS-HK
candidate_id: cko-a1a4216effe1
viewpoints: [business_domain, business_process, regulatory_product]
version: 1
approved_by: S. Idris
published_at: 2026-08-16T20:34:14.577974+00:00
status: Active
---

# FPS — Hong Kong (Faster Payment System)

## Summary
This document outlines the business rules for Hong Kong's Faster Payment System (FPS), including real-time settlement, dual-currency support, and specific interface requirements.

## Purpose
Defines the platform's rules for Hong Kong's FPS scheme, operated by the Hong Kong Interbank Clearing Limited (HKICL) under the HKMA — another sibling instant-payment rail in the same product family as FAST and IMPS, independently designed rather than a jurisdiction overlay of a shared base.

## Interfaces
- FpsPaymentRequest

## Business Rules
- - Real-time, 24x7 settlement; supports both bank accounts and FPS Identifiers (mobile number, email, or QR code) as the payee address.
- - Dual-currency support (HKD and CNY) is unique to FPS among this platform's instant-payment integrations — currency must be explicit on every request.

## Dependencies
- HKICL FPS switch
- FPS Identifier directory

## Source Content
# FPS — Hong Kong (Faster Payment System)

## Purpose
Defines the platform's rules for Hong Kong's FPS scheme, operated by the Hong Kong Interbank Clearing Limited (HKICL) under the HKMA — another sibling instant-payment rail in the same product family as FAST and IMPS, independently designed rather than a jurisdiction overlay of a shared base.

## Scope
Applies to retail instant transfers in HKD or CNY between participating Hong Kong banks and e-wallets via FPS.

## Business Rules
- Real-time, 24x7 settlement; supports both bank accounts and FPS Identifiers (mobile number, email, or QR code) as the payee address.
- Dual-currency support (HKD and CNY) is unique to FPS among this platform's instant-payment integrations — currency must be explicit on every request.

## Interfaces
`FpsPaymentRequest` — `payerAccount`, `payeeFpsId` (mobile/email/QR) or `payeeAccount`, `amountMinorUnits`, `currency` (HKD|CNY).

## Dependencies
HKICL FPS switch, FPS Identifier directory.

## Glossary
FPS — Faster Payment System, Hong Kong's instant retail payment infrastructure operated by HKICL under HKMA oversight.

