"""Thin client for the local Ollama endpoint — the one interface extraction,
scoring, and context-serving embeddings all go through. Local-only: no
network egress, matching KNOW-PIPE's 'local-first inference' principle.
"""
from __future__ import annotations

import json
import re
from typing import Any, Optional

import requests

from pipeline.config import settings

_JSON_BLOCK_RE = re.compile(r"\{.*\}", re.DOTALL)


class OllamaError(RuntimeError):
    pass


def generate_json(prompt: str, system: Optional[str] = None, model: Optional[str] = None, temperature: float = 0.1) -> dict[str, Any]:
    """Calls Ollama in JSON mode and returns the parsed object. Ollama's
    `format: json` constrains output to valid JSON; we still defensively
    extract the first {...} block in case a model wraps it in prose."""
    model = model or settings.ollama_model
    payload = {
        "model": model,
        "prompt": prompt,
        "system": system or "",
        "format": "json",
        "stream": False,
        "options": {"temperature": temperature},
    }
    try:
        resp = requests.post(f"{settings.ollama_url}/api/generate", json=payload, timeout=120)
        resp.raise_for_status()
    except requests.RequestException as e:
        raise OllamaError(f"Ollama generate call failed: {e}") from e

    raw = resp.json().get("response", "")
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        m = _JSON_BLOCK_RE.search(raw)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                pass
        raise OllamaError(f"Model did not return valid JSON: {raw[:300]!r}")


def embed(text: str, model: Optional[str] = None) -> list[float]:
    model = model or settings.ollama_embed_model
    try:
        resp = requests.post(
            f"{settings.ollama_url}/api/embeddings",
            json={"model": model, "prompt": text[:8000]},
            timeout=60,
        )
        resp.raise_for_status()
    except requests.RequestException as e:
        raise OllamaError(f"Ollama embeddings call failed: {e}") from e
    return resp.json()["embedding"]


def is_reachable() -> bool:
    try:
        r = requests.get(f"{settings.ollama_url}/api/tags", timeout=5)
        return r.status_code == 200
    except requests.RequestException:
        return False
