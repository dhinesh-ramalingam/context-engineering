"""KNOW-EXTRACT §06 — Drift Detection.

Stability is not the same claim as currency. Where a narrative document's
declared subject matches a live structured source of truth (a Swagger
endpoint, a database table), the pipeline diffs the claim against that
source directly instead of trusting edit-history staleness as a proxy for
correctness. Where no structured counterpart exists, freshness falls back
to the edit-history heuristic — a fallback now, not the primary signal.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

_ENDPOINT_RE = re.compile(r"\b(GET|POST|PUT|PATCH|DELETE)\s+(/[\w/{}]+)", re.IGNORECASE)
_TABLE_COLUMN_HINT_RE = re.compile(r"\b([a-z_]+)\.([a-z_]+)\b")


@dataclass
class DriftFinding:
    drift: bool
    detail: str
    structured_source: str | None = None


def check_api_drift(body_markdown: str, swagger_endpoints: list[dict]) -> DriftFinding:
    """Extracts endpoint mentions (METHOD /path) from prose and diffs them
    against the live Swagger spec's endpoint inventory."""
    mentioned = _ENDPOINT_RE.findall(body_markdown)
    if not mentioned:
        return DriftFinding(drift=False, detail="no endpoint mentioned in prose")

    live_index = {(e["method"].upper(), e["path"]): e for e in swagger_endpoints}
    problems = []
    for method, path in mentioned:
        key = (method.upper(), path)
        if key in live_index:
            ep = live_index[key]
            if ep.get("deprecated"):
                problems.append(f"{method} {path} is DEPRECATED in the live spec — {ep.get('description', '')}".strip())
            continue
        # not found verbatim — see if a newer version of the same resource exists
        same_resource = [e for e in swagger_endpoints if e["path"].split("/")[-1] == path.split("/")[-1] and e["path"] != path]
        if same_resource:
            newer = same_resource[0]
            problems.append(
                f"prose references {method} {path}, but the live spec has moved this to "
                f"{newer['method']} {newer['path']} ({newer.get('description', '')})".strip()
            )
        else:
            problems.append(f"{method} {path} not found in the live spec at all")

    if problems:
        return DriftFinding(drift=True, detail="; ".join(problems), structured_source="swagger")
    return DriftFinding(drift=False, detail="all mentioned endpoints match the live spec")


def check_data_model_drift(body_markdown: str, schema_tables: list[dict]) -> DriftFinding:
    """Extracts table.column mentions from prose and checks they still exist
    in the live schema introspection."""
    mentioned = _TABLE_COLUMN_HINT_RE.findall(body_markdown)
    if not mentioned:
        return DriftFinding(drift=False, detail="no table.column reference in prose")

    tables_by_name = {t["name"]: set(t["columns"]) for t in schema_tables}
    problems = []
    for table, column in mentioned:
        if table not in tables_by_name:
            continue  # not a schema reference, just prose that happens to contain a dot
        if column not in tables_by_name[table]:
            problems.append(f"{table}.{column} referenced in prose but not present in the live schema")
    if problems:
        return DriftFinding(drift=True, detail="; ".join(problems), structured_source="db_schema")
    return DriftFinding(drift=False, detail="all mentioned table.column references match the live schema")
