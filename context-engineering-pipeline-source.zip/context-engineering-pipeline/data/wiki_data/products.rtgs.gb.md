---
title: RTGS — United Kingdom Overlay (CHAPS)
entity_key: products.rtgs.gb
source_type: product_catalog
source_ref: product_catalog-1:PROD-RTGS-GB
candidate_id: cko-19da54006834
viewpoints: [business_domain, regulatory_product]
version: 1
approved_by: S. Idris
published_at: 2026-08-16T20:33:37.974703+00:00
status: Active
---

# RTGS — United Kingdom Overlay (CHAPS)

## Summary
This document outlines UK-specific rules for RTGS payments via CHAPS, including operational constraints and regulatory oversight.

## Purpose
UK-specific rules that extend the RTGS base product for high-value same-day sterling settlement via CHAPS, operated under the Bank of England's RTGS infrastructure.

## Interfaces
- RtgsPaymentRequest (UK) — base schema plus payerSortCode, payeeSortCode.

## Business Rules
- No regulatory minimum amount, but CHAPS is conventionally used for high-value, time-critical payments; low-value transfers should use Faster Payments instead.
- Operating window is 06:00 to 18:00 UK time on CHAPS business days (Bank of England calendar).
- Routing requires a valid UK sort code and account number for both payer and payee, in addition to the base account fields.
- Regulator of record: Bank of England; CHAPS is a systemically important payment system under the Bank of England's oversight.

## Dependencies
- RTGS base product rules
- UK sort code directory
- Bank of England CHAPS business-day calendar

## Source Content
# RTGS — United Kingdom Overlay (CHAPS)

## Purpose
UK-specific rules that extend the RTGS base product for high-value same-day sterling settlement via CHAPS, operated under the Bank of England's RTGS infrastructure.

## Scope
Applies to RTGS payments where the payer or payee account is domiciled in the UK and routed via CHAPS.

## Business Rules (overrides / additions to base)
- No regulatory minimum amount, but CHAPS is conventionally used for high-value, time-critical payments; low-value transfers should use Faster Payments instead.
- Operating window is 06:00 to 18:00 UK time on CHAPS business days (Bank of England calendar).
- Routing requires a valid UK sort code and account number for both payer and payee, in addition to the base account fields.
- Regulator of record: Bank of England; CHAPS is a systemically important payment system under the Bank of England's oversight.

## Interfaces
`RtgsPaymentRequest` (UK) — base schema plus `payerSortCode`, `payeeSortCode`.

## Dependencies
RTGS base product rules, UK sort code directory, Bank of England CHAPS business-day calendar.

## Glossary
CHAPS — Clearing House Automated Payment System, the UK's RTGS-based high-value payment system.

