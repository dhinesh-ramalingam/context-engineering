"""End-to-end demo walkthrough from a clean slate: full pipeline run, human
review decisions across the whole queue, an isolated run + promote cycle,
and a final state summary. This is what task 9 (end-to-end validation)
actually exercises; eval/evaluate.py is run separately afterward."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.models import ObjectStatus, ReviewDecisionAction, RunMode
from pipeline.orchestrator import approve_and_publish, run_pipeline
from pipeline.governance.review_store import ReviewStore

print("=== Full pipeline run (reset) ===")
run = run_pipeline(mode=RunMode.FULL, reset=True)
print(f"run={run.id} status={run.status.value}")
print(run.funnel)

DECISIONS = {
    # (title fragment) -> (reviewer, action, note)
    "FAST Payment cut-off & peak handling": ("R. Tan", "approve", "Matches known policy."),
    "FAST Payment Settlement": ("K. Mensah", "approve", "Architecture overview is accurate."),
    "RTGS — Base Product Rules": ("R. Tan", "approve", "RTGS base rules approved."),
    "RTGS — India Overlay": ("R. Tan", "approve", "India overlay approved."),
    "RTGS — United Kingdom Overlay": ("S. Idris", "approve", "UK overlay approved."),
    "FAST — Singapore (Instant Payment Rail)": ("R. Tan", "approve", "Product catalog entry for FAST approved."),
    "IMPS — India (Immediate Payment Service)": ("R. Tan", "approve", "IMPS product entry approved."),
    "FPS — Hong Kong (Faster Payment System)": ("S. Idris", "approve", "FPS product entry approved."),
    "ACH — United States": ("S. Idris", "approve", "ACH US product entry approved."),
    "ACH — Philippines": ("M. Reyes", "approve", "ACH PH product entry approved."),
    "TT — Singapore (Cross-Border Telegraphic Transfer)": ("R. Tan", "approve", "TT SG product entry approved."),
    "TT — Hong Kong (Cross-Border Telegraphic Transfer)": ("S. Idris", "approve", "TT HK product entry approved."),
    "VAS — Singapore (Value Added Services)": ("K. Mensah", "approve", "VAS SG product entry approved."),
    "Add sanctions screening validation": ("K. Mensah", "approve", "Correct sanctions screening requirement."),
    "AML threshold — Singapore": ("K. Mensah", "approve", "AML threshold confirmed."),
    "Cards dispute SLA definition": ("M. Reyes", "approve", "SLA definition approved."),
    "Failed settlement retry runbook": ("A. Novak", "approve", "Runbook is current."),
    "SRE on-call": ("K. Mensah", "approve", "Runbook is current."),
    "FX quote endpoint returns stale rate": ("S. Idris", "approve", "Valid bug, tracked."),
    "As an ops user": ("A. Novak", "approve", "Valid story."),
    "As a merchant": ("S. Idris", "approve", "Valid story."),
    "Singapore FAST Enhancement Program": ("R. Tan", "approve", "Epic approved."),
    "FAST Real-Time Settlement Enhancements": ("R. Tan", "approve", "Feature approved."),
    "Update AML threshold documentation": ("K. Mensah", "approve", "Wording clarification approved."),
    "FAST Payment cut-off time": ("A. Novak", "reject", "Superseded by the approved 22:00/23:30 policy; this page is stale."),
    "random notes": ("A. Novak", "reject", "Stale scratch notes, no actionable content."),
}

print("\n=== Human review pass ===")
store = ReviewStore()
pending = store.list_candidates(status=ObjectStatus.PENDING_REVIEW)
processed = set()
# process the conflict pair last so the canonical exists first
ordering = sorted(pending, key=lambda c: 0 if "cut-off & peak" in c.title else 1)
for c in ordering:
    match = next((k for k in DECISIONS if k in c.title), None)
    if not match:
        print(f"  SKIP (no rule): {c.title}")
        continue
    reviewer, action, note = DECISIONS[match]
    result = approve_and_publish(c.id, reviewer=reviewer, action=ReviewDecisionAction(action), note=note)
    processed.add(c.id)
    print(f"  {action:8} by {reviewer:10} {c.title[:50]}")

remaining = store.list_candidates(status=ObjectStatus.PENDING_REVIEW)
print(f"\nremaining pending: {len(remaining)} -> {[c.title for c in remaining]}")

print("\n=== Isolated run + promote cycle ===")
iso_run = run_pipeline(mode=RunMode.ISOLATED, reset=False)
print(f"isolated run={iso_run.id} status={iso_run.status.value} funnel={iso_run.funnel}")

from pipeline.indexing import es_index
from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.config import settings

client = es_index.get_client()
client.indices.refresh(index=settings.es_index_staging)
staging_count = client.count(index=settings.es_index_staging)["count"]
print(f"staging index doc count before promote: {staging_count}")

graph = GraphBuilder()
graph.promote_staging()
graph.close()
n = es_index.promote_staging_to_prod(client, settings.es_index_staging, settings.es_index_prod)
print(f"promoted {n} docs staging -> production")

print("\nDone.")
