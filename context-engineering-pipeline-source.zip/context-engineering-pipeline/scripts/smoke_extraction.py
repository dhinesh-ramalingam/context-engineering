"""Manual smoke test for Tier 0 / Tier 1 / drift detection / entity
resolution against the real mock corpus — not part of the eval suite."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.config import settings
from pipeline.connectors import CONNECTOR_REGISTRY
from pipeline.extraction.drift_detection import check_api_drift
from pipeline.extraction.entity_resolution import Glossary, resolve_entity
from pipeline.extraction.regimes import normalize_narrative
from pipeline.extraction.tier0_gate import evaluate_tier0
from pipeline.extraction.tier1_statistical import Bm25Corpus, DOMAIN_LEXICON, find_near_duplicates

SOURCE_DIRS = {
    "ado": settings.mock_sources_dir / "ado",
    "confluence": settings.mock_sources_dir / "confluence",
    "runbook": settings.mock_sources_dir / "runbooks",
    "product_catalog": settings.mock_sources_dir / "product_catalog",
}

narrative_docs = []
for source_type, root in SOURCE_DIRS.items():
    cls = CONNECTOR_REGISTRY[source_type]
    conn = cls(connector_id=f"{source_type}-1", name=source_type, root=root)
    for item_id in conn.list_items():
        raw = conn.fetch(item_id)
        doc = normalize_narrative(raw, source_type, conn.connector_id)
        narrative_docs.append(doc)

print(f"=== Tier 0 gate — {len(narrative_docs)} narrative docs ===")
survivors = []
for doc in narrative_docs:
    verdict, conditions = evaluate_tier0(doc)
    failed = [c.condition for c in conditions if not c.passed]
    print(f"[{verdict.value:12}] {doc.source_type:8} {doc.title[:55]:55} failed={failed}")
    if verdict.value in ("candidate", "needs_review"):
        survivors.append(doc)

print(f"\n=== Tier 1 BM25 relevance — {len(survivors)} Tier-0 survivors ===")
corpus = Bm25Corpus.build([d.body_markdown for d in survivors])
for doc in survivors:
    score = corpus.score(doc.body_markdown, DOMAIN_LEXICON)
    flag = "OK" if score >= settings.bm25_relevance_floor else "BELOW FLOOR"
    print(f"[{score:.3f} {flag:12}] {doc.title[:60]}")

print("\n=== Near-duplicate check (synthetic pair, proves mechanism) ===")
pairs = find_near_duplicates([
    ("a", "The FAST cut-off is 22:00 SGT extended to 23:30 during peak periods for same day transfers."),
    ("b", "The FAST cut-off is 22:00 SGT extended to 23:30 during peak periods for same-day transfers."),
    ("c", "RTGS in India requires a valid IFSC code for both payer and payee bank branch."),
])
for a, b, sim in pairs:
    print(f"near-dup: {a} <-> {b} sim={sim:.2f}")

print("\n=== Drift detection — FX API stale Confluence page vs live Swagger v2 ===")
swagger_conn = CONNECTOR_REGISTRY["swagger"](connector_id="swagger-1", name="swagger", root=settings.mock_sources_dir / "swagger")
swagger_raw = swagger_conn.fetch("fx-rates-api")
endpoints = swagger_raw.content["endpoints"]
stale_doc = next(d for d in narrative_docs if d.source_item_id == "CONF-1004")
finding = check_api_drift(stale_doc.body_markdown, endpoints)
print(f"drift={finding.drift} detail={finding.detail}")

print("\n=== Entity resolution ===")
glossary = Glossary()
for doc in survivors:
    match = resolve_entity(doc.title, doc.body_markdown, glossary)
    print(f"[{match.method:10} {match.score:.2f}] {doc.title[:45]:45} -> {match.entity_key}")
