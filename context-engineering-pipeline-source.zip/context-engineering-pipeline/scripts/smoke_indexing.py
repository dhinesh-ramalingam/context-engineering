import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.config import settings
from pipeline.indexing import es_index
from pipeline.indexing.embeddings import get_default_cache
from pipeline.indexing.graph_builder import GraphBuilder

print("=== Neo4j: constraints + product hierarchy + code graph ===")
gb = GraphBuilder()
gb.ensure_constraints()
gb.wipe_env("production")  # clean slate for repeatable smoke test

gb.upsert_entity("products.rtgs", "RTGS — base product", "payments")
gb.upsert_entity("products.rtgs.in", "RTGS — India overlay", "payments")
gb.upsert_product("products.rtgs.base", "RTGS", "payments", "base", None, None)
gb.upsert_product("products.rtgs.in", "RTGS", "payments", "variant", "IN", "products.rtgs.base")

gb.upsert_code_class("payments-core:PaymentDispatcher", "PaymentDispatcher", "com.payments.core", "payments-core", "src/PaymentDispatcher.java")
gb.upsert_code_class("payments-core:SanctionsService", "SanctionsService", "com.payments.core.sanctions", "payments-core", "src/SanctionsService.java")
gb.link_code_depends_on("payments-core:PaymentDispatcher", "payments-core:SanctionsService")
gb.upsert_db_table("payments:sanctions_check", "payments", "sanctions_check", ["uetr", "counterparty_id", "result"])
gb.link_code_reads_writes("payments-core:SanctionsService", "payments:sanctions_check", ["read", "write"])

gb.upsert_component("PaymentDispatcher", "component")
gb.upsert_component("Kafka: payments.settlement", "queue")
gb.upsert_component("Clearing Service", "component")
gb.link_component_flow("PaymentDispatcher", "Kafka: payments.settlement", "dispatch")
gb.link_component_flow("Kafka: payments.settlement", "Clearing Service", "consume")
gb.link_component_to_code("PaymentDispatcher", "payments-core:PaymentDispatcher")

gb.upsert_incident_signature("sig-1", "SanctionsService", "SCREENING_TIMEOUT", 4, "2026-08-14T22:07:45Z", "2026-08-14T23:41:12Z")

neighbors = gb.neighbors("CodeClass", "key", "payments-core:PaymentDispatcher", hops=2)
print(f"blast radius of PaymentDispatcher ({len(neighbors)} nodes):")
for n in neighbors:
    print(" ", n["labels"], n["node"].get("name") or n["node"].get("key"), "dist=", n["distance"])

hierarchy = gb.product_hierarchy("RTGS")
print("\nproduct hierarchy for RTGS:")
for row in hierarchy:
    print(" ", row["product"].get("key"), "-> base:", row["base_product"].get("key") if row["base_product"] else None)

print("\nincident count for SanctionsService:", gb.incident_count("SanctionsService"))
gb.close()

print("\n=== Elasticsearch: index + BM25 + dense search ===")
client = es_index.get_client()
idx = "ctxeng-smoke-test"
client.options(ignore_status=[404]).indices.delete(index=idx)
es_index.ensure_index(client, idx)

cache = get_default_cache()
docs = [
    ("doc-1", "FAST Payment cut-off & peak handling", "Cut-off for same-day FAST transfer is 22:00 SGT, extended to 23:30 during peak periods."),
    ("doc-2", "RTGS India overlay", "RTGS in India requires a valid IFSC code and a minimum amount of INR 2,00,000."),
    ("doc-3", "Sanctions screening runbook", "SanctionsService screening timeout escalates to manual review."),
]
for doc_id, title, body in docs:
    vector, content_hash, cached = cache.get_or_embed(title + " " + body)
    es_index.upsert(client, idx, doc_id, {"title": title, "body": body, "source_type": "confluence", "content_hash": content_hash}, vector)
client.indices.refresh(index=idx)

bm25_hits = es_index.search_bm25(client, idx, "FAST cut-off time")
print("BM25 'FAST cut-off time':", [(h["id"], round(h["score"], 2)) for h in bm25_hits])

query_vec, _, _ = cache.get_or_embed("What is the India RTGS minimum transaction amount?")
dense_hits = es_index.search_dense(client, idx, query_vec)
print("dense 'India RTGS minimum amount':", [(h["id"], round(h["score"], 3)) for h in dense_hits])

client.indices.delete(index=idx)
print("\nsmoke test index cleaned up.")
