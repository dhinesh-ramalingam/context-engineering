import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.config import settings
from pipeline.connectors import CONNECTOR_REGISTRY
from pipeline.extraction.conflict_scoring import score_conflict
from pipeline.extraction.entity_resolution import Glossary, resolve_entity
from pipeline.extraction.regimes import normalize_narrative
from pipeline.extraction.tier2_llm import structure_candidate
from pipeline.governance.review_store import ReviewStore, SegregationOfDutiesError
from pipeline.governance.wiki_publish import WikiRepo
from pipeline.models import (
    SOURCE_DEFAULT_VIEWPOINTS,
    CandidateKnowledgeObject,
    ConflictRecord,
    ObjectStatus,
    ReviewDecisionAction,
)

conn = CONNECTOR_REGISTRY["confluence"](connector_id="confluence-1", name="confluence", root=settings.mock_sources_dir / "confluence")
glossary = Glossary()
store = ReviewStore()
wiki = WikiRepo()


def build_candidate(item_id: str) -> CandidateKnowledgeObject:
    raw = conn.fetch(item_id)
    doc = normalize_narrative(raw, "confluence", conn.connector_id)
    match = resolve_entity(doc.title, doc.body_markdown, glossary)
    structured = structure_candidate(doc.title, doc.body_markdown, doc.doc_type, SOURCE_DEFAULT_VIEWPOINTS["confluence"])
    obj = CandidateKnowledgeObject(
        source_connector_id=conn.connector_id, source_type="confluence", source_item_id=item_id,
        source_updated=doc.updated, title=doc.title, body=doc.body_markdown,
        viewpoints=structured["viewpoints"], canonical_entity_key=match.entity_key,
        confidence=0.9, status=ObjectStatus.DRAFT,
        purpose=structured["purpose"], interfaces=structured["interfaces"],
        constraints=structured["constraints"], business_rules=structured["business_rules"],
        open_questions=structured["open_questions"], dependencies=structured["dependencies"],
        summary=structured["summary"],
    )
    store.save_candidate(obj)
    return obj


print("=== Step 1: publish the canonical FAST cut-off article first ===")
canonical_obj = build_candidate("fast-cutoff-canonical")
store.submit_for_review(canonical_obj.id)
decision = store.decide(canonical_obj.id, reviewer="R. Tan", action=ReviewDecisionAction.APPROVE, note="Matches known policy.")
print("decision:", decision.action, "by", decision.reviewer)
publish_result = wiki.publish(store.get_candidate(canonical_obj.id), approved_by="R. Tan")
print("published:", publish_result)

print("\n=== Step 2: segregation-of-duties check (service account reviewer must be rejected) ===")
conflicting_obj = build_candidate("fast-cutoff-conflicting-draft")
print("entity_key resolved:", conflicting_obj.canonical_entity_key)
store.submit_for_review(conflicting_obj.id)
try:
    store.decide(conflicting_obj.id, reviewer="pipeline-system", action=ReviewDecisionAction.APPROVE)
    print("BUG: service-account reviewer was allowed!")
except SegregationOfDutiesError as e:
    print("correctly rejected:", e)

print("\n=== Step 3: conflict scoring against the now-canonical article ===")
canonical_article = wiki.get(conflicting_obj.canonical_entity_key)
conflict = score_conflict(conflicting_obj.body, canonical_article["body"])
print("conflict:", conflict)
record = ConflictRecord(candidate_id=conflicting_obj.id, canonical_id=canonical_obj.id,
                          severity=conflict["severity"], rationale=conflict["rationale"])
store.save_conflict(record)

print("\n=== Step 4: named human reviewer rejects the conflicting candidate ===")
decision = store.decide(conflicting_obj.id, reviewer="A. Novak", action=ReviewDecisionAction.REJECT,
                          note="Superseded by the approved 22:00/23:30 policy; this page is stale.",
                          canonical_text=canonical_article["body"])
print("decision:", decision.action, "by", decision.reviewer)

print("\n=== Audit log for the conflicting candidate ===")
for entry in store.audit_log(conflicting_obj.id):
    print(f"  [{entry['timestamp']}] {entry['actor']} -> {entry['action']} why={entry['why']}")

print("\n=== Wiki history for payments.fast_cutoff ===")
for h in wiki.history("payments.fast_cutoff"):
    print(f"  {h['sha'][:8]} {h['date']} {h['message'].splitlines()[0]}")

print("\n=== Wiki article listing ===")
for a in wiki.list_articles():
    print(" ", a)
