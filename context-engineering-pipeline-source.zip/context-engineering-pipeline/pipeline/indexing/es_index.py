"""Elasticsearch as the pluggable Vector Store adapter (KNOW-PIPE §04) — BM25
text search and dense-vector kNN behind one client, selected per environment
via config. Staging vs. production are separate indices so an Isolated Run
(KNOW-PIPE §06) never leaks into what agents actually retrieve from until an
explicit promote action reindexes staging -> production.
"""
from __future__ import annotations

from typing import Any, Optional

from elasticsearch import Elasticsearch

from pipeline.config import settings

_MAPPING = {
    "properties": {
        "title": {"type": "text"},
        "body": {"type": "text"},
        "summary": {"type": "text"},
        "source_type": {"type": "keyword"},
        "doc_type": {"type": "keyword"},
        "viewpoints": {"type": "keyword"},
        "entity_key": {"type": "keyword"},
        "product_code": {"type": "keyword"},
        "product_scope": {"type": "keyword"},
        "product_variant_key": {"type": "keyword"},
        "approved_by": {"type": "keyword"},
        "version": {"type": "integer"},
        "content_hash": {"type": "keyword"},
        "candidate_id": {"type": "keyword"},
        "vector": {"type": "dense_vector", "dims": settings.embedding_dims, "index": True, "similarity": "cosine"},
    }
}


def get_client() -> Elasticsearch:
    return Elasticsearch(settings.elasticsearch_url)


def ensure_index(client: Elasticsearch, index_name: str) -> None:
    if not client.indices.exists(index=index_name):
        client.indices.create(index=index_name, mappings=_MAPPING)


def upsert(client: Elasticsearch, index_name: str, doc_id: str, fields: dict[str, Any], vector: list[float]) -> None:
    client.index(index=index_name, id=doc_id, document={**fields, "vector": vector})


def delete(client: Elasticsearch, index_name: str, doc_id: str) -> None:
    client.options(ignore_status=[404]).delete(index=index_name, id=doc_id)


def search_bm25(client: Elasticsearch, index_name: str, query: str, filters: Optional[dict] = None,
                 size: int = 10) -> list[dict]:
    must = [{"multi_match": {"query": query, "fields": ["title^2", "body", "summary"]}}]
    filter_clauses = _build_filters(filters)
    body = {"query": {"bool": {"must": must, "filter": filter_clauses}}, "size": size}
    resp = client.search(index=index_name, **body)
    return [{"id": h["_id"], "score": h["_score"], **h["_source"]} for h in resp["hits"]["hits"]]


def search_dense(client: Elasticsearch, index_name: str, query_vector: list[float], filters: Optional[dict] = None,
                  k: int = 10) -> list[dict]:
    knn = {
        "field": "vector", "query_vector": query_vector, "k": k, "num_candidates": max(50, k * 5),
    }
    filter_clauses = _build_filters(filters)
    if filter_clauses:
        knn["filter"] = {"bool": {"filter": filter_clauses}}
    resp = client.search(index=index_name, knn=knn, size=k)
    return [{"id": h["_id"], "score": h["_score"], **h["_source"]} for h in resp["hits"]["hits"]]


def get_by_field(client: Elasticsearch, index_name: str, field: str, value: str, size: int = 1) -> list[dict]:
    """Pure filter lookup — no relevance query. Used for exact-key fetches
    (e.g. a resolved entity_key) where the key itself isn't expected to
    appear as matchable text in the document body."""
    resp = client.search(index=index_name, query={"term": {field: value}}, size=size)
    return [{"id": h["_id"], "score": h["_score"], **h["_source"]} for h in resp["hits"]["hits"]]


def _build_filters(filters: Optional[dict]) -> list[dict]:
    if not filters:
        return []
    clauses = []
    for field, value in filters.items():
        if isinstance(value, (list, tuple)):
            clauses.append({"terms": {field: list(value)}})
        else:
            clauses.append({"term": {field: value}})
    return clauses


def promote_staging_to_prod(client: Elasticsearch, staging_index: str, prod_index: str) -> int:
    ensure_index(client, prod_index)
    resp = client.reindex(source={"index": staging_index}, dest={"index": prod_index}, refresh=True)
    return resp.get("total", 0)


def index_name_for(env: str) -> str:
    return settings.es_index_staging if env == "staging" else settings.es_index_prod
