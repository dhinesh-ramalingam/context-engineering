---
title: RTGS — Base Product Rules
entity_key: products.rtgs
source_type: product_catalog
source_ref: product_catalog-1:PROD-RTGS-BASE
candidate_id: cko-747129ebea95
viewpoints: [business_domain, business_process, regulatory_product]
version: 1
approved_by: R. Tan
published_at: 2026-08-16T20:34:05.688247+00:00
status: Active
---

# RTGS — Base Product Rules

## Summary
This document outlines the foundational rules for Real-Time Gross Settlement (RTGS) products, applicable across all markets where such services are offered. It defines key business rules and dependencies without including country-specific details.

## Purpose
Defines the rail-agnostic base rules for Real-Time Gross Settlement (RTGS) products before any country-specific regulatory overlay is applied. Country implementations extend this base and may narrow or add constraints — they never relax them.

## Interfaces
- RtgsPaymentRequest

## Business Rules
- - RTGS settles gross, in real time, transaction by transaction — no netting.
- - Once settled, an RTGS payment is final and irrevocable.
- - A base RTGS payment requires: payer account, payee account, amount, currency, and a settlement reference.

## Dependencies
- Core Banking ledger
- Settlement service

## Source Content
# RTGS — Base Product Rules

## Purpose
Defines the rail-agnostic base rules for Real-Time Gross Settlement (RTGS) products before any country-specific regulatory overlay is applied. Country implementations (see country variant pages) extend this base and may narrow or add constraints — they never relax them.

## Scope
Applies to every market where the platform offers an RTGS product. Country-specific operating hours, minimum amounts, and routing schemes are defined in each country variant page, not here.

## Business Rules
- RTGS settles gross, in real time, transaction by transaction — no netting.
- Once settled, an RTGS payment is final and irrevocable.
- A base RTGS payment requires: payer account, payee account, amount, currency, and a settlement reference.
- Country variants may impose additional mandatory fields (see each country's variant page).

## Interfaces
`RtgsPaymentRequest` — base schema: `payerAccount`, `payeeAccount`, `amountMinorUnits`, `currency`, `settlementReference`.

## Dependencies
Core Banking ledger, Settlement service.

## Glossary
RTGS — Real-Time Gross Settlement.

