"""Manual smoke test — not part of the eval suite. Confirms every connector
can connect, list, and fetch at least one item from the mock corpus."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.config import settings
from pipeline.connectors import CONNECTOR_REGISTRY

SOURCE_DIRS = {
    "ado": settings.mock_sources_dir / "ado",
    "confluence": settings.mock_sources_dir / "confluence",
    "git": settings.mock_sources_dir / "git_payments_core",
    "db_schema": settings.mock_sources_dir / "db_schema",
    "swagger": settings.mock_sources_dir / "swagger",
    "plantuml": settings.mock_sources_dir / "plantuml",
    "runbook": settings.mock_sources_dir / "runbooks",
    "logs": settings.mock_sources_dir / "logs",
    "product_catalog": settings.mock_sources_dir / "product_catalog",
}

for source_type, cls in CONNECTOR_REGISTRY.items():
    root = SOURCE_DIRS[source_type]
    conn = cls(connector_id=f"{source_type}-1", name=source_type, root=root)
    ok = conn.connect()
    items = list(conn.list_items())
    print(f"[{source_type:16}] connect={ok} items={len(items)} -> {items[:3]}")
    if items:
        raw = conn.fetch(items[0])
        title = raw.content.get("title") if isinstance(raw.content, dict) else str(raw.content)[:40]
        print(f"{'':18} fetched '{items[0]}' updated={raw.updated!r} title={title!r}")
