from __future__ import annotations

from typing import Iterable

import yaml

from .base import RawItem, SourceConnector


class SwaggerConnector(SourceConnector):
    """Structured regime (KNOW-EXTRACT §03) — parsed, not graded. Also the
    structured source of truth §06 drift detection diffs narrative claims
    against."""

    source_type = "swagger"

    def connect(self) -> bool:
        return self.root.exists()

    def list_items(self) -> Iterable[str]:
        for p in sorted(self.root.glob("*.yaml")) + sorted(self.root.glob("*.yml")):
            yield p.stem

    def fetch(self, item_id: str) -> RawItem:
        path = self._find(item_id)
        spec = yaml.safe_load(self._read_text(path))
        endpoints = []
        for route, methods in (spec.get("paths") or {}).items():
            for method, detail in methods.items():
                endpoints.append({
                    "path": route,
                    "method": method.upper(),
                    "deprecated": bool(detail.get("deprecated")),
                    "summary": detail.get("summary", ""),
                    "description": detail.get("description", ""),
                })
        return RawItem(
            item_id=item_id,
            content={"spec": spec, "endpoints": endpoints, "title": spec.get("info", {}).get("title", item_id)},
            content_format="json",
            updated=spec.get("info", {}).get("version", ""),
            path=str(path),
            metadata={"endpoints": endpoints},
        )

    def _find(self, item_id: str):
        for ext in ("yaml", "yml"):
            p = self.root / f"{item_id}.{ext}"
            if p.exists():
                return p
        raise FileNotFoundError(item_id)
