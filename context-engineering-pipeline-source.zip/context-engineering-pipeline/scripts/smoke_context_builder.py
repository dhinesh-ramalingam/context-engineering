import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.serving.context_builder import ContextBuilder

cb = ContextBuilder(env="production")
bundle = cb.build("Implement payment validation for sanctions screening", agent_role="developer")
print("intent:", bundle.intent, "confidence:", bundle.intent_confidence)
print("items:", [(i.id, i.title, round(i.score, 3)) for i in bundle.items])
print("tokens_used:", bundle.tokens_used, "/", bundle.token_budget)
print("guardrail_clean:", bundle.guardrail_clean)
cb.close()
