"""Content-hash-cached embeddings — Context-Engineering-Platform-Design
Layer 06/11: 'recompute a card only when its source content hash changes.'
A knowledge card carries 'already embedded, hash X' so Ollama only runs on
genuinely new or changed content, not on every request."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from pipeline.config import settings
from pipeline.llm_client import embed as _ollama_embed

_CACHE_PATH = settings.data_dir / "embedding_cache.json"


class EmbeddingCache:
    def __init__(self, path: Path = _CACHE_PATH):
        self.path = path
        self._cache: dict[str, list[float]] = {}
        if path.exists():
            self._cache = json.loads(path.read_text(encoding="utf-8"))

    @staticmethod
    def hash_of(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def get_or_embed(self, text: str) -> tuple[list[float], str, bool]:
        """Returns (vector, content_hash, was_cached)."""
        h = self.hash_of(text)
        if h in self._cache:
            return self._cache[h], h, True
        vector = _ollama_embed(text)
        self._cache[h] = vector
        self._save()
        return vector, h, False

    def _save(self) -> None:
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self._cache), encoding="utf-8")


_default_cache: EmbeddingCache | None = None


def get_default_cache() -> EmbeddingCache:
    global _default_cache
    if _default_cache is None:
        _default_cache = EmbeddingCache()
    return _default_cache
