---
title: Failed settlement retry runbook
owner: A. Novak
status: Active
version: 4
labels: [runbook, operational, settlement, approved]
updated: 2026-07-10
---

# Failed settlement retry runbook

## Purpose
Steps for the payments SRE on-call when a FAST settlement fails to confirm within the expected window.

## Scope
Applies to FAST rail settlements only. Card rail failures follow a separate runbook.

## Procedure
1. Check the settlement retry dashboard for the affected UETR.
2. If attempt count < 3, allow the automatic retry policy to continue — no action needed.
3. If attempt count >= 3, check the Clearing Service error log for the specific rejection reason.
4. If the rejection reason is `CLEARING_TIMEOUT`, escalate to the FAST network operator via the standard incident channel.
5. If the rejection reason is `SANCTIONS_ESCALATION`, route to the AML on-call queue — do not manually override.
6. Manual override of the retry schedule must be logged with the acting engineer's identity per story 48214.

## Interfaces
Reads from the `payments.settlement` Kafka topic consumer lag dashboard and the Clearing Service error log.

## Errors
`CLEARING_TIMEOUT`, `SANCTIONS_ESCALATION`, `FX_QUOTE_EXPIRED` are the three retryable rejection reasons currently handled by this runbook.

## Dependencies
Clearing Service, PaymentDispatcher, AML on-call queue.
