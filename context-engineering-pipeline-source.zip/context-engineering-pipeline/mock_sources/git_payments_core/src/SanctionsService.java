package com.payments.core.sanctions;

/**
 * Screens a counterparty against the sanctions list before a payment is
 * dispatched. Screening must complete within the dispatch budget; a timeout
 * escalates to manual review rather than failing open or failing closed.
 *
 * @db-table payments.sanctions_check (read, write)
 */
public class SanctionsService {

    private static final long SCREENING_TIMEOUT_MS = 180;

    public ScreeningResult screen(Counterparty counterparty) {
        // In production this calls the sanctions list provider with a hard
        // timeout budget so PaymentDispatcher.dispatch() stays under 200ms.
        throw new UnsupportedOperationException("stub for mock corpus");
    }
}
