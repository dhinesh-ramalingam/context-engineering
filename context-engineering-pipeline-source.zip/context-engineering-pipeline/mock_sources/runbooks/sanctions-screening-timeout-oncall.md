---
title: SRE on-call — sanctions screening timeout
owner: K. Mensah
status: Active
version: 2
labels: [runbook, operational, sanctions, oncall]
updated: 2026-07-20
---

# SRE on-call — sanctions screening timeout

## Purpose
What to do when SanctionsService.screen() is timing out for a sustained period, causing payments to escalate to manual review instead of dispatching.

## Scope
Applies to the Singapore FAST rail sanctions screening step in PaymentDispatcher.

## Procedure
1. Check the sanctions provider status page for an outage.
2. Check `sanctions_check.screening_latency_ms` in the payments schema for a latency spike vs. the 180ms internal timeout budget.
3. If the provider is degraded, page the compliance on-call — escalated payments must go through manual review, they are not queued automatically.
4. Do not disable screening to relieve backlog under any circumstance.

## Interfaces
Reads `sanctions_check` table (payments schema) and the sanctions provider status page.

## Dependencies
SanctionsService, PaymentDispatcher, compliance on-call rotation.
