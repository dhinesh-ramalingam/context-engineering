"""Environment-driven settings. Every value has a local-only default so the
pipeline runs out of the box against docker-compose + local Ollama with no
.env file required — .env only overrides."""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _env(name: str, default: str) -> str:
    return os.environ.get(name, default)


class Settings:
    neo4j_uri: str = _env("NEO4J_URI", "bolt://localhost:7688")
    neo4j_user: str = _env("NEO4J_USER", "neo4j")
    neo4j_password: str = _env("NEO4J_PASSWORD", "ctxeng-local-only")

    elasticsearch_url: str = _env("ELASTICSEARCH_URL", "http://localhost:9200")
    es_index_prod: str = _env("ES_INDEX_PROD", "ctxeng-knowledge")
    es_index_staging: str = _env("ES_INDEX_STAGING", "ctxeng-knowledge-staging")

    ollama_url: str = _env("OLLAMA_URL", "http://localhost:11434")
    ollama_model: str = _env("OLLAMA_MODEL", "qwen2.5:7b")
    ollama_embed_model: str = _env("OLLAMA_EMBED_MODEL", "nomic-embed-text")
    embedding_dims: int = 768  # nomic-embed-text output size

    data_dir: Path = Path(_env("DATA_DIR", str(ROOT / "data")))
    mock_sources_dir: Path = Path(_env("MOCK_SOURCES_DIR", str(ROOT / "mock_sources")))
    wiki_repo_dir: Path = Path(_env("WIKI_REPO_DIR", str(ROOT / "data" / "wiki_data")))

    # Tier-0 gate version — bumping this re-labels every future verdict with
    # a new gate_version while leaving historical verdicts attributed to the
    # version that actually produced them (KNOW-EXTRACT §10).
    gate_version: str = "tier0-v1"

    # Tier-1 thresholds (raw BM25 scale — see extraction/tier1_statistical.py)
    bm25_relevance_floor: float = 1.0
    near_dup_similarity_threshold: float = 0.88

    # Context assembly
    default_token_budget: int = 6000

    def __init__(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)


settings = Settings()
