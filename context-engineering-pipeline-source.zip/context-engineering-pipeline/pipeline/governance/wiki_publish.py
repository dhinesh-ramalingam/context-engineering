"""Enterprise Knowledge Wiki — KNOW-PIPE §02 stage 7.

Approved knowledge objects only. Published as versioned markdown in a git
repo dedicated to this pipeline (isolated from the outer workspace) —
version, publish, retire superseded articles, keep full provenance. One
canonical article per resolved entity key; republishing the same entity key
supersedes the prior version and the git history is the version log.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from git import Repo

from pipeline.config import settings
from pipeline.models import CandidateKnowledgeObject, now_iso

_FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---\n(.*)$", re.DOTALL)


def _slug(entity_key_or_id: str) -> str:
    return re.sub(r"[^a-z0-9_.\-]+", "-", entity_key_or_id.lower()).strip("-")


def _render(obj: CandidateKnowledgeObject, version: int, approved_by: str) -> str:
    labels = ", ".join(obj.viewpoints)
    fm = (
        "---\n"
        f"title: {obj.title}\n"
        f"entity_key: {obj.canonical_entity_key or obj.id}\n"
        f"source_type: {obj.source_type.value}\n"
        f"source_ref: {obj.source_connector_id}:{obj.source_item_id}\n"
        f"candidate_id: {obj.id}\n"
        f"viewpoints: [{labels}]\n"
        f"version: {version}\n"
        f"approved_by: {approved_by}\n"
        f"published_at: {now_iso()}\n"
        "status: Active\n"
        "---\n"
    )
    body_parts = [f"# {obj.title}\n"]
    if obj.summary:
        body_parts.append(f"## Summary\n{obj.summary}\n")
    if obj.purpose:
        body_parts.append(f"## Purpose\n{obj.purpose}\n")
    if obj.interfaces:
        body_parts.append("## Interfaces\n" + "\n".join(f"- {i}" for i in obj.interfaces) + "\n")
    if obj.constraints:
        body_parts.append("## Constraints\n" + "\n".join(f"- {c}" for c in obj.constraints) + "\n")
    if obj.business_rules:
        body_parts.append("## Business Rules\n" + "\n".join(f"- {r}" for r in obj.business_rules) + "\n")
    if obj.dependencies:
        body_parts.append("## Dependencies\n" + "\n".join(f"- {d}" for d in obj.dependencies) + "\n")
    if obj.open_questions:
        body_parts.append("## Open Questions\n" + "\n".join(f"- {q}" for q in obj.open_questions) + "\n")
    body_parts.append(f"## Source Content\n{obj.body}\n")
    return fm + "\n" + "\n".join(body_parts)


def _parse(text: str) -> tuple[dict, str]:
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}, text
    meta: dict = {}
    for line in m.group(1).splitlines():
        if ":" not in line:
            continue
        k, _, v = line.partition(":")
        meta[k.strip()] = v.strip()
    return meta, m.group(2)


class WikiRepo:
    def __init__(self, root: Optional[Path] = None):
        self.root = root or settings.wiki_repo_dir
        self.root.mkdir(parents=True, exist_ok=True)
        if not (self.root / ".git").exists():
            self.repo = Repo.init(self.root)
            with self.repo.config_writer() as cw:
                cw.set_value("user", "name", "Enterprise Knowledge Wiki")
                cw.set_value("user", "email", "wiki@ctxeng.local")
            (self.root / ".gitkeep").write_text("", encoding="utf-8")
            self.repo.index.add([".gitkeep"])
            self.repo.index.commit("Initialize enterprise knowledge wiki")
        else:
            self.repo = Repo(self.root)

    def _path_for(self, entity_key_or_id: str) -> Path:
        return self.root / f"{_slug(entity_key_or_id)}.md"

    def get(self, entity_key_or_id: str) -> Optional[dict]:
        path = self._path_for(entity_key_or_id)
        if not path.exists():
            return None
        meta, body = _parse(path.read_text(encoding="utf-8"))
        return {"meta": meta, "body": body, "path": str(path)}

    def list_articles(self) -> list[dict]:
        out = []
        for p in sorted(self.root.glob("*.md")):
            meta, _ = _parse(p.read_text(encoding="utf-8"))
            if meta:
                out.append(meta)
        return out

    def publish(self, obj: CandidateKnowledgeObject, approved_by: str) -> dict:
        entity_key = obj.canonical_entity_key or obj.id
        existing = self.get(entity_key)
        version = int(existing["meta"].get("version", "0")) + 1 if existing else 1

        content = _render(obj, version=version, approved_by=approved_by)
        path = self._path_for(entity_key)
        path.write_text(content, encoding="utf-8")

        self.repo.index.add([str(path.relative_to(self.root))])
        action = "Update" if existing else "Publish"
        commit = self.repo.index.commit(
            f"{action} '{obj.title}' (v{version}) — approved by {approved_by}\n\n"
            f"candidate_id={obj.id} entity_key={entity_key} source={obj.source_connector_id}:{obj.source_item_id}",
        )
        return {"entity_key": entity_key, "version": version, "commit": commit.hexsha, "path": str(path)}

    def history(self, entity_key_or_id: str) -> list[dict]:
        path = self._path_for(entity_key_or_id)
        rel = path.relative_to(self.root)
        commits = list(self.repo.iter_commits(paths=str(rel)))
        return [{"sha": c.hexsha, "message": c.message, "date": c.committed_datetime.isoformat()} for c in commits]
