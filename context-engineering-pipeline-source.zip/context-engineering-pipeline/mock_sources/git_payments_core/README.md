# payments-core

Core payment dispatch and validation services for the Singapore FAST rail.

## Modules

- `PaymentDispatcher` — routes a validated, sanctions-cleared payment to the correct clearing rail and handles settlement acknowledgements.
- `SanctionsService` — screens a counterparty against the sanctions list before dispatch.
- `PaymentValidator` — validates an inbound payment request (structure, currency, limits) before it reaches the dispatcher.

## Build

`./gradlew build`

## Conventions

- All monetary amounts are minor units (cents), never floating point.
- Every payment carries a UETR (Unique End-to-end Transaction Reference) used for idempotency and cross-service correlation.
- Dispatch must complete within 200ms; anything that can't meet that budget (e.g. sanctions screening) runs with its own timeout and a defined escalation path, not inline blocking.
