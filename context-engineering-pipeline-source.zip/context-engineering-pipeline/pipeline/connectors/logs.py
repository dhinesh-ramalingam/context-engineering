from __future__ import annotations

import re
from collections import Counter
from typing import Iterable

from .base import RawItem, SourceConnector

_LINE_RE = re.compile(
    r"^(?P<ts>\S+)\s+(?P<level>\w+)\s+(?P<component>\w+)\s+(?P<fields>.*)$"
)


class LogsConnector(SourceConnector):
    """Telemetry regime (KNOW-EXTRACT §03) — aggregated into error-signature
    clusters. No per-line item ever enters the extraction funnel; only the
    resulting cluster summaries do."""

    source_type = "logs"

    def connect(self) -> bool:
        return self.root.exists()

    def list_items(self) -> Iterable[str]:
        for p in sorted(self.root.glob("*.log")):
            yield p.stem

    def fetch(self, item_id: str) -> RawItem:
        path = self.root / f"{item_id}.log"
        text = self._read_text(path)
        clusters: dict[tuple[str, str], list[dict]] = {}
        for line in text.splitlines():
            if not line.strip():
                continue
            m = _LINE_RE.match(line)
            if not m:
                continue
            fields = dict(kv.split("=", 1) for kv in m.group("fields").split() if "=" in kv)
            key = (m.group("component"), fields.get("reason", "UNKNOWN"))
            clusters.setdefault(key, []).append({
                "ts": m.group("ts"), "level": m.group("level"), **fields,
            })

        signatures = []
        for (component, reason), occurrences in sorted(clusters.items(), key=lambda kv: -len(kv[1])):
            signatures.append({
                "component": component,
                "reason": reason,
                "count": len(occurrences),
                "first_seen": occurrences[0]["ts"],
                "last_seen": occurrences[-1]["ts"],
                "sample_uetrs": [o.get("uetr") for o in occurrences[:3] if o.get("uetr")],
            })

        return RawItem(
            item_id=item_id,
            content={"title": f"Error signature clusters — {item_id}", "signatures": signatures, "raw_line_count": len(text.splitlines())},
            content_format="json",
            updated="",
            path=str(path),
            metadata={"signature_count": len(signatures)},
        )
