"""Core data model — mirrors KNOW-PIPE-2026-01 §08 plus the extraction-quality
fields KNOW-EXTRACT-2026-01 §11 adds to CandidateKnowledgeObject, and the
Product/CodeGraph extensions introduced for jurisdiction-scoped product rules
and code-to-database dependency mapping.

Kept intentionally domain-agnostic: every domain-specific value (viewpoints,
source types, agent roles, product domains) is a plain string/enum, not a
hardcoded payments type, so the same models serve any SDLC knowledge domain.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str = "") -> str:
    return f"{prefix}{uuid.uuid4().hex[:12]}"


# ---------------------------------------------------------------------------
# Agent personas & viewpoints (ISO/IEC/IEEE 42010) — KNOW-PIPE §03
# ---------------------------------------------------------------------------

class AgentRole(str, Enum):
    """The seven SDLC agent personas the context builder serves. Deliberately
    a flat enum, not payments-specific — any project's VS Code agent fleet
    maps onto these seven."""
    BA = "ba"
    ARCHITECT = "architect"
    DESIGNER = "designer"
    DEVELOPER = "developer"
    TESTER = "tester"
    SRE = "sre"
    PM = "pm"


class Viewpoint(str, Enum):
    BUSINESS_PROCESS = "business_process"       # BA / delivery
    BUSINESS_DOMAIN = "business_domain"          # BA / onboarding
    TECHNICAL_IMPLEMENTATION = "technical_implementation"  # Developer / Reviewer
    DATA_MODEL = "data_model"                    # Developer / BA
    API_INTEGRATION = "api_integration"          # Developer / Tester / Designer
    ARCHITECTURE_STRUCTURE = "architecture_structure"  # Architect
    INTERFACE_DESIGN = "interface_design"        # Designer — request/response
                                                  # contracts, interaction shape
    OPERATIONAL_PROCEDURE = "operational_procedure"  # SRE / Support
    OBSERVABILITY_INCIDENT = "observability_incident"  # SRE / root-cause
    REGULATORY_PRODUCT = "regulatory_product"    # BA / Architect — base +
                                                  # jurisdiction product rules


# Default viewpoint(s) per raw source type — overridable at extraction time.
SOURCE_DEFAULT_VIEWPOINTS: dict[str, list[str]] = {
    "ado": [Viewpoint.BUSINESS_PROCESS.value],
    "confluence": [Viewpoint.BUSINESS_DOMAIN.value],
    "git": [Viewpoint.TECHNICAL_IMPLEMENTATION.value],
    "db_schema": [Viewpoint.DATA_MODEL.value],
    "swagger": [Viewpoint.API_INTEGRATION.value],
    "plantuml": [Viewpoint.ARCHITECTURE_STRUCTURE.value],
    "runbook": [Viewpoint.OPERATIONAL_PROCEDURE.value],
    "logs": [Viewpoint.OBSERVABILITY_INCIDENT.value],
    "product_catalog": [Viewpoint.REGULATORY_PRODUCT.value, Viewpoint.BUSINESS_DOMAIN.value],
}


# ---------------------------------------------------------------------------
# Source Connector — KNOW-PIPE §04, §08
# ---------------------------------------------------------------------------

class SourceType(str, Enum):
    ADO = "ado"
    CONFLUENCE = "confluence"
    GIT = "git"
    DATABASE = "db_schema"
    SWAGGER = "swagger"
    PLANTUML = "plantuml"
    RUNBOOK = "runbook"
    LOG = "logs"
    PRODUCT_CATALOG = "product_catalog"


class Intent(str, Enum):
    """Fixed, versioned intent taxonomy — Context-Engineering-Platform-Design
    Layer 01. Structured output from the intent classifier, not free text,
    so the planner downstream is deterministic and testable."""
    SPEC_AUTHORING = "spec-authoring"
    CODE_GENERATION = "code-generation"
    TEST_GENERATION = "test-generation"
    ARCHITECTURE_REVIEW = "architecture-review"
    CODE_REVIEW = "code-review"
    IMPACT_ANALYSIS = "impact-analysis"
    DEFECT_TRIAGE = "defect-triage"
    INCIDENT_RESPONSE = "incident-response"
    INTERFACE_DESIGN = "interface-design"
    PRIORITIZATION = "prioritization"


class SourceRegime(str, Enum):
    """KNOW-EXTRACT §03 — which strategy a source type gets: score it,
    parse it, or aggregate it. Product catalog behaves like narrative
    business-rule content (scored), Git/Swagger/PlantUML/DB are structured
    (parsed), Logs are telemetry (aggregated)."""
    NARRATIVE = "narrative"
    STRUCTURED = "structured"
    TELEMETRY = "telemetry"


SOURCE_REGIME: dict[str, str] = {
    SourceType.ADO.value: SourceRegime.NARRATIVE.value,
    SourceType.CONFLUENCE.value: SourceRegime.NARRATIVE.value,
    SourceType.RUNBOOK.value: SourceRegime.NARRATIVE.value,
    SourceType.PRODUCT_CATALOG.value: SourceRegime.NARRATIVE.value,
    SourceType.GIT.value: SourceRegime.STRUCTURED.value,
    SourceType.DATABASE.value: SourceRegime.STRUCTURED.value,
    SourceType.SWAGGER.value: SourceRegime.STRUCTURED.value,
    SourceType.PLANTUML.value: SourceRegime.STRUCTURED.value,
    SourceType.LOG.value: SourceRegime.TELEMETRY.value,
}


class SourceConnectorConfig(BaseModel):
    id: str = Field(default_factory=lambda: new_id("src-"))
    type: SourceType
    name: str
    scope: str = ""  # project / space / repo / schema / path filter
    schedule: str = "manual"
    default_viewpoints: list[str] = Field(default_factory=list)
    enabled: bool = True
    watermark: Optional[str] = None  # last-synced timestamp, per connector


# ---------------------------------------------------------------------------
# Candidate Knowledge Object — KNOW-PIPE §08 + KNOW-EXTRACT §11 additions
# ---------------------------------------------------------------------------

class GateVerdict(str, Enum):
    CANDIDATE = "candidate"
    NEEDS_REVIEW = "needs_review"
    IGNORED = "ignored"
    BLOCKED = "blocked"  # security/sensitivity hard block


class ObjectStatus(str, Enum):
    DRAFT = "draft"
    PENDING_REVIEW = "pending_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    CHANGES_REQUESTED = "changes_requested"


class GateConditionResult(BaseModel):
    condition: str
    passed: bool
    detail: str
    signal: Any = None


class CandidateKnowledgeObject(BaseModel):
    id: str = Field(default_factory=lambda: new_id("cko-"))
    source_connector_id: str
    source_type: SourceType
    source_item_id: str
    source_updated: Optional[str] = None

    title: str
    body: str
    raw_excerpt: str = ""

    viewpoints: list[str] = Field(default_factory=list)
    entity_ref: Optional[str] = None          # linked canonical wiki article id
    canonical_entity_key: Optional[str] = None  # resolved glossary key, e.g. payments.fast_transfer
    entity_match_method: Optional[str] = None   # "exact" | "fuzzy" | "embedding" | "unresolved" — drives glossary write-back

    confidence: float = 0.0
    status: ObjectStatus = ObjectStatus.DRAFT

    # --- Tier 0 ---
    gate_verdict: Optional[GateVerdict] = None
    gate_conditions: list[GateConditionResult] = Field(default_factory=list)
    gate_version: Optional[str] = None

    # --- Tier 1 ---
    relevance_score: Optional[float] = None   # BM25 vs domain lexicon
    near_duplicate_of: Optional[str] = None
    classifier_score: Optional[float] = None

    # --- Drift (§06) ---
    drift_flag: Optional[bool] = None
    drift_detail: Optional[str] = None

    # --- Tier 2 (LLM-structured) ---
    purpose: Optional[str] = None
    interfaces: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    business_rules: list[str] = Field(default_factory=list)
    open_questions: list[str] = Field(default_factory=list)
    dependencies: list[str] = Field(default_factory=list)
    summary: Optional[str] = None

    # --- Product hierarchy (base + jurisdiction overlay) ---
    product_code: Optional[str] = None
    product_scope: Optional[str] = None       # "base" | "variant"
    product_variant_key: Optional[str] = None  # e.g. "IN", "GB"
    product_domain: Optional[str] = None
    product_family: Optional[str] = None  # e.g. "Instant Retail Payments" — cross-product grouping, independent of EXTENDS
    product_country: Optional[str] = None  # matrix column — independent of variant_key, which specifically means "EXTENDS a shared base"
    capabilities: list[dict] = Field(default_factory=list)  # [{"sub_type": "Customer Transfer", "direction": "outward"}, ...]

    # carries source-native fields (ADO type/state, Confluence page_type/status...)
    # through to graph-building and review-UI display without re-fetching the raw item
    source_metadata: dict[str, Any] = Field(default_factory=dict)

    # ACE (Agentic Context Engineering) — which playbook strategy, if any,
    # guided this candidate's Tier 2 structuring; set so the review decision
    # can be recorded back against it (see extraction/ace_playbook.py)
    ace_playbook_entry_id: Optional[str] = None
    ace_pattern_signature: Optional[str] = None

    created: str = Field(default_factory=now_iso)
    run_id: Optional[str] = None


class ConflictRecord(BaseModel):
    id: str = Field(default_factory=lambda: new_id("conf-"))
    candidate_id: str
    canonical_id: Optional[str] = None
    severity: float = 0.0
    rationale: str = ""
    created: str = Field(default_factory=now_iso)


class ReviewDecisionAction(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    REQUEST_CHANGES = "request_changes"


class ReviewDecision(BaseModel):
    id: str = Field(default_factory=lambda: new_id("rev-"))
    candidate_id: str
    reviewer: str  # named identity — never a service account
    action: ReviewDecisionAction
    note: str = ""
    decided_at: str = Field(default_factory=now_iso)


class RunMode(str, Enum):
    ISOLATED = "isolated"
    FULL = "full"


class RunStatus(str, Enum):
    QUEUED = "queued"
    ESTIMATING = "estimating"
    RUNNING = "running"
    AWAITING_REVIEW = "awaiting_review"
    COMPLETED = "completed"
    PROMOTED = "promoted"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class CriticalityScore(BaseModel):
    """PM-facing prioritization signal — composed entirely from evidence
    already in the graph/index (blast radius, incident frequency, regulatory
    linkage, open work-item count), never hand-asserted. See
    serving/prioritization.py."""
    entity_key: str
    label: str
    blast_radius: int = 0
    incident_count_30d: int = 0
    regulatory_linked: bool = False
    open_work_items: int = 0
    score: float = 0.0
    rationale: list[str] = Field(default_factory=list)


class PipelineRun(BaseModel):
    id: str = Field(default_factory=lambda: new_id("run-"))
    mode: RunMode
    scope: list[str] = Field(default_factory=list)  # source ids or stage ids for isolated runs
    stage_status: dict[str, Any] = Field(default_factory=dict)
    status: RunStatus = RunStatus.QUEUED
    promoted_by: Optional[str] = None
    started_at: str = Field(default_factory=now_iso)
    finished_at: Optional[str] = None
    funnel: dict[str, int] = Field(default_factory=dict)
