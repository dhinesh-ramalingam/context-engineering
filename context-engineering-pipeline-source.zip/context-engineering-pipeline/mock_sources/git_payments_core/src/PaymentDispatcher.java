package com.payments.core;

import com.payments.core.sanctions.SanctionsService;
import com.payments.core.sanctions.ScreeningResult;

/**
 * Routes a validated payment to the correct clearing rail and handles
 * settlement acknowledgements. FAST rail payments must be sanctions-screened
 * at intake before dispatch — see ADO story 48219.
 *
 * @db-table payments.payment (read, write)
 * @db-table payments.settlement (write)
 */
public class PaymentDispatcher {

    private final SanctionsService sanctionsService;
    private final SettlementPublisher settlementPublisher;

    public PaymentDispatcher(SanctionsService sanctionsService, SettlementPublisher settlementPublisher) {
        this.sanctionsService = sanctionsService;
        this.settlementPublisher = settlementPublisher;
    }

    /**
     * Dispatches a validated payment request to the correct clearing rail.
     * Idempotent on UETR. Must not block more than 200ms; a sanctions
     * screening timeout escalates to manual review rather than failing
     * open or closed.
     */
    public DispatchResult dispatch(PaymentRequest request) {
        ScreeningResult screening = sanctionsService.screen(request.getCounterparty());
        if (screening.isHit()) {
            return DispatchResult.rejected(request.getUetr(), screening.getReasonCode());
        }
        if (screening.isTimeout()) {
            return DispatchResult.escalated(request.getUetr());
        }

        if ("FAST".equals(request.getRail())) {
            // FAST rail requires ISO 20022 pacs.008 message format
            settlementPublisher.publishPacs008(request);
        } else {
            settlementPublisher.publishGeneric(request);
        }
        return DispatchResult.dispatched(request.getUetr());
    }

    /**
     * Callback invoked when the clearing rail confirms settlement.
     */
    public void onSettlementAck(SettlementAck ack) {
        settlementPublisher.confirm(ack.getUetr(), ack.getStatus());
    }
}
