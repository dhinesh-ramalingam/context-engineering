#!/usr/bin/env python
"""MCP stdio server — the literal 'usable by VS Code SDLC agents' delivery
mechanism. VS Code's agent mode is a native MCP client (Context-Engineering
-Platform-Design Layer 03): register this server once in .vscode/mcp.json
and every one of the seven personas (BA, Architect, Designer, Developer,
Tester, SRE, PM) can call get_context, search_knowledge, graph_neighbors,
and prioritize_backlog as tools during a live coding session — no bespoke
IDE plugin, and it's the same ContextBuilder the CLI and FastAPI console use,
so behavior is identical across every surface.
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mcp.server.mcpserver import MCPServer

from pipeline.extraction.entity_resolution import Glossary
from pipeline.governance.wiki_publish import WikiRepo
from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.serving.context_builder import ContextBuilder
from pipeline.serving.document_view import build_full_document
from pipeline.serving.prioritization import compute_criticality

mcp = MCPServer(
    name="context-engineering-pipeline",
    title="Context Engineering Pipeline",
    description=(
        "Governed knowledge context for SDLC agents (BA, Architect, Designer, Developer, "
        "Tester, SRE, PM) — hybrid retrieval + GraphRAG over an approved, maker-checker-gated "
        "knowledge base. Runs entirely local (Neo4j + Elasticsearch + Ollama), no data leaves "
        "the machine."
    ),
    version="1.0.0",
)

VALID_ROLES = ("ba", "architect", "designer", "developer", "tester", "sre", "pm")


@mcp.tool()
def get_context(query: str, agent_role: str, intent: str | None = None, top_k: int = 12,
                 session_id: str | None = None) -> dict:
    """Assembles the minimum, sufficient, provenance-tagged context bundle for one task.

    Runs the full pipeline: intent classification -> policy-as-code planning ->
    hybrid (BM25 + dense) retrieval with Reciprocal Rank Fusion -> knowledge-graph
    enrichment (blast radius / product base+overlay resolution) -> token-budgeted
    assembly -> outbound guardrail scan. This is the one call every agent persona
    should make instead of querying the vector index directly.

    Args:
        query: the task in natural language, e.g. "implement sanctions screening validation"
        agent_role: one of ba, architect, designer, developer, tester, sre, pm
        intent: optional explicit intent (spec-authoring, code-generation, test-generation,
            architecture-review, code-review, impact-analysis, defect-triage,
            incident-response, interface-design, prioritization). Auto-classified if omitted.
        top_k: how many hybrid-retrieval candidates to fuse before ranking (default 12)
        session_id: optional — pass the same id across multiple calls in one agentic task
            (e.g. "read spec" -> "implement" -> "write tests") so content already delivered
            earlier in the session is referenced instead of re-sent, freeing token budget
            for genuinely new context on each subsequent call. Omit for a one-shot query.
    """
    if agent_role not in VALID_ROLES:
        return {"error": f"agent_role must be one of {VALID_ROLES}"}
    cb = ContextBuilder(env="production")
    try:
        bundle = cb.build(query, agent_role=agent_role, intent=intent, top_k=top_k, session_id=session_id)
    finally:
        cb.close()
    return {
        "intent": bundle.intent,
        "intent_confidence": bundle.intent_confidence,
        "tokens_used": bundle.tokens_used,
        "token_budget": bundle.token_budget,
        "guardrail_clean": bundle.guardrail_clean,
        "guardrail_hits": bundle.guardrail_hits,
        "session_id": bundle.session_id,
        "context": bundle.assembled_text,
        "sources": [
            {"title": i.title, "source_type": i.source_type, "entity_key": i.entity_key,
             "tag": i.tag, "score": round(i.score, 4), "provenance": i.provenance}
            for i in bundle.items
        ],
        "graph_notes": bundle.graph_notes,
    }


@mcp.tool()
def search_knowledge(query: str, viewpoint: str | None = None, size: int = 10) -> dict:
    """Direct hybrid search (BM25 + dense, RRF-fused) over the governed knowledge
    base, without intent planning or graph enrichment — for when an agent wants raw
    search results rather than a full assembled context bundle.

    Args:
        query: free-text search query
        viewpoint: optional filter, one of business_process, business_domain,
            technical_implementation, data_model, api_integration, architecture_structure,
            interface_design, operational_procedure, observability_incident, regulatory_product
        size: max results (default 10)
    """
    from pipeline.indexing import es_index
    from pipeline.indexing.embeddings import get_default_cache
    from pipeline.serving.hybrid_retrieval import reciprocal_rank_fusion

    client = es_index.get_client()
    idx = es_index.index_name_for("production")
    filters = {"viewpoints": [viewpoint]} if viewpoint else None
    cache = get_default_cache()
    vector, _, _ = cache.get_or_embed(query)
    bm25_hits = es_index.search_bm25(client, idx, query, filters=filters, size=size)
    dense_hits = es_index.search_dense(client, idx, vector, filters=filters, k=size)
    fused = reciprocal_rank_fusion(bm25_hits, dense_hits)
    return {
        "results": [
            {"id": h.id, "title": h.source.get("title"), "source_type": h.source.get("source_type"),
             "entity_key": h.source.get("entity_key"), "fused_score": round(h.fused_score, 4),
             "summary": h.source.get("summary")}
            for h in fused[:size]
        ]
    }


@mcp.tool()
def graph_neighbors(entity_key_or_class: str, node_label: str = "Entity", hops: int = 2) -> dict:
    """Knowledge-graph traversal — blast radius / impact analysis. Given a node
    (an Entity key like 'payments.sanctions_screening', a CodeClass key like
    'payments-core:PaymentDispatcher', or a Component name), returns everything
    within N hops: dependent code, database tables it reads/writes, architecture
    components, incident signatures, and related work items.

    Args:
        entity_key_or_class: the node's key (Entity.key, CodeClass.key) or name (Component.name)
        node_label: Entity | CodeClass | Component | Product | DbTable (default Entity)
        hops: traversal depth, bounded to 1-4 (default 2)
    """
    graph = GraphBuilder()
    try:
        key_prop = "name" if node_label == "Component" else "key"
        neighbors = graph.neighbors(node_label, key_prop, entity_key_or_class, hops=hops, env="production")
    finally:
        graph.close()
    return {
        "start": entity_key_or_class,
        "neighbors": [
            {"labels": n["labels"], "distance": n["distance"], "node": n["node"]}
            for n in neighbors
        ],
    }


@mcp.tool()
def get_full_document(entity_key: str) -> dict:
    """Merges an entity's base canonical article with everything that
    extends or relates to it into one persona-readable document — e.g.
    'products.rtgs' returns the RTGS base rules plus every approved country
    overlay (India, UK...) as one document, not separate chunks the agent
    has to stitch together itself.

    Args:
        entity_key: the canonical entity key, e.g. 'products.rtgs', 'payments.settlement'
    """
    graph = GraphBuilder()
    try:
        doc = build_full_document(graph, WikiRepo(), entity_key)
    finally:
        graph.close()
    if doc is None:
        return {"error": f"no canonical article for entity_key={entity_key!r}"}
    return {
        "root_entity_key": doc.root_entity_key,
        "sections": [
            {"role": s.role, "entity_key": s.entity_key, "title": s.title,
             "approved_by": s.approved_by, "version": s.version, "relationship": s.relationship}
            for s in doc.sections
        ],
        "merged_markdown": doc.merged_markdown,
    }


@mcp.tool()
def prioritize_backlog() -> dict:
    """PM-facing prioritization: ranks every known business entity by a
    criticality score composed from graph blast radius, incident frequency,
    regulatory/product linkage, and open work-item count — all evidence already
    in the knowledge graph, never hand-asserted. Use this to answer 'what should
    we work on first' from the same governed knowledge base every other agent reads.
    """
    graph = GraphBuilder()
    try:
        glossary = Glossary()
        wiki = WikiRepo()
        entity_keys = {a.get("entity_key") for a in wiki.list_articles() if a.get("entity_key")}
        scores = []
        for key in entity_keys:
            component = graph.implemented_by_name(key)
            scores.append(compute_criticality(graph, key, glossary.label(key) or key, component))
        scores.sort(key=lambda s: -s.score)
    finally:
        graph.close()
    return {"ranked": [s.model_dump() for s in scores]}


if __name__ == "__main__":
    mcp.run()
