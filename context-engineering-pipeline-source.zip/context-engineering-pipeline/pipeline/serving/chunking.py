"""Structural chunking — cuts at markdown section boundaries instead of a
blind character offset. Both source articles flag chunking strategy as a
first-order retrieval-quality decision ('garbage in, garbage out'): a
truncation that lands mid-sentence or mid-table actively damages what a
model downstream sees, worse than a shorter but structurally complete
version would. This pipeline previously truncated long bodies with plain
`text[:N]` at both the Tier 2 structuring prompt and the Elasticsearch
indexed body — both call sites now go through this instead.

Deliberately not a general-purpose semantic chunker (no embeddings-per-
chunk, no separate chunk-level ES documents) — the corpus here doesn't yet
have documents large enough to need retrieval-time sub-document chunking,
so the scoped fix is "truncate intelligently", not "re-architect indexing
around chunks." See docs 'Honest limitations' for where that line is.
"""
from __future__ import annotations

import re

_HEADING_SPLIT_RE = re.compile(r"(?=^#{1,3}\s)", re.MULTILINE)
_TRUNCATION_NOTE = "\n\n_[content truncated at a section boundary — see the full document via get_full_document / wiki document]_"


def structural_truncate(text: str, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text

    budget = max_chars - len(_TRUNCATION_NOTE)
    sections = _HEADING_SPLIT_RE.split(text)
    if len(sections) > 1:
        kept, total = [], 0
        for section in sections:
            if not section.strip():
                continue  # the empty fragment before the first heading
            if total + len(section) > budget:
                break
            kept.append(section)
            total += len(section)
        joined = "".join(kept).rstrip()
        if joined:
            return joined + _TRUNCATION_NOTE
        # every individual section (even the first) exceeds the budget on
        # its own — fall through to the paragraph-boundary cut below
        # instead of returning near-nothing.

    # No usable heading structure — fall back to the last paragraph break
    # before the limit rather than an arbitrary mid-sentence cut.
    cut = text[:budget]
    last_break = cut.rfind("\n\n")
    if last_break > budget * 0.5:
        cut = cut[:last_break]
    return cut.rstrip() + _TRUNCATION_NOTE
