"""Source Connector interface — KNOW-PIPE §04.

Every source (ADO, Confluence, Git, Database, Swagger, PlantUML, Runbook,
Log, Product Catalog) implements the same four methods. A new source type is
a new adapter, not a pipeline change. These mock connectors read from local
files under mock_sources/ instead of calling a real ADO/Confluence/Git API —
swapping in a real API client later only touches this one file per source.
"""
from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable


@dataclass
class RawItem:
    """One raw unit fetched from a source — a work item, a wiki page, a
    file, a spec, a runbook, a log batch. `content` is source-native (dict
    for JSON sources, text for markdown/code/yaml/log)."""
    item_id: str
    content: Any
    content_format: str  # "json" | "text" | "yaml"
    updated: str
    path: str
    metadata: dict[str, Any] = field(default_factory=dict)


class SourceConnector(ABC):
    source_type: str

    def __init__(self, connector_id: str, name: str, root: Path, scope: str = ""):
        self.connector_id = connector_id
        self.name = name
        self.root = root
        self.scope = scope
        self._watermark: str | None = None

    @abstractmethod
    def connect(self) -> bool:
        """Verify the source is reachable. For file-based mock connectors
        this just checks the directory exists."""

    @abstractmethod
    def list_items(self) -> Iterable[str]:
        """Return item ids available from this source, newer than the
        current watermark if one is set."""

    @abstractmethod
    def fetch(self, item_id: str) -> RawItem:
        """Fetch one item's full content."""

    def watermark(self) -> str | None:
        return self._watermark

    def set_watermark(self, value: str) -> None:
        self._watermark = value

    # --- shared helpers for file-based mock connectors ---
    def _read_json(self, path: Path) -> dict:
        return json.loads(path.read_text(encoding="utf-8"))

    def _read_text(self, path: Path) -> str:
        return path.read_text(encoding="utf-8")
