# Registering with VS Code

VS Code's agent mode / Copilot Chat is a native MCP client. To give it access to this
pipeline's governed knowledge base:

1. **Bring up the stack first** (from the `context-engineering-pipeline/` root):
   ```
   docker compose up -d
   ollama pull nomic-embed-text   # once
   ```
   The MCP server talks to Neo4j (bolt://localhost:7688), Elasticsearch (localhost:9200),
   and Ollama (localhost:11434) directly — it does not start them.

2. **Register the server.** Merge `vscode_mcp.json`'s contents into your workspace's
   `.vscode/mcp.json` (create it if it doesn't exist), or into your user `mcp.json` via
   the Command Palette → "MCP: Open User Configuration". Adjust the `${workspaceFolder}`
   paths if this repo isn't at your workspace root.

3. **Reload VS Code / restart the MCP connection.** Copilot Chat (agent mode) will now
   list four tools from `context-engineering-pipeline`:
   - `get_context(query, agent_role, intent?, top_k?)` — the main call. `agent_role` is
     one of `ba, architect, designer, developer, tester, sre, pm`.
   - `search_knowledge(query, viewpoint?, size?)` — raw hybrid search, no planning.
   - `graph_neighbors(entity_key_or_class, node_label?, hops?)` — blast-radius / impact
     analysis over the knowledge graph.
   - `prioritize_backlog()` — PM criticality ranking.

4. **Use it.** In agent mode, a prompt like *"using the context engineering pipeline,
   get context for implementing sanctions screening validation as a developer"* will
   invoke `get_context` and ground the response in the approved knowledge base — with
   citations back to the source item and the reviewer who approved it.

## Manual smoke test (no VS Code required)

```
python scripts/smoke_mcp.py
```
Launches the server as a real stdio subprocess and drives it with the official MCP
client SDK — the same protocol VS Code speaks.
