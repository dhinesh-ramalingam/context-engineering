"""PM-facing prioritization — composed entirely from evidence already in the
graph/index (blast radius, incident frequency, regulatory linkage, open
work-item count), never hand-asserted. This is what lets a PM agent
'prioritize based on project criticality' from the same governed knowledge
base every other persona reads from, instead of a separately maintained
priority spreadsheet.
"""
from __future__ import annotations

from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.models import CriticalityScore

WEIGHTS = {"blast_radius": 0.35, "incident": 0.30, "regulatory": 0.20, "open_work": 0.15}


def compute_criticality(graph: GraphBuilder, entity_key: str, label: str,
                         component_name: str | None = None, env: str = "production") -> CriticalityScore:
    blast_radius = graph.blast_radius_count("Entity", "key", entity_key, hops=2, env=env)
    incident_count = graph.incident_count(component_name, env=env) if component_name else 0
    open_work = graph.open_work_item_count(entity_key, env=env)
    regulatory_linked = graph.has_product_link(entity_key, env=env)

    # normalize each factor to a rough [0,1] band before weighting — same
    # discipline the context ranker uses (Context-Engineering-Platform-
    # Design Layer 04): log the per-factor contribution, don't just blend.
    norm_blast = min(1.0, blast_radius / 10)
    norm_incident = min(1.0, incident_count / 10)
    norm_regulatory = 1.0 if regulatory_linked else 0.0
    norm_open_work = min(1.0, open_work / 5)

    score = (
        WEIGHTS["blast_radius"] * norm_blast +
        WEIGHTS["incident"] * norm_incident +
        WEIGHTS["regulatory"] * norm_regulatory +
        WEIGHTS["open_work"] * norm_open_work
    )

    rationale = [
        f"blast radius {blast_radius} nodes within 2 hops (contributes {WEIGHTS['blast_radius']*norm_blast:.2f})",
        f"{incident_count} incident occurrences in the last known window (contributes {WEIGHTS['incident']*norm_incident:.2f})",
        f"regulatory/product-linked: {regulatory_linked} (contributes {WEIGHTS['regulatory']*norm_regulatory:.2f})",
        f"{open_work} open work items (contributes {WEIGHTS['open_work']*norm_open_work:.2f})",
    ]

    return CriticalityScore(
        entity_key=entity_key, label=label, blast_radius=blast_radius, incident_count_30d=incident_count,
        regulatory_linked=regulatory_linked, open_work_items=open_work, score=round(score, 3), rationale=rationale,
    )


def rank_entities(graph: GraphBuilder, entities: list[dict], env: str = "production") -> list[CriticalityScore]:
    """entities: [{'entity_key': ..., 'label': ..., 'component_name': ...}, ...]"""
    scores = [
        compute_criticality(graph, e["entity_key"], e["label"], e.get("component_name"), env=env)
        for e in entities
    ]
    return sorted(scores, key=lambda s: -s.score)
