from __future__ import annotations

from typing import Iterable

from .base import RawItem, SourceConnector


class ProductCatalogConnector(SourceConnector):
    """Narrative-regime source (KNOW-EXTRACT §03) carrying base + jurisdiction
    -overlay product rules — scored through the same Tier 0/1/2 cascade as
    Confluence, not treated as structured/parsed content, because it's
    human-authored business/regulatory prose that can go stale or be wrong
    just like any other narrative doc."""

    source_type = "product_catalog"

    def connect(self) -> bool:
        return self.root.exists()

    def list_items(self) -> Iterable[str]:
        for p in sorted(self.root.glob("*.json")):
            yield p.stem

    def fetch(self, item_id: str) -> RawItem:
        path = self.root / f"{item_id}.json"
        data = self._read_json(path)
        return RawItem(
            item_id=data["id"],
            content=data,
            content_format="json",
            updated=data.get("updated", ""),
            path=str(path),
            metadata={
                "page_type": data.get("page_type"),
                "status": data.get("status"),
                "owner": data.get("owner"),
                "labels": data.get("labels", []),
                "version": data.get("version"),
                "domain": data.get("domain"),
                "product_code": data.get("product_code"),
                "scope": data.get("scope"),
                "variant_key": data.get("variant_key"),
                "base_product_id": data.get("base_product_id"),
            },
        )
