from __future__ import annotations

import re
from typing import Iterable

from .base import RawItem, SourceConnector

_COMPONENT_RE = re.compile(r'(?:component|queue|actor)\s+"([^"]+)"\s+as\s+(\w+)')
_EDGE_RE = re.compile(r'(\w+)\s*-+>\s*(\w+)\s*(?::\s*(.+))?')


class PlantUmlConnector(SourceConnector):
    """Structured regime — parsed for its component/edge inventory, which
    feeds the architecture knowledge graph directly (KNOW-EXTRACT §03, §06)."""

    source_type = "plantuml"

    def connect(self) -> bool:
        return self.root.exists()

    def list_items(self) -> Iterable[str]:
        for p in sorted(self.root.glob("*.puml")):
            yield p.stem

    def fetch(self, item_id: str) -> RawItem:
        path = self.root / f"{item_id}.puml"
        text = self._read_text(path)
        aliases = {alias: label for label, alias in _COMPONENT_RE.findall(text)}
        edges = []
        for src, dst, label in _EDGE_RE.findall(text):
            if src in aliases and dst in aliases:
                edges.append({"from": aliases[src], "to": aliases[dst], "label": (label or "").strip()})
        return RawItem(
            item_id=item_id,
            content={"raw": text, "components": list(aliases.values()), "edges": edges, "title": item_id},
            content_format="json",
            updated="",
            path=str(path),
            metadata={"components": list(aliases.values()), "edges": edges},
        )
