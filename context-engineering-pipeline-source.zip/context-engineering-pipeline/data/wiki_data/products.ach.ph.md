---
title: ACH — Philippines (PDDTS / InstaPay Batch)
entity_key: products.ach.ph
source_type: product_catalog
source_ref: product_catalog-1:PROD-ACH-PH
candidate_id: cko-4ebe00d03179
viewpoints: [business_domain, business_process, regulatory_product]
version: 1
approved_by: M. Reyes
published_at: 2026-08-16T20:33:50.760259+00:00
status: Active
---

# ACH — Philippines (PDDTS / InstaPay Batch)

## Summary
This document outlines the business rules for processing Philippine peso batch credit transfers through PDDTS, regulated by BSP. It specifies that these transactions are batch-based and not real-time.

## Purpose
Defines the platform's rules for Philippine peso batch credit transfers via PDDTS (Peso Net / PhilPaSS batch clearing), operated under BSP (Bangko Sentral ng Pilipinas) oversight.

## Interfaces
- AchBatchEntry

## Business Rules
- Batch cycles settle multiple times per business day; not real-time.
- Both outward (this platform originates) and inward (this platform receives from an external bank via the clearing house) credit are supported.
- Regulator of record: BSP.

## Dependencies
- PDDTS batch clearing interface
- BSP settlement calendar

## Source Content
# ACH — Philippines (PDDTS)

## Purpose
Defines the platform's rules for Philippine peso batch credit transfers via PDDTS (Peso Net / PhilPaSS batch clearing), operated under BSP (Bangko Sentral ng Pilipinas) oversight.

## Scope
Applies to batch-settled domestic PHP credit transfers between participating Philippine banks.

## Business Rules
- Batch cycles settle multiple times per business day; not real-time.
- Both outward (this platform originates) and inward (this platform receives from an external bank via the clearing house) credit are supported.
- Regulator of record: BSP.

## Interfaces
`AchBatchEntry` (PH) — `payerAccount`, `payeeAccount`, `payeeBankCode`, `amountMinorUnits`.

## Dependencies
PDDTS batch clearing interface, BSP settlement calendar.

## Glossary
PDDTS — Philippine Domestic Dollar Transfer System naming convention adapted here for peso batch clearing; BSP — the Philippine central bank.

