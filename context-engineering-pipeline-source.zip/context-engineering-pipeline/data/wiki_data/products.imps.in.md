---
title: IMPS — India (Immediate Payment Service)
entity_key: products.imps.in
source_type: product_catalog
source_ref: product_catalog-1:PROD-IMPS-IN
candidate_id: cko-4ae4b97a7d1d
viewpoints: [business_domain, business_process, regulatory_product]
version: 1
approved_by: R. Tan
published_at: 2026-08-16T20:33:45.385936+00:00
status: Active
---

# IMPS — India (Immediate Payment Service)

## Summary
This document outlines the business rules for India's IMPS scheme, including transaction limits and availability, and specifies the required routing information.

## Purpose
Defines the platform's rules for India's IMPS scheme, operated by NPCI (National Payments Corporation of India) — a sibling instant-payment rail to Singapore's FAST and Hong Kong's FPS, in the same product family, but an independently designed national scheme rather than a jurisdiction overlay on a shared base.

## Interfaces
- ImpsPaymentRequest

## Business Rules
- - Available 24x7x365, including bank holidays — no cut-off window, unlike RTGS.
- - Per-transaction limit is INR 5,00,000 for retail customers (bank-configurable up to the NPCI ceiling).
- - Routing requires either (account number + IFSC) or (MMID + mobile number); IMPS does not use UPI VPAs directly.

## Dependencies
- NPCI IMPS switch
- IFSC directory service

## Source Content
# IMPS — India (Immediate Payment Service)

## Purpose
Defines the platform's rules for India's IMPS scheme, operated by NPCI (National Payments Corporation of India) — a sibling instant-payment rail to Singapore's FAST and Hong Kong's FPS, in the same product family, but an independently designed national scheme rather than a jurisdiction overlay on a shared base.

## Scope
Applies to retail instant transfers between Indian bank accounts, addressed via account+IFSC or MMID+mobile number.

## Business Rules
- Available 24x7x365, including bank holidays — no cut-off window, unlike RTGS.
- Per-transaction limit is INR 5,00,000 for retail customers (bank-configurable up to the NPCI ceiling).
- Routing requires either (account number + IFSC) or (MMID + mobile number); IMPS does not use UPI VPAs directly.

## Interfaces
`ImpsPaymentRequest` — `payerAccount`, `payeeAccount` or `payeeMmid`+`payeeMobile`, `amountMinorUnits`, `payerIfsc`.

## Dependencies
NPCI IMPS switch, IFSC directory service.

## Glossary
IMPS — Immediate Payment Service. MMID — Mobile Money Identifier, a 7-digit code linking a mobile number to a bank account for IMPS routing.

