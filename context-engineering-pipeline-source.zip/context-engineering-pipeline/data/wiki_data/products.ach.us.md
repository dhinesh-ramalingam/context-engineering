---
title: ACH — United States
entity_key: products.ach.us
source_type: product_catalog
source_ref: product_catalog-1:PROD-ACH-US
candidate_id: cko-fdc2b10a7240
viewpoints: [business_domain, business_process, regulatory_product]
version: 1
approved_by: S. Idris
published_at: 2026-08-16T20:34:38.489533+00:00
status: Active
---

# ACH — United States

## Summary
This document outlines rules for US ACH transactions, specifying batch settlement processes and requirements such as authorization checks and return code handling.

## Purpose
Defines the platform's rules for originating and receiving US ACH (Automated Clearing House) transactions via NACHA-governed batch settlement, distinct from the platform's real-time rails.

## Interfaces
- AchBatchEntry

## Business Rules
- - ACH is batch-settled, not real-time — standard entries settle next-business-day; same-day ACH windows are supported for a per-transaction fee, up to NACHA's same-day limit.
- - ACH Debit (pulling funds from a payer) requires a signed authorization on file before origination — outward-only capability, this platform does not accept inward ACH debit pulls.
- - Return codes (e.g. R01 insufficient funds, R10 unauthorized) must be handled per the NACHA return-code table, not treated as generic failures.

## Dependencies
- ACH operator batch file interface
- NACHA return-code handling

## Source Content
# ACH — United States

## Purpose
Defines the platform's rules for originating and receiving US ACH (Automated Clearing House) transactions via NACHA-governed batch settlement, distinct from the platform's real-time rails.

## Scope
Applies to batch-settled domestic US credit and debit transfers processed through an ACH operator (e.g. the Federal Reserve or a clearing house).

## Business Rules
- ACH is batch-settled, not real-time — standard entries settle next-business-day; same-day ACH windows are supported for a per-transaction fee, up to NACHA's same-day limit.
- ACH Debit (pulling funds from a payer) requires a signed authorization on file before origination — outward-only capability, this platform does not accept inward ACH debit pulls.
- Return codes (e.g. R01 insufficient funds, R10 unauthorized) must be handled per the NACHA return-code table, not treated as generic failures.

## Interfaces
`AchBatchEntry` — `routingNumber`, `accountNumber`, `amountMinorUnits`, `secCode`, `effectiveEntryDate`.

## Dependencies
ACH operator batch file interface, NACHA return-code handling.

## Glossary
ACH — Automated Clearing House. NACHA — the US body governing ACH network rules. SEC code — Standard Entry Class code identifying the authorization type for a given ACH entry.

