"""OWASP LLM Top 10-mapped guardrails, run in both directions (Context-
Engineering-Platform-Design, Layer 9): the same scanners that give Tier 0's
Condition 7 its inbound hard block also scan outbound context before it
reaches an agent — LLM06 Sensitive Information Disclosure either way, plus
LLM01 Prompt Injection on inbound content (a wiki page or commit message can
carry instructions aimed at the agent, not just information).
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field

SECRET_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\bsk_live_[A-Za-z0-9]{16,}\b"), "stripe-style live API key"),
    (re.compile(r"\b[A-Za-z0-9_\-]{20,}\.[A-Za-z0-9_\-]{6,}\.[A-Za-z0-9_\-]{20,}\b"), "JWT-shaped secret"),
    (re.compile(r"(?i)\b(postgres|mysql|mongodb)://[^/\s]+:[^/\s@]+@"), "embedded DB credentials in connection string"),
    (re.compile(r"(?i)\bpassword\s*[:=]\s*\S+"), "inline password assignment"),
]

PII_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"\b[STFG]\d{7}[A-Z]\b"), "Singapore NRIC/FIN"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "US SSN-shaped number"),
    (re.compile(r"\b\d{16}\b"), "16-digit PAN-shaped number"),
]

# LLM01 — a retrieved document instructing the agent, not informing it.
PROMPT_INJECTION_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"(?i)ignore (all|the)?\s*(previous|above|prior)\s*instructions"), "instruction-override attempt"),
    (re.compile(r"(?i)disregard (the )?(system|above)\s*(prompt|instructions)?"), "instruction-override attempt"),
    (re.compile(r"(?i)you are now\s+\w+"), "role-reassignment attempt"),
    (re.compile(r"(?i)reveal (your|the) (system prompt|instructions|api key)"), "prompt/secret exfiltration attempt"),
    (re.compile(r"(?i)act as (an?|the) (unrestricted|unfiltered|jailbroken)"), "jailbreak framing"),
]

_TOKEN_RE = re.compile(r"[A-Za-z0-9+/_\-]{24,}")


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    length = len(s)
    return -sum((count / length) * math.log2(count / length) for count in freq.values())


def _entropy_scan(text: str, threshold: float = 4.2) -> list[str]:
    hits = []
    for token in _TOKEN_RE.findall(text):
        if _shannon_entropy(token) >= threshold:
            hits.append(f"high-entropy token (possible secret): {token[:12]}...")
    return hits


@dataclass
class GuardrailFinding:
    blocked: bool
    secret_hits: list[str] = field(default_factory=list)
    pii_hits: list[str] = field(default_factory=list)
    injection_hits: list[str] = field(default_factory=list)
    entropy_hits: list[str] = field(default_factory=list)

    @property
    def clean(self) -> bool:
        return not (self.secret_hits or self.pii_hits or self.injection_hits or self.entropy_hits)

    def all_hits(self) -> list[str]:
        return self.secret_hits + self.pii_hits + self.injection_hits + self.entropy_hits


def scan_inbound(text: str) -> GuardrailFinding:
    """Ingestion-time scan — secrets/PII hard-block (Tier 0 Condition 7),
    plus prompt-injection detection so an attacker can't plant agent
    instructions inside content that later gets served as 'trusted' context."""
    secret_hits = [label for pattern, label in SECRET_PATTERNS if pattern.search(text)]
    pii_hits = [label for pattern, label in PII_PATTERNS if pattern.search(text)]
    injection_hits = [label for pattern, label in PROMPT_INJECTION_PATTERNS if pattern.search(text)]
    entropy_hits = _entropy_scan(text) if not secret_hits else []  # avoid double-counting an already-matched key
    return GuardrailFinding(
        blocked=bool(secret_hits or pii_hits or injection_hits),
        secret_hits=secret_hits, pii_hits=pii_hits, injection_hits=injection_hits, entropy_hits=entropy_hits,
    )


def scan_outbound(text: str) -> GuardrailFinding:
    """Context-assembly-time scan — the same detectors run again on the
    assembled bundle right before it reaches the agent (Layer 9): a
    guardrail decision made once at ingestion is not assumed to hold
    forever, e.g. after a candidate's content is edited during review."""
    secret_hits = [label for pattern, label in SECRET_PATTERNS if pattern.search(text)]
    pii_hits = [label for pattern, label in PII_PATTERNS if pattern.search(text)]
    return GuardrailFinding(blocked=bool(secret_hits or pii_hits), secret_hits=secret_hits, pii_hits=pii_hits)
