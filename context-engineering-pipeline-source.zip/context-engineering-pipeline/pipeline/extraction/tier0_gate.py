"""KNOW-EXTRACT §04 — Tier 0 Deterministic Quality Gate.

Seven *independent* pass/fail conditions, not a weighted sum — this is the
critical-review fix to the source proposal's central bug: a single blended
score structurally caps a well-written Story at 40 points on type alone.
Here, four strong independent signals can earn a Story a human look even
though its type tier is C.

Condition 7 (security/sensitivity) is a hard block that overrides every
other signal, applied regardless of how well a document scores otherwise.
"""
from __future__ import annotations

import re

from pipeline.config import settings
from pipeline.models import GateConditionResult, GateVerdict
from .guardrails import scan_inbound
from .regimes import DOC_TYPE_TIER, EXPECTED_SECTIONS, TEMPLATED_TYPES, NormalizedDoc

# --- Condition 4: domain pattern sets (payments demo domain; swap/extend
# per deployment — this is config, not code, in a real rollout) ---
DOMAIN_PATTERNS = [
    r"\bmust\b", r"\bshall\b", r"\bshall not\b", r"\bshould\b", r"\bSLA\b",
    r"\bsettlement\b", r"\bsanctions?\b", r"\bcut-?off\b", r"\bthreshold\b",
    r"\bFAST\b", r"\bRTGS\b", r"\bAML\b", r"\bregulat\w+\b", r"\bUETR\b",
    r"\bidempotent\b", r"\bescalat\w+\b", r"\brollback\b", r"\bdispute\b",
]
_DOMAIN_RE = re.compile("|".join(DOMAIN_PATTERNS), re.IGNORECASE)


def _condition_1_type_tier(doc: NormalizedDoc) -> GateConditionResult:
    tier = DOC_TYPE_TIER.get(doc.doc_type, "C")
    return GateConditionResult(
        condition="document_type_tier", passed=tier in ("A", "B"),
        detail=f"{doc.doc_type} -> Tier {tier}", signal=tier,
    )


def _condition_2_metadata(doc: NormalizedDoc) -> GateConditionResult:
    present = sum([
        bool(doc.owner), bool(doc.labels), bool(doc.status), doc.version is not None,
    ])
    return GateConditionResult(
        condition="metadata_completeness", passed=present >= 3,
        detail=f"{present}/4 present (owner, labels, status, version)", signal=present,
    )


def _condition_3_structure(doc: NormalizedDoc) -> GateConditionResult:
    body = doc.body_markdown
    elements = 0
    signals = []
    if re.search(r"^#{1,3}\s+\S", body, re.MULTILINE):
        elements += 1; signals.append("headings")
    if "|" in body and re.search(r"\|.*\|.*\|", body):
        elements += 1; signals.append("table")
    if "```" in body or "plantuml" in body.lower():
        elements += 1; signals.append("diagram/code")
    if re.search(r"^#{1,3}\s*Glossary", body, re.MULTILINE | re.IGNORECASE):
        elements += 1; signals.append("glossary")
    return GateConditionResult(
        condition="structural_richness", passed=elements >= 2,
        detail=f"{elements} structural elements ({', '.join(signals) or 'none'})", signal=elements,
    )


def _condition_4_domain_pattern(doc: NormalizedDoc) -> GateConditionResult:
    hits = _DOMAIN_RE.findall(doc.body_markdown)
    return GateConditionResult(
        condition="domain_pattern_match", passed=len(hits) >= 1,
        detail=f"{len(hits)} domain pattern hits", signal=len(hits),
    )


def _condition_5_template(doc: NormalizedDoc) -> GateConditionResult:
    if doc.doc_type not in TEMPLATED_TYPES:
        return GateConditionResult(
            condition="template_completeness", passed=True,
            detail="not applicable for this document type", signal=None,
        )
    found = [s for s in EXPECTED_SECTIONS if re.search(rf"^#{{1,3}}\s*{re.escape(s)}", doc.body_markdown, re.MULTILINE | re.IGNORECASE)]
    threshold = 5 if DOC_TYPE_TIER.get(doc.doc_type) == "A" else 3
    return GateConditionResult(
        condition="template_completeness", passed=len(found) >= threshold,
        detail=f"{len(found)}/{len(EXPECTED_SECTIONS)} sections present (need >= {threshold}): {found}",
        signal=len(found),
    )


def _condition_6_lifecycle(doc: NormalizedDoc) -> GateConditionResult:
    ok = doc.status not in ("Draft", "Removed") and not doc.superseded_by
    return GateConditionResult(
        condition="lifecycle_validity", passed=ok,
        detail=f"status={doc.status}, superseded_by={doc.superseded_by}", signal=doc.status,
    )


def _condition_7_security(doc: NormalizedDoc) -> GateConditionResult:
    finding = scan_inbound(doc.body_markdown)
    hits = finding.secret_hits + finding.pii_hits
    return GateConditionResult(
        condition="security_sensitivity_screen", passed=not hits,
        detail="clean" if not hits else f"HARD BLOCK: {', '.join(hits)}", signal=hits,
    )


def evaluate_tier0(doc: NormalizedDoc) -> tuple[GateVerdict, list[GateConditionResult]]:
    conditions = [
        _condition_1_type_tier(doc),
        _condition_2_metadata(doc),
        _condition_3_structure(doc),
        _condition_4_domain_pattern(doc),
        _condition_5_template(doc),
        _condition_6_lifecycle(doc),
        _condition_7_security(doc),
    ]

    security = conditions[-1]
    if not security.passed:
        return GateVerdict.BLOCKED, conditions

    tier = conditions[0].signal
    others = conditions[1:-1]  # 2-6, excluding type tier and security
    failed = [c for c in others if not c.passed]
    strong_signals = sum(1 for c in others if c.passed)

    if tier in ("A", "B") and not failed:
        return GateVerdict.CANDIDATE, conditions
    if tier in ("A", "B") and len(failed) <= 2:
        return GateVerdict.NEEDS_REVIEW, conditions
    if tier == "C" and strong_signals >= 3:
        return GateVerdict.NEEDS_REVIEW, conditions
    return GateVerdict.IGNORED, conditions


def gate_version() -> str:
    return settings.gate_version
