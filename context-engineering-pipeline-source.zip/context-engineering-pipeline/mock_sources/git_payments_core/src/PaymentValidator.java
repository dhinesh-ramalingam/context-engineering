package com.payments.core.validation;

import com.payments.core.PaymentRequest;

/**
 * Validates an inbound payment request before it reaches PaymentDispatcher:
 * structural validity, currency support, and limit checks. Sanctions
 * screening itself lives in SanctionsService, not here — this class only
 * validates the request shape and business limits.
 *
 * @db-table payments.payment (read)
 */
public class PaymentValidator {

    public ValidationResult validate(PaymentRequest request) {
        if (request.getUetr() == null || request.getUetr().isBlank()) {
            return ValidationResult.invalid("UETR_MISSING");
        }
        if (request.getAmountMinorUnits() <= 0) {
            return ValidationResult.invalid("INVALID_AMOUNT");
        }
        if (!SupportedCurrencies.contains(request.getCurrency())) {
            return ValidationResult.invalid("UNSUPPORTED_CURRENCY");
        }
        return ValidationResult.valid();
    }
}
