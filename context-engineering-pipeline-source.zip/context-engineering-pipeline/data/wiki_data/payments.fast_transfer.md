---
title: Singapore FAST Enhancement Program
entity_key: payments.fast_transfer
source_type: ado
source_ref: ado-1:4001
candidate_id: cko-ebeb4b8fda41
viewpoints: [api_integration, business_process, technical_implementation]
version: 2
approved_by: R. Tan
published_at: 2026-08-16T20:34:38.215212+00:00
status: Active
---

# Singapore FAST Enhancement Program

## Summary
This document outlines the modernization of Singapore's FAST payment rail, focusing on extending cut-off handling, migrating FX rates to v2, and adding sanctions screening at intake.

## Purpose
To modernize the Singapore FAST real-time payment rail integration by extending cut-off handling for peak periods, migrating FX rates dependency to v2 (async callback support), and adding sanctions screening at intake rather than post-settlement.

## Source Content
Modernise the Singapore FAST real-time payment rail integration: extend cut-off handling for peak periods, migrate the FX rates dependency to v2 (async callback support), and add sanctions screening at intake rather than post-settlement. Supersedes the 2024 FAST integration epic.


