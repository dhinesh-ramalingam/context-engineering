"""Manual MCP smoke test: launches mcp_server/server.py as a real stdio
subprocess and drives it with the official client SDK — tools/list then a
tools/call for each tool, exactly what VS Code's agent mode does."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

ROOT = Path(__file__).resolve().parent.parent
PYTHON = str(ROOT / ".venv" / "Scripts" / "python.exe")
SERVER = str(ROOT / "mcp_server" / "server.py")


async def main():
    params = StdioServerParameters(command=PYTHON, args=[SERVER])
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await session.list_tools()
            print("tools:", [t.name for t in tools.tools])

            result = await session.call_tool("get_context", {
                "query": "What are the RTGS rules for India?", "agent_role": "ba",
            })
            print("\n--- get_context ---")
            print(result.content[0].text[:600])

            result = await session.call_tool("graph_neighbors", {
                "entity_key_or_class": "payments-core:PaymentDispatcher", "node_label": "CodeClass", "hops": 2,
            })
            print("\n--- graph_neighbors ---")
            print(result.content[0].text[:600])

            result = await session.call_tool("prioritize_backlog", {})
            print("\n--- prioritize_backlog ---")
            print(result.content[0].text[:600])


asyncio.run(main())
