---
title: FAST Payment cut-off & peak handling
entity_key: payments.fast_cutoff
source_type: confluence
source_ref: confluence-1:CONF-1002
candidate_id: cko-a72d84c62af7
viewpoints: [business_domain, business_process]
version: 1
approved_by: R. Tan
published_at: 2026-08-16T20:33:33.900580+00:00
status: Active
---

# FAST Payment cut-off & peak handling

## Summary
This document outlines the cut-off times for Singapore FAST transfers, including extended hours during peak periods and specifies that payments after these times are queued for next-day processing.

## Purpose
Defines the same-day settlement cut-off time for Singapore FAST transfers, including the peak-period extension.

## Business Rules
- Cut-off for same-day FAST transfer is 22:00 SGT, extended to 23:30 during peak periods.
- Peak periods are declared on the shared peak calendar (typically month-end and public-holiday eves).
- A payment received after the applicable cut-off is queued for next-business-day processing, not rejected.

## Dependencies
- Peak calendar service
- PaymentDispatcher

## Open Questions
- Whether the peak extension should apply automatically on declared bank holidays in Malaysia given cross-border FAST/DuitNow linkage — not yet decided.

## Source Content
# FAST Payment cut-off & peak handling

## Purpose
Defines the same-day settlement cut-off time for Singapore FAST transfers, including the peak-period extension.

## Scope
Applies to all FAST payments processed through the Payments platform for Singapore-domiciled accounts.

## Business Rules
- Cut-off for same-day FAST transfer is 22:00 SGT, extended to 23:30 during peak periods.
- Peak periods are declared on the shared peak calendar (typically month-end and public-holiday eves).
- A payment received after the applicable cut-off is queued for next-business-day processing, not rejected.

## Dependencies
Peak calendar service, PaymentDispatcher.

## Open Questions
Whether the peak extension should apply automatically on declared bank holidays in Malaysia given cross-border FAST/DuitNow linkage — not yet decided.

