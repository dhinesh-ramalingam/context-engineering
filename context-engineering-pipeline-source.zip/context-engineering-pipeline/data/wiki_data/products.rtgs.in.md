---
title: RTGS — India Overlay (RBI)
entity_key: products.rtgs.in
source_type: product_catalog
source_ref: product_catalog-1:PROD-RTGS-IN
candidate_id: cko-785619a8a654
viewpoints: [business_domain, regulatory_product]
version: 1
approved_by: R. Tan
published_at: 2026-08-16T20:34:08.564047+00:00
status: Active
---

# RTGS — India Overlay (RBI)

## Summary
This document outlines India-specific rules for the RTGS payment system, including transaction thresholds, operating hours, and regulatory requirements.

## Purpose
India-specific rules that extend the RTGS base product to comply with RBI operating guidelines.

## Interfaces
- RtgsPaymentRequest

## Business Rules
- - Minimum transaction amount is INR 2,00,000 — RTGS in India is not available below this threshold (below it, use NEFT/IMPS instead).
- - Operating window is 07:00 to 18:00 IST on RTGS working days (RBI-declared calendar); no settlement outside this window.
- - Routing requires a valid IFSC (Indian Financial System Code) for both payer and payee bank branch, in addition to the base account fields.
- - Regulator of record: Reserve Bank of India (RBI); reporting follows RBI RTGS guidelines, distinct from the base product's generic regulator field.

## Dependencies
- RTGS base product rules
- IFSC directory service
- RBI RTGS working-day calendar

## Source Content
# RTGS — India Overlay (RBI)

## Purpose
India-specific rules that extend the RTGS base product to comply with RBI (Reserve Bank of India) RTGS operating guidelines. This overlay applies on top of the RTGS base rules — it does not restate them.

## Scope
Applies to RTGS payments where the payer or payee account is domiciled in India and routed via India's RTGS system.

## Business Rules (overrides / additions to base)
- Minimum transaction amount is INR 2,00,000 — RTGS in India is not available below this threshold (below it, use NEFT/IMPS instead).
- Operating window is 07:00 to 18:00 IST on RTGS working days (RBI-declared calendar); no settlement outside this window.
- Routing requires a valid IFSC (Indian Financial System Code) for both payer and payee bank branch, in addition to the base account fields.
- Regulator of record: Reserve Bank of India (RBI); reporting follows RBI RTGS guidelines, distinct from the base product's generic regulator field.

## Interfaces
`RtgsPaymentRequest` (India) — base schema plus `payerIfsc`, `payeeIfsc`; `amountMinorUnits` must be >= 20000000 (INR 2,00,000 in paise).

## Dependencies
RTGS base product rules, IFSC directory service, RBI RTGS working-day calendar.

## Glossary
IFSC — Indian Financial System Code, an 11-character code identifying a bank branch for RTGS/NEFT routing.

