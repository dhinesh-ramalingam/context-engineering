from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

from git import Repo

from .base import RawItem, SourceConnector

_PACKAGE_RE = re.compile(r"^package\s+([\w.]+);", re.MULTILINE)
_IMPORT_RE = re.compile(r"^import\s+([\w.]+);", re.MULTILINE)
_CLASS_RE = re.compile(r"\bclass\s+(\w+)")
_DB_TABLE_RE = re.compile(r"@db-table\s+([\w.]+)\s*\(([^)]*)\)")

CODE_EXTENSIONS = {".java", ".py", ".ts", ".js", ".go"}


def parse_java_dependencies(text: str) -> dict:
    """Lightweight regex-based static parse — deliberately not a full AST
    parser. This is the 'structured regime: parse, don't grade' approach
    from KNOW-EXTRACT §03 applied to code: package, imports, declared class
    name, and explicit @db-table javadoc markers are all deterministic,
    explainable signals, not model-inferred guesses."""
    package = _PACKAGE_RE.search(text)
    imports = _IMPORT_RE.findall(text)
    classes = _CLASS_RE.findall(text)
    db_tables = [
        {"table": table.strip(), "modes": [m.strip() for m in modes.split(",")]}
        for table, modes in _DB_TABLE_RE.findall(text)
    ]
    return {
        "package": package.group(1) if package else None,
        "imports": imports,
        "classes": classes,
        "db_tables": db_tables,
    }


class GitConnector(SourceConnector):
    """Structured regime — parsed, not graded. Walks a real local git repo
    (GitPython) so file content, commit history, and last-modified watermark
    are all genuine, not synthesized."""

    source_type = "git"

    def __init__(self, connector_id: str, name: str, root: Path, scope: str = ""):
        super().__init__(connector_id, name, root, scope)
        self.repo = Repo(root) if (root / ".git").exists() else None

    def connect(self) -> bool:
        return self.root.exists() and self.repo is not None

    def list_items(self) -> Iterable[str]:
        for p in sorted(self.root.rglob("*")):
            if p.is_file() and ".git" not in p.parts:
                if p.suffix in CODE_EXTENSIONS or p.name == "README.md":
                    yield str(p.relative_to(self.root)).replace("\\", "/")

    def fetch(self, item_id: str) -> RawItem:
        path = self.root / item_id
        text = self._read_text(path)
        last_commit_iso = ""
        if self.repo:
            commits = list(self.repo.iter_commits(paths=item_id, max_count=1))
            if commits:
                last_commit_iso = commits[0].committed_datetime.isoformat()

        parsed = {}
        if path.suffix == ".java":
            parsed = parse_java_dependencies(text)

        return RawItem(
            item_id=item_id,
            content={"path": item_id, "text": text, "title": path.name, **parsed},
            content_format="text",
            updated=last_commit_iso,
            path=str(path),
            metadata={"kind": "test" if "test" in item_id.lower() else "source", **parsed},
        )
