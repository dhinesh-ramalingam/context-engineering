"""KNOW-EXTRACT §08 — Tier 2 Local LLM-Assisted Structuring.

The only generative step in the cascade, and it earns its cost by
structuring, not by deciding: every document reaching this module has
already been judged worth keeping by Tier 0 and Tier 1. The model turns
already-good documents into structured, agent-ready knowledge — it never
decides whether a document is worth anything.
"""
from __future__ import annotations

from pipeline.llm_client import OllamaError, generate_json
from pipeline.models import Viewpoint
from pipeline.serving.chunking import structural_truncate

_VALID_VIEWPOINTS = {v.value for v in Viewpoint}

_SYSTEM_PROMPT = """You are a knowledge extraction assistant for an enterprise payments platform.
You structure ALREADY-APPROVED-FOR-EXTRACTION documents into a fixed JSON schema.
You do not judge whether the document is worth keeping — that decision has already been made upstream.
You do not invent facts not present in the source text. If a field has no content, return an empty list or empty string.
Always respond with a single JSON object matching the requested schema exactly, no prose outside the JSON."""

_STRUCTURE_PROMPT_TEMPLATE = """Structure the following {doc_type} document titled "{title}" into this exact JSON schema:

{{
  "purpose": "one or two sentences on what this document is for",
  "interfaces": ["list of named APIs, methods, or contracts mentioned, empty if none"],
  "constraints": ["list of explicit constraints or non-functional requirements stated, e.g. timing budgets, limits"],
  "business_rules": ["list of explicit business rules or policy statements — prefer verbatim or near-verbatim phrasing"],
  "open_questions": ["list of anything the document explicitly flags as undecided or unclear"],
  "dependencies": ["list of other systems, services, or documents this content depends on"],
  "summary": "a concise 2-4 sentence summary of the document for a reviewer to approve",
  "viewpoints": ["zero or more of: {viewpoint_options}, chosen ONLY if clearly evidenced by the content"]
}}

Document body:
---
{body}
---
"""


def structure_candidate(
    title: str,
    body: str,
    doc_type: str,
    default_viewpoints: list[str],
    model: str | None = None,
    playbook_hint: str | None = None,
) -> dict:
    """Returns the structured fields plus a final `viewpoints` list that
    always includes the source's default viewpoint(s) — the LLM can only
    ADD viewpoints on top of the deterministic default, never remove it,
    and any hallucinated viewpoint string outside the known taxonomy is
    dropped rather than trusted.

    playbook_hint: an optional pattern-specific instruction from the ACE
    playbook (extraction/ace_playbook.py) — additive guidance layered on
    top of the base prompt, never a replacement for it, so a bad learned
    strategy degrades to the base prompt's behavior rather than replacing
    a working one outright."""
    prompt = _STRUCTURE_PROMPT_TEMPLATE.format(
        doc_type=doc_type, title=title, body=structural_truncate(body, 6000),
        viewpoint_options=", ".join(sorted(_VALID_VIEWPOINTS)),
    )
    if playbook_hint:
        prompt += f"\nAdditional pattern-specific guidance for this document type:\n{playbook_hint}\n"
    try:
        result = generate_json(prompt, system=_SYSTEM_PROMPT, model=model)
    except OllamaError:
        result = {}

    llm_viewpoints = [v for v in result.get("viewpoints", []) if v in _VALID_VIEWPOINTS]
    viewpoints = sorted(set(default_viewpoints) | set(llm_viewpoints))

    def _as_text(value, default: str = "") -> str:
        """A local model doesn't always honor 'this field is a string' in
        its JSON output — occasionally a single-sentence field comes back
        as a one-element list. Coerce rather than let a schema hiccup on
        one field fail the whole candidate."""
        if isinstance(value, list):
            return " ".join(str(v) for v in value).strip() or default
        if value is None:
            return default
        return str(value)

    def _as_list(value) -> list[str]:
        if isinstance(value, list):
            return [str(v) for v in value]
        if isinstance(value, str) and value.strip():
            return [value]
        return []

    return {
        "purpose": _as_text(result.get("purpose")),
        "interfaces": _as_list(result.get("interfaces")),
        "constraints": _as_list(result.get("constraints")),
        "business_rules": _as_list(result.get("business_rules")),
        "open_questions": _as_list(result.get("open_questions")),
        "dependencies": _as_list(result.get("dependencies")),
        "summary": _as_text(result.get("summary"), default=body[:280] + ("..." if len(body) > 280 else "")),
        "viewpoints": viewpoints,
    }
