"""Full-document view: one entity's base article plus everything that
extends or relates to it, merged into a single persona-readable document —
not a list of retrieved chunks the reader has to mentally stitch together.

Generalizes the product base+overlay merge that context_builder.py's
`detect_product_variant_query` special-cases for a literal "RTGS IN"-style
query into something reachable for *any* entity or product: give it a key,
it walks the graph for children and assembles one document, base first,
each overlay/related section clearly labeled with its own provenance.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from pipeline.governance.wiki_publish import WikiRepo
from pipeline.indexing.graph_builder import GraphBuilder


@dataclass
class DocumentSection:
    role: str  # "base" | "overlay" | "related"
    entity_key: str
    title: str
    body: str
    approved_by: Optional[str]
    version: Optional[str]
    relationship: Optional[str] = None  # how this section relates to the base, e.g. "EXTENDS", "IMPLEMENTED_BY"


@dataclass
class FullDocument:
    root_entity_key: str
    sections: list[DocumentSection] = field(default_factory=list)

    @property
    def merged_markdown(self) -> str:
        parts = []
        for s in self.sections:
            tag = "" if s.role == "base" else f" [{s.role}{' via ' + s.relationship if s.relationship else ''}]"
            parts.append(f"# {s.title}{tag}\n_approved by {s.approved_by}, v{s.version}_\n\n{s.body}")
        return "\n\n---\n\n".join(parts)


def build_full_document(graph: GraphBuilder, wiki: WikiRepo, entity_key: str, env: str = "production",
                          max_related: int = 5) -> Optional[FullDocument]:
    base_article = wiki.get(entity_key)
    if base_article is None:
        return None

    doc = FullDocument(root_entity_key=entity_key)
    doc.sections.append(DocumentSection(
        role="base", entity_key=entity_key, title=base_article["meta"].get("title", entity_key),
        body=base_article["body"], approved_by=base_article["meta"].get("approved_by"),
        version=base_article["meta"].get("version"),
    ))

    seen = {entity_key}

    # 1. Product variants that EXTEND this one (base -> country/jurisdiction overlays)
    variant_rows = graph.neighbors("Product", "key", entity_key, hops=1, env=env)
    for row in variant_rows:
        if row["labels"] != ["Product"] or row["distance"] != 1:
            continue
        variant_key = row["node"].get("key")
        if not variant_key or variant_key in seen:
            continue
        article = wiki.get(variant_key)
        if article is None:
            continue
        seen.add(variant_key)
        doc.sections.append(DocumentSection(
            role="overlay", entity_key=variant_key, title=article["meta"].get("title", variant_key),
            body=article["body"], approved_by=article["meta"].get("approved_by"),
            version=article["meta"].get("version"), relationship="EXTENDS",
        ))

    # 2. Other graph-adjacent entities that have their own canonical article
    #    (e.g. an implementing CodeClass's related domain entity) — capped,
    #    since 'related' is a much looser signal than a direct EXTENDS edge.
    if len(doc.sections) <= 1:
        neighbors = graph.neighbors("Entity", "key", entity_key, hops=2, env=env)
        for row in neighbors:
            if row["labels"] != ["Entity"]:
                continue
            other_key = row["node"].get("key")
            if not other_key or other_key in seen:
                continue
            article = wiki.get(other_key)
            if article is None:
                continue
            seen.add(other_key)
            doc.sections.append(DocumentSection(
                role="related", entity_key=other_key, title=article["meta"].get("title", other_key),
                body=article["body"], approved_by=article["meta"].get("approved_by"),
                version=article["meta"].get("version"), relationship=f"{row['distance']} hop(s)",
            ))
            if len(doc.sections) - 1 >= max_related:
                break

    return doc
