"""Coverage reporting — answers 'how much of the governed knowledge base
actually maps to each persona' and 'what product/country coverage exists',
as a queryable summary rather than something you can only see one query at
a time through the context builder. Read-only: computed live from the same
Elasticsearch index and Neo4j graph everything else reads from, never a
separately maintained count.
"""
from __future__ import annotations

from elasticsearch import Elasticsearch

from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.models import AgentRole
from pipeline.serving.context_builder import _POLICIES


def persona_coverage(es_client: Elasticsearch, index_name: str) -> list[dict]:
    """For each of the seven personas: which intents serve them, the union
    of viewpoints those intents' policies draw from, and how many indexed
    documents currently carry at least one of those viewpoints — i.e. how
    much of the knowledge base that persona can actually be served from
    right now, not how many documents exist in total."""
    results = []
    for role in AgentRole:
        intents, viewpoints, source_types = [], set(), set()
        for intent, policy in _POLICIES.items():
            if role.value in policy.get("primary_roles", []):
                intents.append(intent)
                sources = policy.get("sources", {})
                viewpoints |= set(sources.get("required_viewpoints", []))
                viewpoints |= set(sources.get("optional_viewpoints", []))

        doc_count = 0
        by_source_type: dict[str, int] = {}
        if viewpoints:
            resp = es_client.search(
                index=index_name,
                query={"terms": {"viewpoints": sorted(viewpoints)}},
                aggs={"by_source": {"terms": {"field": "source_type"}}},
                size=0,
            )
            doc_count = resp["hits"]["total"]["value"]
            by_source_type = {b["key"]: b["doc_count"] for b in resp["aggregations"]["by_source"]["buckets"]}

        results.append({
            "role": role.value,
            "intents": intents,
            "viewpoints": sorted(viewpoints),
            "document_count": doc_count,
            "by_source_type": by_source_type,
        })
    return results


def product_country_matrix(graph: GraphBuilder, env: str = "production") -> list[dict]:
    """Groups every governed Product node by code: the base row plus every
    jurisdiction/variant overlay approved so far, each with its approving
    reviewer and version — the base+country coverage view. Each group also
    carries `family` (e.g. 'Instant Retail Payments') so the UI can nest
    sibling product codes — RTGS, FAST-SG, IMPS-IN, FPS-HK — under a shared
    category even though they don't EXTEND a common base."""
    rows = graph.list_products(env=env)
    by_code: dict[str, dict] = {}
    for row in rows:
        product = row["product"]
        code = product["code"]
        entry = by_code.setdefault(code, {"code": code, "domain": product.get("domain"), "family": None,
                                            "base": None, "variants": []})
        if product.get("family"):
            entry["family"] = product["family"]
        article = row["article"]
        item = {
            "key": product["key"],
            "variant_key": product.get("variant_key"),
            "approved_by": article.get("approved_by") if article else None,
            "version": article.get("version") if article else None,
            "title": article.get("title") if article else None,
        }
        if product.get("scope") == "base":
            entry["base"] = item
        else:
            entry["variants"].append(item)
    for entry in by_code.values():
        if not entry["family"]:
            entry["family"] = "Ungrouped"
    return list(by_code.values())


def capability_matrix(graph: GraphBuilder, env: str = "production") -> list[dict]:
    """Product line x country x sub-type x direction — the Product
    Capability Matrix. Rows are (product_line, country) pairs; each carries
    its list of implemented capabilities, split by direction. Direction
    matters operationally, not just descriptively: inward transactions
    arrive from a regulator/external bank and are screened/credited on
    receipt, outward transactions are customer/channel-initiated and are
    screened/released before send — different triggers, different SLAs.
    Scaling this to more countries or product lines is adding mock source
    files, not writing code — see docs 'Extending it'."""
    rows = graph.list_capabilities(env=env)
    by_group: dict[tuple[str, str], dict] = {}
    for row in rows:
        product, cap = row["product"], row["capability"]
        code = product.get("code")
        country = product.get("country") or product.get("variant_key") or "—"
        key = (code, country)
        entry = by_group.setdefault(key, {
            "product_line": code, "country": country, "family": product.get("family") or "Ungrouped",
            "product_key": product.get("key"), "inward": [], "outward": [],
        })
        direction = cap.get("direction", "").lower()
        bucket = entry["inward"] if direction == "inward" else entry["outward"]
        bucket.append(cap.get("sub_type"))
    return sorted(by_group.values(), key=lambda e: (e["family"], e["product_line"], e["country"]))
