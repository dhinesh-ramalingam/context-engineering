"""Agent scratchpad — Context-Engineering-Platform-Design Layer 07, the
piece that lets a multi-step agentic loop ('read the spec, then the code,
then the tests') build up context incrementally instead of re-fetching the
same thing at every step. Session-scoped, file-backed (this pipeline has no
Redis dependency by design — everything runs local-only), TTL-free for the
demo but structured exactly like the design doc's task-graph shape:
requested / produced / pending per session, not free text the model has to
re-read and re-infer state from.

Deliberately NOT a semantic/episodic long-term memory (Layer 08) — nothing
here is trusted across sessions or written back to the glossary/wiki. It
only prevents the *current* session from paying for the same context twice.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from pipeline.config import settings

_SESSIONS_DIR = settings.data_dir / "sessions"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Session:
    def __init__(self, session_id: str):
        self.session_id = session_id
        self.path = _SESSIONS_DIR / f"{session_id}.json"
        self.retrieved_doc_ids: set[str] = set()
        self.retrieved_entity_keys: set[str] = set()
        self.history: list[dict] = []
        self._load()

    def _load(self) -> None:
        if self.path.exists():
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.retrieved_doc_ids = set(data.get("retrieved_doc_ids", []))
            self.retrieved_entity_keys = set(data.get("retrieved_entity_keys", []))
            self.history = data.get("history", [])

    def save(self) -> None:
        _SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps({
            "session_id": self.session_id,
            "retrieved_doc_ids": sorted(self.retrieved_doc_ids),
            "retrieved_entity_keys": sorted(self.retrieved_entity_keys),
            "history": self.history,
            "updated": _now(),
        }, indent=2), encoding="utf-8")

    def already_seen(self, doc_id: str) -> bool:
        return doc_id in self.retrieved_doc_ids

    def record(self, query: str, intent: str, agent_role: str, item_ids: list[str], entity_keys: list[str]) -> None:
        self.retrieved_doc_ids.update(item_ids)
        self.retrieved_entity_keys.update(k for k in entity_keys if k)
        self.history.append({
            "query": query, "intent": intent, "agent_role": agent_role,
            "item_ids": item_ids, "entity_keys": entity_keys, "at": _now(),
        })
        self.save()


def get_session(session_id: str) -> Session:
    return Session(session_id)


def load_session_summary(session_id: str) -> Optional[dict]:
    path = _SESSIONS_DIR / f"{session_id}.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))
