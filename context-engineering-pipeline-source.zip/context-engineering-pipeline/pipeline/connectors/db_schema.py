from __future__ import annotations

from typing import Iterable

from .base import RawItem, SourceConnector


class DbSchemaConnector(SourceConnector):
    """Structured regime — introspected schema, parsed not graded. Serves
    two purposes: (1) the structured source of truth §06 drift detection
    diffs narrative data-model claims against, and (2) DbTable nodes in the
    code-to-database dependency graph (see indexing/graph_builder.py)."""

    source_type = "db_schema"

    def connect(self) -> bool:
        return self.root.exists()

    def list_items(self) -> Iterable[str]:
        for p in sorted(self.root.glob("*.json")):
            yield p.stem

    def fetch(self, item_id: str) -> RawItem:
        path = self.root / f"{item_id}.json"
        data = self._read_json(path)
        return RawItem(
            item_id=item_id,
            content=data,
            content_format="json",
            updated=data.get("synced_at", ""),
            path=str(path),
            metadata={"schema": data.get("schema"), "table_count": len(data.get("tables", []))},
        )
