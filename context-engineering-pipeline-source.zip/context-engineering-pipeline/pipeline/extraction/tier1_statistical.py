"""KNOW-EXTRACT §05 — Tier 1 Statistical & Lexical.

Classical, fully explainable, no-inference-cost NLP sitting between regex
and a language model: BM25 relevance against a domain lexicon, MinHash
near-duplicate detection over the Tier-0 survivor set, and a small
supervised classifier that starts untrained (defers to the Tier-0 verdict)
and retrains once enough reviewer decisions accumulate — the calibration
loop KNOW-EXTRACT §10 calls for.
"""
from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import joblib
import numpy as np
from sklearn.linear_model import LogisticRegression

from pipeline.config import settings

_TOKEN_RE = re.compile(r"[a-z0-9]+")

# A maintained per-domain lexicon (config, not code, in a real rollout) used
# as the BM25 "query" each survivor is scored against. Terms are weighted —
# a hit on a high-weight term contributes more than a hit on a common one.
DOMAIN_LEXICON: dict[str, float] = {
    "settlement": 2.0, "sanctions": 2.0, "screening": 1.5, "cutoff": 2.0,
    "cut-off": 2.0, "threshold": 1.5, "fast": 1.0, "rtgs": 1.8, "clearing": 1.5,
    "uetr": 1.8, "dispatch": 1.5, "aml": 2.0, "regulator": 1.5, "regulatory": 1.5,
    "idempotent": 1.2, "escalation": 1.3, "retry": 1.2, "dispute": 1.5,
    "quote": 1.2, "fx": 1.5, "counterparty": 1.5, "ifsc": 1.5, "chaps": 1.5,
    "reconcile": 1.2, "sla": 1.5, "compliance": 1.5, "overlay": 1.0,
}


def tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())


# ---------------------------------------------------------------------------
# BM25 relevance vs the domain lexicon
# ---------------------------------------------------------------------------

@dataclass
class Bm25Corpus:
    """IDF/avgdl computed once over a survivor set — 'runs once per survivor
    set, not per raw document,' per KNOW-EXTRACT §05."""
    doc_freq: dict[str, int]
    n_docs: int
    avg_doc_len: float
    k1: float = 1.5
    b: float = 0.75

    @classmethod
    def build(cls, documents: list[str]) -> "Bm25Corpus":
        tokenized = [tokenize(d) for d in documents]
        df: dict[str, int] = {}
        for toks in tokenized:
            for term in set(toks):
                df[term] = df.get(term, 0) + 1
        avgdl = sum(len(t) for t in tokenized) / max(len(tokenized), 1)
        return cls(doc_freq=df, n_docs=len(tokenized), avg_doc_len=avgdl or 1.0)

    def _idf(self, term: str) -> float:
        n_q = self.doc_freq.get(term, 0)
        return math.log(1 + (self.n_docs - n_q + 0.5) / (n_q + 0.5))

    def score(self, document: str, query_terms: dict[str, float]) -> float:
        """Raw BM25 score, deliberately not squashed to [0,1] against a
        theoretical tf->infinity ceiling — that ceiling is never reached in
        practice (tf=1-3 for most terms), so normalizing against it made
        every real document score near zero. The floor in settings is
        calibrated against this raw scale instead."""
        tokens = tokenize(document)
        doc_len = len(tokens) or 1
        term_freq: dict[str, int] = {}
        for t in tokens:
            term_freq[t] = term_freq.get(t, 0) + 1

        raw = 0.0
        for term, weight in query_terms.items():
            tf = term_freq.get(term, 0)
            if tf == 0:
                continue
            idf = self._idf(term)
            denom = tf + self.k1 * (1 - self.b + self.b * doc_len / self.avg_doc_len)
            raw += weight * idf * (tf * (self.k1 + 1)) / denom
        return raw


# ---------------------------------------------------------------------------
# MinHash near-duplicate detection
# ---------------------------------------------------------------------------

_SALTS = [i * 2654435761 % (2**32) for i in range(1, 65)]  # 64 deterministic salts


def _shingles(text: str, k: int = 5) -> set[str]:
    tokens = tokenize(text)
    if len(tokens) < k:
        return {" ".join(tokens)} if tokens else set()
    return {" ".join(tokens[i:i + k]) for i in range(len(tokens) - k + 1)}


def minhash_signature(text: str, num_hashes: int = 64) -> tuple[int, ...]:
    shingles = _shingles(text)
    if not shingles:
        return tuple([0] * num_hashes)
    sig = []
    for salt in _SALTS[:num_hashes]:
        min_h = min(
            int(hashlib.md5(f"{salt}:{s}".encode()).hexdigest(), 16) for s in shingles
        )
        sig.append(min_h)
    return tuple(sig)


def estimated_jaccard(sig_a: tuple[int, ...], sig_b: tuple[int, ...]) -> float:
    if not sig_a or not sig_b or len(sig_a) != len(sig_b):
        return 0.0
    matches = sum(1 for a, b in zip(sig_a, sig_b) if a == b)
    return matches / len(sig_a)


def find_near_duplicates(items: list[tuple[str, str]], threshold: float | None = None) -> list[tuple[str, str, float]]:
    """items: [(id, text), ...]. Returns [(id_a, id_b, similarity), ...] for
    pairs at/above the threshold. O(n^2) — fine at the post-Tier-0 survivor
    scale this runs at."""
    threshold = threshold if threshold is not None else settings.near_dup_similarity_threshold
    sigs = [(item_id, minhash_signature(text)) for item_id, text in items]
    pairs = []
    for i in range(len(sigs)):
        for j in range(i + 1, len(sigs)):
            sim = estimated_jaccard(sigs[i][1], sigs[j][1])
            if sim >= threshold:
                pairs.append((sigs[i][0], sigs[j][0], sim))
    return pairs


# ---------------------------------------------------------------------------
# Supervised classifier over reviewer decisions (KNOW-EXTRACT §10 feedback loop)
# ---------------------------------------------------------------------------

FEATURE_NAMES = ["tier_numeric", "metadata_count", "structural_count", "domain_hits", "relevance_score"]
MIN_TRAINING_EXAMPLES = 20
_MODEL_PATH = settings.data_dir / "tier1_classifier.joblib"


class ReviewOutcomeClassifier:
    """Predicts P(reviewer approves) from the same features the Tier-0/1
    gate already computed. Inspectable feature weights, no generative
    inference. Starts untrained; falls back to the Tier-0 verdict until
    MIN_TRAINING_EXAMPLES reviewer decisions exist to fit against."""

    def __init__(self):
        self.model: Optional[LogisticRegression] = None
        self._load()

    def _load(self):
        if _MODEL_PATH.exists():
            self.model = joblib.load(_MODEL_PATH)

    @property
    def is_trained(self) -> bool:
        return self.model is not None

    def predict(self, features: dict[str, float]) -> Optional[float]:
        if not self.model:
            return None
        x = np.array([[features.get(f, 0.0) for f in FEATURE_NAMES]])
        return float(self.model.predict_proba(x)[0][1])

    def fit(self, examples: list[dict[str, float]], labels: list[int]) -> bool:
        if len(examples) < MIN_TRAINING_EXAMPLES:
            return False
        x = np.array([[ex.get(f, 0.0) for f in FEATURE_NAMES] for ex in examples])
        y = np.array(labels)
        if len(set(y.tolist())) < 2:
            return False  # needs both positive and negative examples
        model = LogisticRegression(max_iter=200)
        model.fit(x, y)
        self.model = model
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        joblib.dump(model, _MODEL_PATH)
        return True

    def feature_weights(self) -> Optional[dict[str, float]]:
        if not self.model:
            return None
        return dict(zip(FEATURE_NAMES, self.model.coef_[0].tolist()))
