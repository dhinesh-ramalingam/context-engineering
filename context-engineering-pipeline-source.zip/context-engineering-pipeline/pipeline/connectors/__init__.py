from .ado import AdoConnector
from .base import RawItem, SourceConnector
from .confluence import ConfluenceConnector
from .db_schema import DbSchemaConnector
from .git import GitConnector
from .logs import LogsConnector
from .plantuml import PlantUmlConnector
from .product_catalog import ProductCatalogConnector
from .runbook import RunbookConnector
from .swagger import SwaggerConnector

CONNECTOR_REGISTRY: dict[str, type[SourceConnector]] = {
    AdoConnector.source_type: AdoConnector,
    ConfluenceConnector.source_type: ConfluenceConnector,
    GitConnector.source_type: GitConnector,
    DbSchemaConnector.source_type: DbSchemaConnector,
    SwaggerConnector.source_type: SwaggerConnector,
    PlantUmlConnector.source_type: PlantUmlConnector,
    RunbookConnector.source_type: RunbookConnector,
    LogsConnector.source_type: LogsConnector,
    ProductCatalogConnector.source_type: ProductCatalogConnector,
}

__all__ = [
    "SourceConnector",
    "RawItem",
    "AdoConnector",
    "ConfluenceConnector",
    "GitConnector",
    "DbSchemaConnector",
    "SwaggerConnector",
    "PlantUmlConnector",
    "RunbookConnector",
    "LogsConnector",
    "ProductCatalogConnector",
    "CONNECTOR_REGISTRY",
]
