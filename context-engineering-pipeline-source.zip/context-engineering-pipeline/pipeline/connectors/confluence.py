from __future__ import annotations

from typing import Iterable

from .base import RawItem, SourceConnector


class ConfluenceConnector(SourceConnector):
    source_type = "confluence"

    def connect(self) -> bool:
        return self.root.exists()

    def list_items(self) -> Iterable[str]:
        for p in sorted(self.root.glob("*.json")):
            yield p.stem

    def fetch(self, item_id: str) -> RawItem:
        path = self.root / f"{item_id}.json"
        data = self._read_json(path)
        return RawItem(
            item_id=data["id"],
            content=data,
            content_format="json",
            updated=data.get("updated", ""),
            path=str(path),
            metadata={
                "page_type": data.get("page_type"),
                "status": data.get("status"),
                "owner": data.get("owner"),
                "labels": data.get("labels", []),
                "version": data.get("version"),
                "space": data.get("space"),
            },
        )
