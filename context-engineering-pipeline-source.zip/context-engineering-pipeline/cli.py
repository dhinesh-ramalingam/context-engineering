#!/usr/bin/env python
"""Command-line entry point for the context engineering pipeline.

    python cli.py run --mode full --reset
    python cli.py review list
    python cli.py review show <candidate_id>
    python cli.py review decide <candidate_id> --reviewer "R. Tan" --action approve
    python cli.py promote <run_id>
    python cli.py query "sanctions screening for FAST payments" --role developer
    python cli.py wiki list
    python cli.py prioritize
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from pipeline.config import settings
from pipeline.governance.review_store import ReviewStore, SegregationOfDutiesError
from pipeline.governance.wiki_publish import WikiRepo
from pipeline.indexing import es_index
from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.models import ObjectStatus, ReviewDecisionAction, RunMode
from pipeline.orchestrator import approve_and_publish, refresh_conflict_check, run_pipeline
from pipeline.serving.context_builder import ContextBuilder
from pipeline.serving.prioritization import rank_entities


def cmd_run(args):
    mode = RunMode.ISOLATED if args.mode == "isolated" else RunMode.FULL
    run = run_pipeline(mode=mode, reset=args.reset, incremental=args.incremental)
    print(f"run id: {run.id}")
    print(f"mode: {run.mode.value}  status: {run.status.value}")
    print("funnel:")
    for k, v in run.funnel.items():
        print(f"  {k:24} {v}")
    if mode == RunMode.ISOLATED:
        print(f"\nIsolated run wrote to the staging index/graph only. Promote with:\n  python cli.py promote {run.id}")


def cmd_watch(args):
    import time

    print(f"watching sources every {args.interval}s (mode={args.mode}, incremental)."
          f"{' max ' + str(args.max_cycles) + ' cycles.' if args.max_cycles else ' Ctrl+C to stop.'}")
    mode = RunMode.ISOLATED if args.mode == "isolated" else RunMode.FULL
    cycle = 0
    try:
        while True:
            cycle += 1
            run = run_pipeline(mode=mode, reset=False, incremental=True)
            skipped = run.funnel.get("skipped_unchanged_since_watermark", 0)
            new = run.funnel.get("raw_narrative_docs", 0)
            print(f"[cycle {cycle}] run={run.id} new/changed={new} unchanged_skipped={skipped} "
                  f"candidates={run.funnel.get('tier2_candidates', 0)}")
            if args.max_cycles and cycle >= args.max_cycles:
                break
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nstopped.")


def cmd_review_list(args):
    store = ReviewStore()
    status = ObjectStatus(args.status) if args.status else ObjectStatus.PENDING_REVIEW
    items = store.list_candidates(status=status)
    print(f"{len(items)} candidate(s) with status={status.value}\n")
    for c in items:
        conflicts = store.conflicts_for(c.id)
        flags = []
        if conflicts:
            flags.append(f"CONFLICT(sev={max(x.severity for x in conflicts):.2f})")
        if c.drift_flag:
            flags.append("DRIFT")
        if c.near_duplicate_of:
            flags.append(f"NEAR_DUP({c.near_duplicate_of})")
        flag_str = " ".join(flags)
        print(f"{c.id}  [{c.gate_verdict.value:12}] {c.source_type.value:10} {c.title[:55]:55} {flag_str}")


def cmd_review_show(args):
    store = ReviewStore()
    obj = store.get_candidate(args.candidate_id)
    if not obj:
        print("not found", file=sys.stderr)
        sys.exit(1)
    refreshed = refresh_conflict_check(args.candidate_id)
    print(f"# {obj.title}")
    print(f"source: {obj.source_type.value}:{obj.source_item_id}  entity: {obj.canonical_entity_key} (match={obj.entity_match_method})")
    print(f"gate: {obj.gate_verdict.value}  relevance: {obj.relevance_score}  drift: {obj.drift_flag} ({obj.drift_detail})")
    print(f"viewpoints: {obj.viewpoints}")
    print(f"\nsummary: {obj.summary}")
    if obj.business_rules:
        print("business_rules:")
        for r in obj.business_rules:
            print(f"  - {r}")
    if refreshed:
        print(f"\n*** CONFLICT sev={refreshed.severity:.2f} ***\n{refreshed.rationale}")
        canonical = WikiRepo().get(obj.canonical_entity_key)
        if canonical:
            print(f"\n--- canonical (current, v{canonical['meta'].get('version')}) ---\n{canonical['body'][:800]}")
    print(f"\n--- candidate body ---\n{obj.body[:800]}")


def cmd_review_decide(args):
    try:
        result = approve_and_publish(
            args.candidate_id, reviewer=args.reviewer,
            action=ReviewDecisionAction(args.action), note=args.note or "",
        )
    except SegregationOfDutiesError as e:
        print(f"REJECTED: {e}", file=sys.stderr)
        sys.exit(1)
    print(json.dumps(result, indent=2, default=str))


def cmd_promote(args):
    graph = GraphBuilder()
    graph.promote_staging()
    graph.close()
    client = es_index.get_client()
    n = es_index.promote_staging_to_prod(client, settings.es_index_staging, settings.es_index_prod)
    print(f"promoted staging graph -> production; reindexed {n} ES docs staging -> production")


def cmd_query(args):
    cb = ContextBuilder(env="production")
    bundle = cb.build(args.text, agent_role=args.role, intent=args.intent, top_k=args.top_k, session_id=args.session)
    print(f"intent: {bundle.intent} (confidence={bundle.intent_confidence:.2f})")
    if args.session:
        already = sum(1 for i in bundle.items if i.already_seen)
        print(f"session: {args.session}  ({already}/{len(bundle.items)} items already delivered earlier this session)")
    print(f"tokens: {bundle.tokens_used}/{bundle.token_budget}  guardrail_clean: {bundle.guardrail_clean}")
    print()
    if args.full:
        print(bundle.assembled_text)
    else:
        for item in bundle.items:
            print(f"[{item.tag:16}] score={item.score:.3f} {item.source_type:14} {item.title}")
        if bundle.graph_notes:
            print("\ngraph notes:")
            for n in bundle.graph_notes:
                print(" ", n)
    cb.close()


def cmd_session_show(args):
    from pipeline.serving.session_memory import load_session_summary
    summary = load_session_summary(args.session_id)
    if not summary:
        print("no such session")
        sys.exit(1)
    print(f"session: {summary['session_id']}  updated: {summary['updated']}")
    print(f"retrieved_doc_ids: {len(summary['retrieved_doc_ids'])}")
    print(f"retrieved_entity_keys: {summary['retrieved_entity_keys']}")
    print("history:")
    for h in summary["history"]:
        print(f"  [{h['at']}] {h['agent_role']:10} intent={h['intent']:20} \"{h['query']}\" -> {len(h['item_ids'])} items")


def cmd_wiki_list(args):
    wiki = WikiRepo()
    for a in wiki.list_articles():
        print(f"{a.get('entity_key'):30} v{a.get('version')}  {a.get('title')}  (approved by {a.get('approved_by')})")


def cmd_wiki_document(args):
    from pipeline.indexing.graph_builder import GraphBuilder
    from pipeline.serving.document_view import build_full_document

    graph = GraphBuilder()
    doc = build_full_document(graph, WikiRepo(), args.entity_key)
    graph.close()
    if doc is None:
        print("no canonical article for this entity_key", file=sys.stderr)
        sys.exit(1)
    for s in doc.sections:
        tag = "" if s.role == "base" else f" [{s.role}{' via ' + s.relationship if s.relationship else ''}]"
        print(f"\n{'=' * 70}\n{s.title}{tag}  (v{s.version}, approved by {s.approved_by})\n{'=' * 70}")
        print(s.body)


def cmd_coverage(args):
    from pipeline.indexing import es_index
    from pipeline.indexing.graph_builder import GraphBuilder
    from pipeline.serving.coverage import persona_coverage, product_country_matrix

    print("=== Persona coverage — documents currently mapped per role ===")
    client = es_index.get_client()
    for row in persona_coverage(client, settings.es_index_prod):
        by_source = ", ".join(f"{k}={v}" for k, v in row["by_source_type"].items())
        print(f"{row['role']:10} docs={row['document_count']:3}  intents={row['intents']}")
        print(f"{'':10} viewpoints={row['viewpoints']}")
        if by_source:
            print(f"{'':10} by source: {by_source}")

    print("\n=== Product / country (jurisdiction) coverage ===")
    graph = GraphBuilder()
    for entry in product_country_matrix(graph):
        base = entry["base"]
        print(f"{entry['code']} ({entry['domain']})  base={'v' + str(base['version']) + ' approved by ' + base['approved_by'] if base else 'MISSING'}")
        for v in entry["variants"]:
            print(f"    {v['variant_key']:6} v{v['version']} approved by {v['approved_by']}  {v['title']}")

    print("\n=== Product Capability Matrix (product line x country x sub-type x direction) ===")
    from pipeline.serving.coverage import capability_matrix
    current_family = None
    for row in capability_matrix(graph):
        if row["family"] != current_family:
            current_family = row["family"]
            print(f"\n-- {current_family} --")
        outward = ", ".join(row["outward"]) or "-"
        inward = ", ".join(row["inward"]) or "-"
        print(f"  {row['product_line']:10} {row['country']:4}  outward: {outward:45} inward: {inward}")
    graph.close()


def cmd_ace_scan(args):
    from pipeline.orchestrator import ace_scan
    report = ace_scan(min_cluster_size=args.min_cluster_size)
    print(f"scanned {report['documents_scanned']} docs -> {report['survivors']} Tier-0/1 survivors "
          f"-> {report['clusters_found']} pattern clusters\n")
    if report["new_strategies_proposed"]:
        print(f"=== New strategies proposed (Generation phase) ===")
        for s in report["new_strategies_proposed"]:
            print(f"  [{s['count']:3} docs] {s['signature']}")
            print(f"           entry={s['entry_id']}  strategy: {s['strategy']}")
    if report["existing_strategies"]:
        print(f"\n=== Clusters with an existing strategy already ===")
        for s in report["existing_strategies"]:
            print(f"  [{s['count']:3} docs] {s['signature']}  ({s['entries']} entrie(s) on file)")
    if report["below_cluster_threshold"]:
        print(f"\n=== Below cluster threshold (--min-cluster-size {args.min_cluster_size}), no strategy proposed ===")
        for s in report["below_cluster_threshold"]:
            print(f"  [{s['count']:3} docs] {s['signature']}")


def cmd_ace_curate(args):
    from pipeline.extraction.ace_playbook import Playbook
    playbook = Playbook()
    report = playbook.curate()
    for label in ("promoted", "retired", "unchanged"):
        ids = report[label]
        print(f"{label}: {len(ids)}")
        for eid in ids:
            e = playbook.entries[eid]
            rate = f"{e.success_rate:.2f}" if e.success_rate is not None else "n/a"
            print(f"  {eid}  {e.pattern_signature:45} status={e.status:8} uses={e.uses} success_rate={rate}")


def cmd_ace_show(args):
    from pipeline.extraction.ace_playbook import Playbook
    playbook = Playbook()
    if not playbook.entries:
        print("playbook is empty — run `python cli.py ace scan` first")
        return
    for e in sorted(playbook.entries.values(), key=lambda x: x.pattern_signature):
        rate = f"{e.success_rate:.2f}" if e.success_rate is not None else "n/a"
        print(f"[{e.status:8}] {e.pattern_signature}")
        print(f"           uses={e.uses} approvals={e.approvals} rejections={e.rejections} "
              f"changes_requested={e.changes_requested} success_rate={rate}")
        print(f"           strategy: {e.strategy_text}")
        print(f"           learned from: {e.sample_titles}")


def cmd_prioritize(args):
    store = ReviewStore()
    graph = GraphBuilder()
    entity_keys = {c.canonical_entity_key for c in store.list_candidates() if c.canonical_entity_key}
    from pipeline.extraction.entity_resolution import Glossary
    glossary = Glossary()
    entities = [
        {"entity_key": k, "label": glossary.label(k) or k, "component_name": graph.implemented_by_name(k)}
        for k in entity_keys
    ]
    ranked = rank_entities(graph, entities)
    for score in ranked:
        print(f"{score.score:.3f}  {score.entity_key:30} {score.label:35} blast={score.blast_radius} incidents={score.incident_count_30d} reg={score.regulatory_linked} open_work={score.open_work_items}")
    graph.close()


def main():
    parser = argparse.ArgumentParser(description="Context engineering pipeline CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    p_run = sub.add_parser("run", help="Run the pipeline")
    p_run.add_argument("--mode", choices=["full", "isolated"], default="full")
    p_run.add_argument("--reset", action="store_true")
    p_run.add_argument("--incremental", action="store_true", help="skip narrative items unchanged since the last watermark")
    p_run.set_defaults(func=cmd_run)

    p_watch = sub.add_parser("watch", help="Continuously re-run the pipeline on an interval, incrementally")
    p_watch.add_argument("--mode", choices=["full", "isolated"], default="full")
    p_watch.add_argument("--interval", type=int, default=300, help="seconds between cycles (default 300)")
    p_watch.add_argument("--max-cycles", type=int, default=None, help="stop after N cycles (default: run forever)")
    p_watch.set_defaults(func=cmd_watch)

    p_review = sub.add_parser("review", help="Maker-checker review queue")
    review_sub = p_review.add_subparsers(dest="review_command", required=True)

    p_list = review_sub.add_parser("list")
    p_list.add_argument("--status", default=None)
    p_list.set_defaults(func=cmd_review_list)

    p_show = review_sub.add_parser("show")
    p_show.add_argument("candidate_id")
    p_show.set_defaults(func=cmd_review_show)

    p_decide = review_sub.add_parser("decide")
    p_decide.add_argument("candidate_id")
    p_decide.add_argument("--reviewer", required=True)
    p_decide.add_argument("--action", required=True, choices=["approve", "reject", "request_changes"])
    p_decide.add_argument("--note", default="")
    p_decide.set_defaults(func=cmd_review_decide)

    p_promote = sub.add_parser("promote", help="Promote a staging run to production")
    p_promote.add_argument("run_id", nargs="?", default=None)
    p_promote.set_defaults(func=cmd_promote)

    p_query = sub.add_parser("query", help="Query the AI Context Builder")
    p_query.add_argument("text")
    p_query.add_argument("--role", required=True, choices=["ba", "architect", "designer", "developer", "tester", "sre", "pm"])
    p_query.add_argument("--intent", default=None)
    p_query.add_argument("--top-k", type=int, default=12)
    p_query.add_argument("--session", default=None, help="session id — enables multi-step working memory across calls")
    p_query.add_argument("--full", action="store_true", help="print the fully assembled context text")
    p_query.set_defaults(func=cmd_query)

    p_wiki = sub.add_parser("wiki", help="Browse the canonical knowledge wiki")
    wiki_sub = p_wiki.add_subparsers(dest="wiki_command", required=True)
    p_wiki_list = wiki_sub.add_parser("list")
    p_wiki_list.set_defaults(func=cmd_wiki_list)

    p_wiki_doc = wiki_sub.add_parser("document", help="Full merged document: base article + all overlays/related sections")
    p_wiki_doc.add_argument("entity_key")
    p_wiki_doc.set_defaults(func=cmd_wiki_document)

    p_session = sub.add_parser("session", help="Inspect a working-memory session")
    session_sub = p_session.add_subparsers(dest="session_command", required=True)
    p_session_show = session_sub.add_parser("show")
    p_session_show.add_argument("session_id")
    p_session_show.set_defaults(func=cmd_session_show)

    p_prioritize = sub.add_parser("prioritize", help="PM criticality ranking across known entities")
    p_prioritize.set_defaults(func=cmd_prioritize)

    p_ace = sub.add_parser("ace", help="ACE — evolving extraction playbook (Generation/Reflection/Curation)")
    ace_sub = p_ace.add_subparsers(dest="ace_command", required=True)

    p_ace_scan = ace_sub.add_parser("scan", help="Scan all narrative sources, cluster by pattern, propose new strategies")
    p_ace_scan.add_argument("--min-cluster-size", type=int, default=2)
    p_ace_scan.set_defaults(func=cmd_ace_scan)

    p_ace_curate = ace_sub.add_parser("curate", help="Promote/retire playbook entries by accumulated success rate")
    p_ace_curate.set_defaults(func=cmd_ace_curate)

    p_ace_show = ace_sub.add_parser("show", help="Show the full playbook")
    p_ace_show.set_defaults(func=cmd_ace_show)

    p_coverage = sub.add_parser("coverage", help="Per-persona document mapping + product/country coverage matrix")
    p_coverage.set_defaults(func=cmd_coverage)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
