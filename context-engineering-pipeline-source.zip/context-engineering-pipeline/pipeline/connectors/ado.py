from __future__ import annotations

from pathlib import Path
from typing import Iterable

from .base import RawItem, SourceConnector


class AdoConnector(SourceConnector):
    source_type = "ado"

    def connect(self) -> bool:
        return self.root.exists()

    def list_items(self) -> Iterable[str]:
        for p in sorted(self.root.glob("*.json")):
            yield p.stem

    def fetch(self, item_id: str) -> RawItem:
        path = self.root / f"{item_id}.json"
        data = self._read_json(path)
        return RawItem(
            item_id=data["id"],
            content=data,
            content_format="json",
            updated=data.get("updated", ""),
            path=str(path),
            metadata={
                "type": data.get("type"),
                "state": data.get("state"),
                "owner": data.get("owner"),
                "tags": data.get("tags", []),
                "area_path": data.get("area_path"),
            },
        )
