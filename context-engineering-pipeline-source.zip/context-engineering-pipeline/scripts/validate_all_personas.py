"""Explicit per-persona validation: one representative query per agent role
(BA, Architect, Designer, Developer, Tester, SRE, PM), run through the exact
same ContextBuilder every CLI/API/MCP call uses, printing intent, top hits,
and whether the result is actually shaped right for that persona — e.g. a
Tester shouldn't get flooded with product roadmap content, an SRE query
should surface a runbook, not a user story."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.serving.context_builder import ContextBuilder
from pipeline.serving.prioritization import compute_criticality
from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.extraction.entity_resolution import Glossary
from pipeline.governance.wiki_publish import WikiRepo

CASES = [
    ("ba", "Create a spec for the FAST cut-off peak-period extension"),
    ("architect", "Architecture review of the payment settlement flow and its dependencies"),
    ("designer", "What fields and contract does the India RTGS payment request need?"),
    ("developer", "Implement sanctions screening validation in PaymentDispatcher"),
    ("tester", "Generate regression tests for the FAST settlement change"),
    ("sre", "Runbook for sanctions screening timeout incidents"),
]

cb = ContextBuilder(env="production")
for role, query in CASES:
    bundle = cb.build(query, agent_role=role, top_k=8)
    print(f"\n=== {role.upper():10} | intent={bundle.intent} (conf={bundle.intent_confidence:.2f}) ===")
    print(f"query: {query}")
    print(f"tokens: {bundle.tokens_used}/{bundle.token_budget}  guardrail_clean={bundle.guardrail_clean}  filter_relaxed={bundle.filter_relaxed}")
    for item in bundle.items[:4]:
        print(f"  [{item.tag:16}] {item.source_type:14} vp={','.join(item.viewpoints):55} {item.title}")
    if not bundle.items:
        print("  (no items retrieved)")
cb.close()

print(f"\n=== PM | prioritize_backlog ===")
graph = GraphBuilder()
glossary = Glossary()
wiki = WikiRepo()
entity_keys = {a.get("entity_key") for a in wiki.list_articles() if a.get("entity_key")}
scores = sorted(
    (compute_criticality(graph, k, glossary.label(k) or k, graph.implemented_by_name(k)) for k in entity_keys),
    key=lambda s: -s.score,
)
for s in scores[:5]:
    print(f"  {s.score:.3f}  {s.entity_key:30} blast={s.blast_radius} incidents={s.incident_count_30d} reg={s.regulatory_linked} open_work={s.open_work_items}")
graph.close()
