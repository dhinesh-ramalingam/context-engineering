---
title: VAS — Singapore (Value Added Services)
entity_key: products.vas.sg
source_type: product_catalog
source_ref: product_catalog-1:PROD-VAS-SG
candidate_id: cko-5f504f714016
viewpoints: [business_domain, business_process, interface_design, regulatory_product]
version: 1
approved_by: K. Mensah
published_at: 2026-08-16T20:33:53.364982+00:00
status: Active
---

# VAS — Singapore (Value Added Services)

## Summary
This document outlines the business rules for value-added services in Singapore, focusing on bill payments and standing instructions that use FAST or ACH-equivalent rails.

## Purpose
Defines the platform's rules for value-added payment services layered on top of the core rails — bill payment and standing instructions — for Singapore customers.

## Interfaces
- BillPaymentRequest
- StandingInstructionRequest

## Business Rules
- - VAS is outward-only by definition — a bill payment or standing instruction is always customer/channel-initiated; there is no 'inward VAS' concept, unlike a settlement rail that can receive external-bank-initiated inward transactions.
- - A standing instruction executes on its scheduled date via the underlying rail (typically FAST); if the underlying rail fails, the VAS layer retries per the underlying rail's own retry policy, it does not define a separate one.

## Dependencies
- FAST — Singapore (Instant Payment Rail)
- biller directory service

## Source Content
# VAS — Singapore (Value Added Services)

## Purpose
Defines the platform's rules for value-added payment services layered on top of the core rails — bill payment and standing instructions — for Singapore customers.

## Scope
Applies to customer-initiated recurring or one-off service payments that route through one of the core rails (FAST or ACH-equivalent) underneath, rather than being a settlement rail in their own right.

## Business Rules
- VAS is outward-only by definition — a bill payment or standing instruction is always customer/channel-initiated; there is no 'inward VAS' concept, unlike a settlement rail that can receive external-bank-initiated inward transactions.
- A standing instruction executes on its scheduled date via the underlying rail (typically FAST); if the underlying rail fails, the VAS layer retries per the underlying rail's own retry policy, it does not define a separate one.

## Interfaces
`BillPaymentRequest` — `payerAccount`, `billerId`, `amountMinorUnits`, `dueDate`. `StandingInstructionRequest` — `payerAccount`, `payeeAccount`, `amountMinorUnits`, `frequency`, `nextRunDate`.

## Dependencies
FAST — Singapore (Instant Payment Rail), biller directory service.

