# Context Engineering Pipeline

A working reference implementation of the three companion design documents one directory up
(`Business-Knowledge-Capabilities-Pipeline-Design-Approach.html`, `Knowledge-Extraction-Quality-Approach.html`,
`Context-Engineering-Platform-Design.html`): a governed knowledge extraction pipeline with a
maker-checker gate, a hybrid-retrieval + GraphRAG knowledge base, and a context-serving agent that
seven SDLC personas (BA, Architect, Designer, Developer, Tester, SRE, PM) can call from VS Code via MCP.

**Start here:** [`docs/Context-Engineering-Pipeline-How-It-Works.html`](docs/Context-Engineering-Pipeline-How-It-Works.html)
— architecture, how every stage maps to the design docs, worked examples with real output, quality
results, and a full quickstart.

## Fastest path to a running system

```
docker compose up -d
ollama pull nomic-embed-text
python -m venv .venv && .venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe cli.py run --mode full --reset
.venv\Scripts\python.exe cli.py review list
```

Everything else — review console, MCP server, evaluation suite — is documented in the HTML doc above.
