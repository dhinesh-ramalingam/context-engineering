"""Query augmentation — Weaviate's 'Query Augmentation' pillar: refining a
raw, messy user query before it hits retrieval, rather than assuming the
literal string typed by the caller is already the best search query.

Deliberately deterministic and glossary-driven, not an LLM rewrite step: an
LLM call here would add latency to every single retrieval and risk
introducing terms the query didn't actually imply. Expanding with the
canonical label for any entity the query already names is a strictly
additive, explainable transformation — "RTGS" also searches for "Real-Time
Gross Settlement", "FAST" also searches for "FAST Transfer" — using the
same controlled vocabulary entity resolution already resolves candidates
against (extraction/entity_resolution.py), so there's no second source of
truth for what a term "means".
"""
from __future__ import annotations

from pipeline.extraction.entity_resolution import Glossary


def augment_query(query: str, glossary: Glossary) -> tuple[str, list[str]]:
    """Returns (augmented_query, matched_canonical_labels). If nothing in
    the query matches a known alias, returns the query unchanged."""
    q_norm = " ".join(query.lower().split())
    matched_labels: list[str] = []
    for entry in glossary.entries().values():
        label = entry.get("label", "")
        if not label:
            continue
        for alias in entry.get("aliases", []):
            if alias and alias.lower() in q_norm:
                matched_labels.append(label)
                break

    if not matched_labels:
        return query, []

    unique_labels = sorted(set(matched_labels) - {query.strip()})
    if not unique_labels:
        return query, matched_labels
    return f"{query} {' '.join(unique_labels)}", matched_labels
