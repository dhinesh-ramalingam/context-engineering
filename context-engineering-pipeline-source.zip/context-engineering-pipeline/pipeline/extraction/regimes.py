"""KNOW-EXTRACT §03 — Source Regimes. Routes each raw item to the strategy
its source type needs: score it (narrative), parse it (structured), or
aggregate it (telemetry). Only the narrative regime goes through Tier 0/1/2;
structured items are normalized straight into CandidateKnowledgeObjects
(they're correct by construction), and telemetry items are pre-aggregated by
their connector (see connectors/logs.py) before they ever reach here.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pipeline.connectors.base import RawItem
from pipeline.models import SOURCE_REGIME, SourceRegime

# Document type -> tier, for Tier-0 Condition 1 (KNOW-EXTRACT §04).
# Tier A/B = long-lived reference material; Tier C = working items that can
# still surface business rules (e.g. acceptance criteria) but need more
# corroborating evidence before the gate treats them as a Candidate.
DOC_TYPE_TIER: dict[str, str] = {
    "Architecture": "A",
    "ADR": "A",
    "Standards": "A",
    "Product Overview": "A",
    "Product Rule Base": "A",
    "Product Rule Country Overlay": "A",
    "API Spec": "B",
    "DB Design": "B",
    "Business Rules": "B",
    "Sequence Diagram": "B",
    "Runbook": "B",
    "Epic": "C",
    "Feature": "C",
    "Story": "C",
    "Bug": "C",
    "Task": "C",
    "Notes": "C",
}

# Sections a well-templated Tier A/B document is expected to have —
# KNOW-EXTRACT §04 Condition 5.
EXPECTED_SECTIONS = ["Purpose", "Scope", "Interfaces", "Errors", "Dependencies", "Business Rules", "Glossary"]

TEMPLATED_TYPES = {"Architecture", "ADR", "API Spec", "DB Design", "Business Rules", "Runbook",
                    "Product Rule Base", "Product Rule Country Overlay", "Standards", "Product Overview"}


@dataclass
class NormalizedDoc:
    """What every narrative-regime item looks like after normalization,
    regardless of whether it came from ADO, Confluence, a Runbook, or the
    Product Catalog — the Tier 0/1 gate only ever sees this shape."""
    source_connector_id: str
    source_type: str
    source_item_id: str
    title: str
    body_markdown: str
    doc_type: str
    status: str
    owner: str | None
    labels: list[str]
    version: Any
    updated: str
    superseded_by: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


def regime_for(source_type: str) -> str:
    return SOURCE_REGIME.get(source_type, SourceRegime.NARRATIVE.value)


def normalize_narrative(raw: RawItem, source_type: str, connector_id: str) -> NormalizedDoc:
    c = raw.content if isinstance(raw.content, dict) else {}
    if source_type == "ado":
        body = c.get("description", "") + "\n\n" + "\n".join(
            f"- {ac}" for ac in c.get("acceptance_criteria", [])
        )
        return NormalizedDoc(
            source_connector_id=connector_id, source_type=source_type, source_item_id=raw.item_id,
            title=c.get("title", ""), body_markdown=body, doc_type=c.get("type", "Story"),
            status=c.get("state", "Active"), owner=c.get("owner"), labels=c.get("tags", []),
            version=None, updated=raw.updated, superseded_by=c.get("superseded_by"),
            extra={"acceptance_criteria": c.get("acceptance_criteria", [])},
        )
    if source_type in ("confluence", "product_catalog"):
        return NormalizedDoc(
            source_connector_id=connector_id, source_type=source_type, source_item_id=raw.item_id,
            title=c.get("title", ""), body_markdown=c.get("body_markdown", ""),
            doc_type=c.get("page_type", "Notes"), status=c.get("status", "Active"),
            owner=c.get("owner"), labels=c.get("labels", []), version=c.get("version"),
            updated=raw.updated, superseded_by=c.get("superseded_by"),
            extra={k: c.get(k) for k in (
                "domain", "product_code", "scope", "variant_key", "base_product_id", "family",
                "capabilities", "country",
            )},
        )
    if source_type == "runbook":
        return NormalizedDoc(
            source_connector_id=connector_id, source_type=source_type, source_item_id=raw.item_id,
            title=c.get("title", raw.item_id), body_markdown=c.get("body_markdown", ""),
            doc_type="Runbook", status=c.get("status", "Active"), owner=c.get("owner"),
            labels=c.get("labels", []), version=c.get("version"), updated=raw.updated,
        )
    raise ValueError(f"no narrative normalizer for source type {source_type}")
