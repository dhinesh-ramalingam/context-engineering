"""KNOW-PIPE §05 — Maker-Checker.

The pipeline is always the Maker (a service identity, never a named
person). A named domain expert is always the Checker. Segregation of duties
is enforced here, not left to convention: a decision from the service
identity, or a blank reviewer, is rejected outright.

State machine: Draft -> Pending Review -> {Approved, Rejected, Changes
Requested (-> Draft)}. Every transition appends an immutable record to the
audit log — who, what changed, why, when — independent of the mutable
candidate record itself, so the audit trail can never be edited after the
fact even if the candidate is later revised.
"""
from __future__ import annotations

import difflib
import json
from pathlib import Path
from typing import Optional

from pipeline.config import settings
from pipeline.models import (
    CandidateKnowledgeObject,
    ConflictRecord,
    ObjectStatus,
    ReviewDecision,
    ReviewDecisionAction,
)

MAKER_IDENTITY = "pipeline-system"
_SERVICE_IDENTITIES = {"", "pipeline-system", "system", "service-account", "pipeline", "maker"}


class SegregationOfDutiesError(ValueError):
    pass


class ReviewStore:
    def __init__(self, root: Optional[Path] = None):
        self.root = root or settings.data_dir
        self.candidates_dir = self.root / "candidates"
        self.conflicts_dir = self.root / "conflicts"
        self.decisions_dir = self.root / "review_decisions"
        self.audit_log_path = self.root / "audit_log.jsonl"
        for d in (self.candidates_dir, self.conflicts_dir, self.decisions_dir):
            d.mkdir(parents=True, exist_ok=True)

    # --- candidates ---
    def save_candidate(self, obj: CandidateKnowledgeObject) -> None:
        (self.candidates_dir / f"{obj.id}.json").write_text(obj.model_dump_json(indent=2), encoding="utf-8")

    def get_candidate(self, candidate_id: str) -> Optional[CandidateKnowledgeObject]:
        path = self.candidates_dir / f"{candidate_id}.json"
        if not path.exists():
            return None
        return CandidateKnowledgeObject.model_validate_json(path.read_text(encoding="utf-8"))

    def list_candidates(self, status: Optional[ObjectStatus] = None) -> list[CandidateKnowledgeObject]:
        items = []
        for p in sorted(self.candidates_dir.glob("*.json")):
            obj = CandidateKnowledgeObject.model_validate_json(p.read_text(encoding="utf-8"))
            if status is None or obj.status == status:
                items.append(obj)
        return items

    # --- conflicts ---
    def save_conflict(self, record: ConflictRecord) -> None:
        (self.conflicts_dir / f"{record.id}.json").write_text(record.model_dump_json(indent=2), encoding="utf-8")

    def conflicts_for(self, candidate_id: str) -> list[ConflictRecord]:
        out = []
        for p in sorted(self.conflicts_dir.glob("*.json")):
            record = ConflictRecord.model_validate_json(p.read_text(encoding="utf-8"))
            if record.candidate_id == candidate_id:
                out.append(record)
        return out

    # --- workflow ---
    def submit_for_review(self, candidate_id: str) -> CandidateKnowledgeObject:
        obj = self.get_candidate(candidate_id)
        if obj is None:
            raise KeyError(candidate_id)
        obj.status = ObjectStatus.PENDING_REVIEW
        self.save_candidate(obj)
        self._append_audit(candidate_id, actor=MAKER_IDENTITY, action="submitted_for_review",
                            diff=None, why="Tier 0/1/2 pipeline produced this candidate for review.")
        return obj

    def decide(
        self,
        candidate_id: str,
        reviewer: str,
        action: ReviewDecisionAction,
        note: str = "",
        canonical_text: Optional[str] = None,
    ) -> ReviewDecision:
        if reviewer.strip().lower() in _SERVICE_IDENTITIES:
            raise SegregationOfDutiesError(
                f"Reviewer must be a named human identity, never a service account (got {reviewer!r})."
            )

        obj = self.get_candidate(candidate_id)
        if obj is None:
            raise KeyError(candidate_id)
        if obj.status != ObjectStatus.PENDING_REVIEW:
            raise ValueError(f"Candidate {candidate_id} is not pending review (status={obj.status}).")

        decision = ReviewDecision(candidate_id=candidate_id, reviewer=reviewer, action=action, note=note)
        (self.decisions_dir / f"{decision.id}.json").write_text(decision.model_dump_json(indent=2), encoding="utf-8")

        if action == ReviewDecisionAction.APPROVE:
            obj.status = ObjectStatus.APPROVED
        elif action == ReviewDecisionAction.REJECT:
            obj.status = ObjectStatus.REJECTED
        else:
            obj.status = ObjectStatus.CHANGES_REQUESTED
        self.save_candidate(obj)

        diff_text = None
        if canonical_text is not None:
            diff_text = "\n".join(difflib.unified_diff(
                canonical_text.splitlines(), obj.body.splitlines(),
                fromfile="canonical", tofile="candidate", lineterm="",
            ))

        conflicts = self.conflicts_for(candidate_id)
        rationale = "; ".join(c.rationale for c in conflicts) if conflicts else None

        self._append_audit(
            candidate_id, actor=reviewer, action=action.value, diff=diff_text,
            why=rationale, note=note,
        )
        return decision

    def audit_log(self, candidate_id: Optional[str] = None) -> list[dict]:
        if not self.audit_log_path.exists():
            return []
        entries = [json.loads(line) for line in self.audit_log_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        if candidate_id:
            entries = [e for e in entries if e["candidate_id"] == candidate_id]
        return entries

    def _append_audit(self, candidate_id: str, actor: str, action: str, diff: Optional[str],
                       why: Optional[str] = None, note: str = "") -> None:
        from pipeline.models import now_iso
        entry = {
            "candidate_id": candidate_id, "actor": actor, "action": action,
            "diff": diff, "why": why, "note": note, "timestamp": now_iso(),
        }
        with self.audit_log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
