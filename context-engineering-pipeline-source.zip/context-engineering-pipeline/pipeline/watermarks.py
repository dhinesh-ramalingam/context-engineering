"""Per-source watermarks — KNOW-PIPE §04's Source Connector interface
defines `watermark()` for incremental sync; this is what actually persists
and uses it. A source's watermark is the highest `updated` value seen
across all its items as of the last run; an incremental run only pushes
narrative items newer than that watermark through the (expensive) Tier 2
LLM cascade — 'Stages 1-5 can run repeatedly and cheaply in isolation'
only holds if repeated runs skip what hasn't changed.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from pipeline.config import settings

_PATH = settings.data_dir / "watermarks.json"


class WatermarkStore:
    def __init__(self, path: Path = _PATH):
        self.path = path
        self._data: dict[str, str] = {}
        if path.exists():
            self._data = json.loads(path.read_text(encoding="utf-8"))

    def get(self, source_type: str) -> Optional[str]:
        return self._data.get(source_type)

    def set(self, source_type: str, value: str) -> None:
        if not value:
            return
        self._data[source_type] = value
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self._data, indent=2, sort_keys=True), encoding="utf-8")

    def clear(self) -> None:
        self._data = {}
        if self.path.exists():
            self.path.unlink()


def is_newer(updated: str, watermark: Optional[str]) -> bool:
    """String comparison is intentional and sufficient here: every
    connector's `updated` value is either ISO-8601 (git commit timestamps,
    ADO/Confluence dates) or blank (structured sources with no natural
    edit time, e.g. PlantUML). Blank always compares as 'newer' — a source
    with no timestamp can't be watermarked, so it's never skipped."""
    if not updated:
        return True
    if not watermark:
        return True
    return updated > watermark
