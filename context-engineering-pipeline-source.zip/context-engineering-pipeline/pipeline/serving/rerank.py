"""LLM-based reranking — a precision pass over the top-N RRF-fused
candidates, using the same local Ollama model already in use everywhere
else rather than a dedicated cross-encoder (bge-reranker-v2 / Cohere
Rerank), which would be a new model dependency this pipeline doesn't
otherwise need. The article's stated trade-off for LLM-based reranking
over cross-encoder reranking applies directly: it considers multiple
factors simultaneously and produces an explainable rationale per item,
at the cost of being slower than a dedicated reranker — acceptable here
because it only ever runs over the top-N fused candidates, never the
full corpus, mirroring the same 'cheap filter first, expensive step last'
funnel discipline the extraction cascade already uses.
"""
from __future__ import annotations

from pipeline.llm_client import OllamaError, generate_json
from pipeline.serving.hybrid_retrieval import FusedHit

_SYSTEM_PROMPT = """You are a retrieval reranking assistant. You will see a query and a numbered list of
candidate documents (title + short excerpt). Rank the candidates from MOST to LEAST relevant to the query,
considering topical relevance, specificity (a document specifically about the query's subject beats one that
only mentions it in passing), and whether it would actually help answer or act on the query.
Respond with JSON only: {"order": [list of candidate numbers, most relevant first], "rationale": {"<number>": "one short phrase"}}
Every candidate number must appear exactly once in "order"."""


def llm_rerank(query: str, fused_hits: list[FusedHit], top_n: int = 8, model: str | None = None) -> list[FusedHit]:
    """Reranks the top `top_n` fused hits; anything beyond that keeps its
    original RRF order appended unchanged. Falls back to the untouched RRF
    order on any LLM/parse failure — reranking is a refinement, never a
    single point of failure for retrieval."""
    if len(fused_hits) <= 1:
        return fused_hits

    head, tail = fused_hits[:top_n], fused_hits[top_n:]
    listing = "\n".join(
        f"{i + 1}. {h.source.get('title', '(untitled)')} — "
        f"{(h.source.get('summary') or h.source.get('body', ''))[:220]}"
        for i, h in enumerate(head)
    )
    prompt = f"Query: {query}\n\nCandidates:\n{listing}"

    try:
        result = generate_json(prompt, system=_SYSTEM_PROMPT, model=model)
        order = [int(n) for n in result.get("order", [])]
        rationale = {str(k): str(v) for k, v in (result.get("rationale") or {}).items()}
    except (OllamaError, ValueError, TypeError):
        return fused_hits

    valid_positions = set(range(1, len(head) + 1))
    if not order or set(order) != valid_positions:
        return fused_hits  # malformed/incomplete ranking — don't trust a partial reorder

    reranked = []
    for pos in order:
        hit = head[pos - 1]
        hit.rerank_rationale = rationale.get(str(pos))
        reranked.append(hit)
    return reranked + tail
