"""ACE — Agentic Context Engineering, applied to bulk extraction from large
volumes of raw ADO epics/stories and Confluence pages.

The article this implements (github/medium "Advanced Context Engineering
Techniques") describes ACE as treating context as an *evolving playbook*
that accumulates and refines strategies through interaction, in three
phases: Generation (propose candidate strategies), Reflection (evaluate
what worked), Curation (promote winners, retire losers).

Applied here: scanning a large batch of raw narrative documents rarely
needs a single one-size-fits-all Tier 2 structuring prompt — a terse ADO
Story, a dense Confluence architecture page, and a Product Rule Base don't
extract well under identical guidance. Rather than hand-tuning the base
prompt per document type indefinitely, the playbook:

  1. GENERATION — clusters Tier-0/1 survivors by a cheap, deterministic
     pattern signature (source type + doc type + structural-richness band +
     domain-pattern-hit band — no ML clustering, fully explainable), and
     for any pattern with no existing strategy, asks the local LLM to
     propose one extraction-guidance instruction from a handful of sample
     documents in that cluster.
  2. REFLECTION — every maker-checker decision (Approve / Reject / Request
     Changes) on a candidate structured under a given playbook entry is
     recorded back against that entry — the same feedback signal
     KNOW-EXTRACT §10 already designs for the Tier-1 classifier, closed
     here for Tier-2 strategy selection instead.
  3. CURATION — periodically (`ace curate`), entries with enough samples
     and a high approval rate are promoted to `active` (preferred at
     match time); entries with enough samples and a low approval rate are
     retired (never matched again). Under-sampled entries stay `proposed`
     — still usable, not yet judged.

This is deliberately NOT the CLAUSE framework's reinforcement-learning
subgraph agents from the same article — that requires an RL training loop
(LC-MAPPO) this pipeline has no infrastructure for. What IS already true
here without new code: the platform's own Context Planner / Hybrid
Retriever / Context Assembly split loosely mirrors CLAUSE's Subgraph
Architect / Path Navigator / Context Curator separation of concerns —
just tuned by policy YAML instead of learned weights.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from pydantic import BaseModel, Field

from pipeline.config import settings
from pipeline.extraction.regimes import NormalizedDoc
from pipeline.extraction.tier0_gate import DOC_TYPE_TIER
from pipeline.llm_client import OllamaError, generate_json
from pipeline.models import ReviewDecisionAction, now_iso, new_id

_PATH = settings.data_dir / "ace_playbook.json"

MIN_SAMPLES_TO_JUDGE = 3
PROMOTE_THRESHOLD = 0.7
DEMOTE_THRESHOLD = 0.3


def pattern_signature(doc: NormalizedDoc, structural_elements: int, domain_hits: int) -> str:
    """Cheap, explainable clustering key — no embeddings, no ML. Buckets
    structural richness and domain-hit density coarsely so near-identical
    documents share a signature without requiring exact equality."""
    tier = DOC_TYPE_TIER.get(doc.doc_type, "C")
    struct_band = "rich" if structural_elements >= 3 else ("some" if structural_elements >= 1 else "bare")
    domain_band = "dense" if domain_hits >= 5 else ("some" if domain_hits >= 1 else "sparse")
    return f"{doc.source_type}:{doc.doc_type}:tier{tier}:struct-{struct_band}:domain-{domain_band}"


class PlaybookEntry(BaseModel):
    id: str = Field(default_factory=lambda: new_id("ace-"))
    pattern_signature: str
    strategy_text: str
    status: str = "proposed"  # proposed | active | retired
    sample_titles: list[str] = Field(default_factory=list)
    uses: int = 0
    approvals: int = 0
    rejections: int = 0
    changes_requested: int = 0
    created: str = Field(default_factory=now_iso)
    last_used: Optional[str] = None

    @property
    def success_rate(self) -> Optional[float]:
        judged = self.approvals + self.rejections
        if judged == 0:
            return None
        return self.approvals / judged


_GENERATION_SYSTEM_PROMPT = """You are tuning an extraction pipeline for an enterprise knowledge base.
You will see 1-3 sample documents that share a structural pattern (same source type, same document type, similar richness).
Propose ONE short, concrete instruction (1-3 sentences) that would help a structuring model extract this
pattern's content more accurately and consistently than a generic instruction would.
Focus on what's distinctive about THIS pattern — e.g. where business rules tend to hide, what's often implicit,
what structure to expect. Do not summarize the documents themselves.
Respond with JSON only: {"strategy": "..."}"""


class Playbook:
    def __init__(self, path: Path = _PATH):
        self.path = path
        self.entries: dict[str, PlaybookEntry] = {}
        if path.exists():
            data = json.loads(path.read_text(encoding="utf-8"))
            self.entries = {k: PlaybookEntry.model_validate(v) for k, v in data.items()}

    def save(self) -> None:
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.path.write_text(
            json.dumps({k: v.model_dump() for k, v in self.entries.items()}, indent=2, default=str),
            encoding="utf-8",
        )

    def by_signature(self, signature: str) -> list[PlaybookEntry]:
        return [e for e in self.entries.values() if e.pattern_signature == signature]

    def match(self, signature: str) -> Optional[PlaybookEntry]:
        """Best non-retired entry for this pattern — active entries
        preferred, then by success rate (unjudged entries sort last, they
        still get a chance to accumulate samples)."""
        candidates = [e for e in self.by_signature(signature) if e.status != "retired"]
        if not candidates:
            return None

        def _rank(e: PlaybookEntry) -> tuple[int, float]:
            status_rank = 1 if e.status == "active" else 0
            rate = e.success_rate if e.success_rate is not None else -1.0
            return (status_rank, rate)

        return max(candidates, key=_rank)

    # --- Generation ---
    def propose(self, signature: str, sample_docs: list[NormalizedDoc], model: Optional[str] = None) -> PlaybookEntry:
        samples_text = "\n\n---\n\n".join(
            f"Title: {d.title}\n{d.body_markdown[:1500]}" for d in sample_docs[:3]
        )
        prompt = f"Pattern: {signature}\n\nSample documents:\n\n{samples_text}"
        try:
            result = generate_json(prompt, system=_GENERATION_SYSTEM_PROMPT, model=model)
            strategy = str(result.get("strategy", "")).strip()
        except OllamaError:
            strategy = ""
        if not strategy:
            strategy = f"No specific guidance generated for pattern {signature}; using base extraction instructions."

        entry = PlaybookEntry(
            pattern_signature=signature, strategy_text=strategy,
            sample_titles=[d.title for d in sample_docs[:3]],
        )
        self.entries[entry.id] = entry
        self.save()
        return entry

    # --- Reflection ---
    def record_outcome(self, entry_id: Optional[str], action: ReviewDecisionAction) -> None:
        if not entry_id or entry_id not in self.entries:
            return
        entry = self.entries[entry_id]
        entry.uses += 1
        entry.last_used = now_iso()
        if action == ReviewDecisionAction.APPROVE:
            entry.approvals += 1
        elif action == ReviewDecisionAction.REJECT:
            entry.rejections += 1
        else:
            entry.changes_requested += 1
        self.save()

    def mark_matched(self, entry_id: str) -> None:
        """Called when an entry is selected to guide extraction, before the
        outcome is known — separate from record_outcome so 'times offered'
        and 'times judged' can both be reported."""
        if entry_id in self.entries:
            self.entries[entry_id].last_used = now_iso()
            self.save()

    # --- Curation ---
    def curate(self, min_samples: int = MIN_SAMPLES_TO_JUDGE, promote_at: float = PROMOTE_THRESHOLD,
               demote_at: float = DEMOTE_THRESHOLD) -> dict[str, list[str]]:
        report: dict[str, list[str]] = {"promoted": [], "retired": [], "unchanged": []}
        for entry in self.entries.values():
            judged = entry.approvals + entry.rejections
            if judged < min_samples:
                report["unchanged"].append(entry.id)
                continue
            rate = entry.success_rate
            if rate is not None and rate >= promote_at:
                entry.status = "active"
                report["promoted"].append(entry.id)
            elif rate is not None and rate <= demote_at:
                entry.status = "retired"
                report["retired"].append(entry.id)
            else:
                report["unchanged"].append(entry.id)
        self.save()
        return report
