from __future__ import annotations

import re
from typing import Iterable

from .base import RawItem, SourceConnector

_FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---\n(.*)$", re.DOTALL)


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}, text
    raw_fm, body = m.group(1), m.group(2)
    meta: dict = {}
    for line in raw_fm.splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        if value.startswith("[") and value.endswith("]"):
            items = [v.strip() for v in value[1:-1].split(",") if v.strip()]
            meta[key] = items
        else:
            meta[key] = value
    return meta, body.strip()


class RunbookConnector(SourceConnector):
    source_type = "runbook"

    def connect(self) -> bool:
        return self.root.exists()

    def list_items(self) -> Iterable[str]:
        for p in sorted(self.root.glob("*.md")):
            yield p.stem

    def fetch(self, item_id: str) -> RawItem:
        path = self.root / f"{item_id}.md"
        text = self._read_text(path)
        meta, body = _parse_frontmatter(text)
        return RawItem(
            item_id=item_id,
            content={"title": meta.get("title", item_id), "body_markdown": body, **meta},
            content_format="json",
            updated=str(meta.get("updated", "")),
            path=str(path),
            metadata={
                "page_type": "Runbook",
                "status": meta.get("status", "Active"),
                "owner": meta.get("owner"),
                "labels": meta.get("labels", []),
                "version": meta.get("version"),
            },
        )
