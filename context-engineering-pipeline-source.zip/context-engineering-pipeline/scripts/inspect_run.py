import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from pipeline.config import settings
from pipeline.governance.review_store import ReviewStore
from pipeline.indexing import es_index
from pipeline.indexing.graph_builder import GraphBuilder
from pipeline.models import ObjectStatus

store = ReviewStore()
pending = store.list_candidates(status=ObjectStatus.PENDING_REVIEW)
print(f"=== Pending review: {len(pending)} ===")
for c in pending:
    conflicts = store.conflicts_for(c.id)
    conflict_note = f" CONFLICT sev={conflicts[0].severity:.2f}" if conflicts else ""
    dup_note = f" NEAR_DUP_OF={c.near_duplicate_of}" if c.near_duplicate_of else ""
    drift_note = " DRIFT" if c.drift_flag else ""
    print(f"  [{c.gate_verdict.value:12}] {c.source_type.value:10} {c.title[:50]:50} entity={c.canonical_entity_key}{conflict_note}{dup_note}{drift_note}")

approved = store.list_candidates(status=ObjectStatus.APPROVED)
print(f"\n=== Already-approved (structured/telemetry, auto): {len(approved)} ===")
for c in approved[:20]:
    print(f"  {c.source_type.value:10} {c.title[:60]}")

print("\n=== Elasticsearch doc count ===")
client = es_index.get_client()
idx = es_index.index_name_for("production")
client.indices.refresh(index=idx)
count = client.count(index=idx)["count"]
print(f"  {idx}: {count} docs")

print("\n=== Neo4j node counts ===")
gb = GraphBuilder()
with gb.driver.session() as session:
    result = session.run("MATCH (n {env: 'production'}) RETURN labels(n)[0] AS label, count(*) AS c ORDER BY c DESC")
    for r in result:
        print(f"  {r['label']:20} {r['c']}")
gb.close()
